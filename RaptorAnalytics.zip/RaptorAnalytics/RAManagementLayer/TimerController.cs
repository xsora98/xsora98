﻿
namespace ManagementLayer
{
    public static class TimerController
    {
        public static int INTERVAL = 50;
    }
}
