﻿using System;
using System.Collections.Generic;
using OpenTK;
using OpenTK.Input;
using RAGraphicsControlLayer;

namespace GraphicsControlLayer
{
    public class WalkAroundCamera : ICamera
    {
        #region // storage       

        private float MouseSensitivity = 0.0025f;
        private Vector3 Orientation = new Vector3((float)Math.PI, 0f, 0f);
        private float MoveSpeed = 0.2f;

        public Vector3 Position = new Vector3(0, 0, 3);
        public Vector3 Front = new Vector3(0,0,-1);
        public Vector3 Up = Vector3.UnitY;

        private float fScale;

        public Vector3 direction;

        public Matrix4 ViewMatrix;

        #endregion

        #region //Constructor

        public WalkAroundCamera() 
        {
            ViewMatrix = GetViewMatrix();
        }

        #endregion

        #region //Methods       

        public void ZoomIn(int nDelta)
        {
            fScale += (0.1f * nDelta);
        }
        public void ZoomOut(int nDelta)
        {
            if (fScale > 0.5f)
                fScale -= (0.1f * nDelta);
        }

        public void ProcessInput()
        {
            const float cameraSpeed = 0.05f;

            if (Keyboard.GetState().IsKeyDown(Key.W))
                Position += cameraSpeed * Front;

            if (Keyboard.GetState().IsKeyDown(Key.S))
                Position -= cameraSpeed * Front;

            if (Keyboard.GetState().IsKeyDown(Key.A))
                Position -= Vector3.Normalize(Vector3.Cross(Front, Up)) * cameraSpeed;

            if (Keyboard.GetState().IsKeyDown(Key.D))
                Position += Vector3.Normalize(Vector3.Cross(Front, Up)) * cameraSpeed;   
        }

        public Matrix4 GetProjectionMatrix(float fWidth, float fHeight)
        {
            float aspect_ratio = fWidth / fHeight;
            return Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect_ratio, 0.001f, 1000f) * Matrix4.CreateScale(0.5f);
        }

        public Matrix4 GetViewMatrix()
        {
            return Matrix4.LookAt(Position, Position + Front, Vector3.UnitY) * Matrix4.CreateScale(fScale);
        }

        public Matrix4 GetViewMatrix2()
        {
            return GetViewMatrix();
        }

        public Matrix4 GetScaleMatrix()
        {
            return Matrix4.CreateScale(fScale);
        }

        public Matrix4 LookAt(Vector3 eye, Vector3 at, Vector3 up)
        {
            return Matrix4.LookAt(eye, at, up);
        }

        public void Move(float x, float y, float z)
        {
            Vector3 offset = new Vector3();

            Vector3 forward = new Vector3((float)Math.Sin((float)Orientation.X), 0, (float)Math.Cos((float)Orientation.X));
            Vector3 right = new Vector3(-forward.Z, 0, forward.X);

            offset += x * right;
            offset += y * forward;
            offset.Y += z;

            offset.NormalizeFast();
            offset = Vector3.Multiply(offset, MoveSpeed);

            Position += offset;
        }

        public void AddRotation(float x, float y)
        {
            x = x * MouseSensitivity;
            y = y * MouseSensitivity;

            Orientation.X = (Orientation.X + x) % ((float)Math.PI * 2.0f);
            Orientation.Y = Math.Max(Math.Min(Orientation.Y + y, (float)Math.PI / 2.0f - 0.1f), (float)-Math.PI / 2.0f + 0.1f);
        }

        public void RotateCameraPos(float x, float y)
        {
            Matrix4 mRotateY = Matrix4.CreateRotationY(x * (float)(Math.PI / 720));

            //Matrix4 mRotateX = Matrix4.CreateRotationY(y * (float)(Math.PI / 90));
            float fOldX = Position.X;
            float fOldY = Position.Y;
            float fOldZ = Position.Z;

            Position.X = mRotateY.M11 * fOldX + mRotateY.M12 * fOldY + mRotateY.M13 * fOldZ + mRotateY.M14;
            Position.Y = mRotateY.M21 * fOldX + mRotateY.M22 * fOldY + mRotateY.M23 * fOldZ + mRotateY.M24;
            Position.Z = mRotateY.M31 * fOldX + mRotateY.M32 * fOldY + mRotateY.M33 * fOldZ + mRotateY.M34;

            Matrix4 mRotateX = Matrix4.CreateRotationX(y * (float)(Math.PI / 720));

            fOldX = Position.X;
            fOldY = Position.Y;
            fOldZ = Position.Z;

            Position.X = mRotateX.M11 * fOldX + mRotateX.M12 * fOldY + mRotateX.M13 * fOldZ + mRotateX.M14;
            Position.Y = mRotateX.M21 * fOldX + mRotateX.M22 * fOldY + mRotateX.M23 * fOldZ + mRotateX.M24;
            Position.Z = mRotateX.M31 * fOldX + mRotateX.M32 * fOldY + mRotateX.M33 * fOldZ + mRotateX.M34;
        }

        public void MoveCameraPos(float x, float y)
        {
            Position += Up * y;
            Front += Up * y;
        }

        // for different rotation algorithm
        public void SetDirection(double yaw, double pitch)
        {
            direction.X = (float)(Math.Cos(yaw) * Math.Cos(pitch));
            direction.Z = (float) Math.Sin(yaw);
            direction.Y = (float)(Math.Sin(yaw) * Math.Cos(pitch));
        }

        #endregion

    }

    public class Camera : ICamera
    {
        #region //Storage

        private bool m_bProjectionOrthographic;

        public Vector3 eye = new Vector3(0, 0, 150);
        public Vector3 target = new Vector3(0, 0, 0);
        public Vector3 up = Vector3.UnitY;

        public Matrix4 lookat;
         
        private float fScale;
        

        private float MoveSpeed = 0.2f;
        public float GetSetMoveSpeed { get { return MoveSpeed; } set { MoveSpeed = value; } }


        private Vector3 Position = new Vector3(0, 0f, 5f);
        public Vector3 GetSetPosition { get { return Position; } set { Position = value; } }
         

        private Vector3 Orientation = new Vector3((float)Math.PI, 0f, 0f);
        public Vector3 GetSetOrientation { get { return Orientation; } set { Orientation = value; } }


        private float MouseSensitivity = 0.0025f;

        public float GetSetMouseSensitivity { get { return MouseSensitivity; } set { MouseSensitivity = value; } }

        #endregion

        #region //Constructor

        public Camera(Matrix4 lookAt, bool bProjectionOrthographic)
        {
            lookat = lookAt;
            fScale = 1;

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        public Camera(List<Vector3> vectors, bool bProjectionOrthographic)
        {
            fScale = 1;
            eye = vectors[0];

            if (vectors.Count == 2)
                target = vectors[1];

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        public Camera(Vector3 eye, Vector3 target, Vector3 up, bool bProjectionOrthographic)
        {
            fScale = 1;
            this.eye = eye;
            this.target = target;
            this.up = up;

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        public Camera(Vector3 position, Vector3 orientation, bool bProjectionOrthographic)
        {
            fScale = 1;
            Position = position;
            Orientation = orientation;

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        public Camera(bool bProjectionOrthographic)
        {
            fScale = 1;
            Position = new Vector3(0, 0, -10);

            Orientation = new Vector3(0,0,0);

            target = Vector3.Zero;

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        public Camera(Vector3 position, bool bProjectionOrthographic)
        {
            fScale = 1;
            Position = position;

            m_bProjectionOrthographic = bProjectionOrthographic;
        }

        #endregion

        #region //Operations

        public void ZoomIn(int nDelta)
        {
            fScale += (0.1f* nDelta);
        }

        public void ZoomOut(int nDelta)
        {
            if(fScale > 0.5f)
                fScale -= (0.1f* nDelta);
        }

        public Matrix4 GetProjectionMatrix(float fWidth, float fHeight)
        {
            float aspect_ratio = fWidth / fHeight;

            if (m_bProjectionOrthographic == false)
            {
                return Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, aspect_ratio, 0.001f, 1000f) * Matrix4.CreateScale(0.5f);
            }
            else
            {
                return Matrix4.CreateOrthographic(fWidth, fHeight, -100000f, 100000f);
            }
        }
         
        public Matrix4 GetViewMatrix()
        {
            Vector3 lookat = new Vector3();
            
            lookat.X = (float)(Math.Sin((float)Orientation.X) * Math.Cos((float)Orientation.Y));
            lookat.Y = (float)Math.Sin((float)Orientation.Y);
            lookat.Z = (float)(Math.Cos((float)Orientation.X) * Math.Cos((float)Orientation.Y));

            return Matrix4.LookAt(Position, Position + lookat, Vector3.UnitY) * Matrix4.CreateScale(fScale);
        }

        public Matrix4 GetViewMatrix2()
        {

            Vector3 cameraDirection = Vector3.Normalize(Position - target);
            Vector3 cameraRight = Vector3.Normalize(Vector3.Cross(up, cameraDirection));


            Matrix4 view = Matrix4.LookAt(Position, target, up) * Matrix4.CreateScale(fScale);
            return view;

        }

        public Matrix4 GetScaleMatrix()
        {
            return Matrix4.CreateScale(fScale); 
        }

        public Matrix4 LookAt(Vector3 eye, Vector3 at, Vector3 up)
        {
            Vector3 zAxis = Vector3.Normalize(at - eye);
            Vector3 xAxis = Vector3.Normalize(Vector3.Cross(zAxis, up));
            Vector3 yAxis = Vector3.Cross(xAxis, zAxis);

            zAxis = -zAxis; 

            Vector4 firstRow =  new Vector4(xAxis.X, xAxis.Y, xAxis.Z, -Vector3.Dot(xAxis, eye));
            Vector4 secondRow = new Vector4(xAxis.X, xAxis.Y, xAxis.Z, -Vector3.Dot(yAxis, eye));
            Vector4 thirdRow =  new Vector4(xAxis.X, xAxis.Y, xAxis.Z, -Vector3.Dot(zAxis, eye));
            Vector4 fourthRow = new Vector4(0,       0,       0,        1);

            return new Matrix4(firstRow, secondRow, thirdRow, fourthRow);

        }

        public void Move(float x, float y, float z)
        {
            Vector3 offset = new Vector3();

            Vector3 forward = new Vector3((float)Math.Sin((float)Orientation.X), 0, (float)Math.Cos((float)Orientation.X));
            Vector3 right = new Vector3(-forward.Z, 0, forward.X);

            offset += x * right;
            offset += y * forward;
            offset.Y += z;

            offset.NormalizeFast();
            offset = Vector3.Multiply(offset, MoveSpeed);

            Position += offset;
        }

        public void AddRotation(float x, float y)
        {
            x = x * MouseSensitivity;
            y = y * MouseSensitivity;

            Orientation.X = (Orientation.X + x) % ((float)Math.PI * 2.0f);
            Orientation.Y = Math.Max(Math.Min(Orientation.Y + y, (float)Math.PI / 2.0f - 0.1f), (float)-Math.PI / 2.0f + 0.1f);
        }

        public void RotateCameraPos(float x, float y)
        {
            Matrix4 mRotateY = Matrix4.CreateRotationY(x * (float)(Math.PI / 720));

            //Matrix4 mRotateX = Matrix4.CreateRotationY(y * (float)(Math.PI / 90));
            float fOldX = Position.X;
            float fOldY = Position.Y;
            float fOldZ = Position.Z;

            Position.X = mRotateY.M11 * fOldX + mRotateY.M12 * fOldY + mRotateY.M13 * fOldZ + mRotateY.M14;
            Position.Y = mRotateY.M21 * fOldX + mRotateY.M22 * fOldY + mRotateY.M23 * fOldZ + mRotateY.M24;
            Position.Z = mRotateY.M31 * fOldX + mRotateY.M32 * fOldY + mRotateY.M33 * fOldZ + mRotateY.M34;
            
            Matrix4 mRotateX = Matrix4.CreateRotationX(y * (float)(Math.PI / 720));

            fOldX = Position.X;
            fOldY = Position.Y;
            fOldZ = Position.Z;

            Position.X = mRotateX.M11 * fOldX + mRotateX.M12 * fOldY + mRotateX.M13 * fOldZ + mRotateX.M14;
            Position.Y = mRotateX.M21 * fOldX + mRotateX.M22 * fOldY + mRotateX.M23 * fOldZ + mRotateX.M24;
            Position.Z = mRotateX.M31 * fOldX + mRotateX.M32 * fOldY + mRotateX.M33 * fOldZ + mRotateX.M34;
        }

        public void MoveCameraPos(float x, float y)
        {
            Position += up * y;
            target += up * y; 
        }

        #endregion
    }
}
