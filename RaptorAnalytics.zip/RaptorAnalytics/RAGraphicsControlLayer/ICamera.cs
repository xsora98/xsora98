﻿using OpenTK;

namespace RAGraphicsControlLayer
{
    public interface ICamera
    {

        void ZoomIn(int nDelta);
        void ZoomOut(int nDelta);
        Matrix4 GetProjectionMatrix(float fWidth, float fHeight);
        Matrix4 GetViewMatrix();
        Matrix4 GetViewMatrix2();
        Matrix4 GetScaleMatrix();
        Matrix4 LookAt(Vector3 eye, Vector3 at, Vector3 up);
        void Move(float x, float y, float z);
        void AddRotation(float x, float y);
        void RotateCameraPos(float x, float y);

        void MoveCameraPos(float x, float y);

    }
}
