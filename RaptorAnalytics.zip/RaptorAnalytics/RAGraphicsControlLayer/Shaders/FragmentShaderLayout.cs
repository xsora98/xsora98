﻿
namespace XmlDeserialize.Shaders
{
    public class FragmentShaderLayout
    {
        private static string fragmentShaderCode = @"#version 330 core
                                        
                                            out vec4 outputColor;

void main()
{
    outputColor = vec4(1.0, 1.0, 0.0, 1.0);
}";


        public static string FragmentShaderCode { get { return fragmentShaderCode; } private set { } }
    }
}
