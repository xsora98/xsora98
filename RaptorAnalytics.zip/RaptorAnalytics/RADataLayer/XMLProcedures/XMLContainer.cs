﻿using RADataLayer;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using static RADataLayer.Enumerations;

namespace XmlDeserialize.XmlProcedures
{
    public static class XmlContainer
    {
        //TODO REDO


        #region //storage

        public static List<Shape> shapeQueue = new List<Shape>();
        public static eProductTypes partType;


        public static void ProcessPartXml(String sFilePath, out Shape shapeProduct, out eProductTypes typeProduct)
        {
            typeProduct = eProductTypes.None;

            XmlAttributes attrs = new XmlAttributes();
            XmlAttributeOverrides xOver = new XmlAttributeOverrides();

            /* Create an XmlTypeAttribute and change the name of the XML type. */
            XmlTypeAttribute xType = new XmlTypeAttribute();
            XmlRootAttribute xRoot = new XmlRootAttribute();

            attrs.XmlRoot = xRoot;
            xRoot.ElementName = "Shape";
            
            var lines = System.IO.File.ReadAllLines(sFilePath);

            for (int i=0;i<Enumerations.ProductTypes.Length; i++)
            {

                string type = Enumerations.ProductTypes[i];
                if (lines[1].Contains(type))
                {
                    xType.TypeName = type;
                    typeProduct = (eProductTypes)i;

                    Console.WriteLine(type);
                    break;
                }
            }

            attrs.XmlType = xType;
            xOver.Add(typeof(Shape), attrs);

            shapeProduct = XmlDeserializer.DeserializeObject(sFilePath, xOver);
            shapeQueue.Add(shapeProduct);
            
        }

        #endregion


    }
}
