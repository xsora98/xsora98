﻿using XmlDeserialize.XmlProcedures;

namespace XmlDeserialize.Geometry
{
    public class RawShapeData
    {

        #region //Storage

        public float BottomFlangeThickness;
        public float FarLegThickness;
        public float FlangeSlope;
        public float Height;
        public float InnerDiameter;
        public float Length;
        public float NearLegThickness;
        public float OuterDiameter;
        public float TopFlangeThickness;
        public float RoundingRadius1;
        public float RoundingRadius2;
        public float Thickness;
        public float WebThickness;
        public float WeightPerLength;
        public float Width;

        public int ShapeType;

        public string Profile;
        public string ProfileID;

        #endregion

        #region //Constructor
        /// <summary>
        /// Retrieves last shape's raw data
        /// </summary>
        public RawShapeData()
        {
            var shapeData = XmlContainer.shapeQueue[XmlContainer.shapeQueue.Count - 1].RawShapeData;

            InitData(shapeData);
        }

        public RawShapeData(Shape shapeData)
        {
            InitData(shapeData.RawShapeData);
        }

        public RawShapeData(ShapeRawShapeData shapeData)
        {
            InitData(shapeData);
        }



        private void InitData(ShapeRawShapeData shapeData)
        {
            BottomFlangeThickness = shapeData.BottomFlangeThickness;
            FarLegThickness = shapeData.FarLegThickness;
            FlangeSlope = shapeData.FlangeSlope;
            Height = shapeData.Height;
            InnerDiameter = shapeData.InnerDiameter;
            Length = shapeData.Length;
            NearLegThickness = shapeData.NearLegThickness;
            OuterDiameter = shapeData.OuterDiameter;
            Profile = shapeData.Profile;
            ProfileID = shapeData.ProfileID;
            RoundingRadius1 = shapeData.RoundingRadius1;
            RoundingRadius2 = shapeData.RoundingRadius2;
            ShapeType = (int)shapeData.ShapeType;
            Thickness = shapeData.Thickness;
            TopFlangeThickness = shapeData.TopFlangeThickness;
            WebThickness = shapeData.WebThickness;
            WeightPerLength = shapeData.WeightPerLength;
            Width = shapeData.Width;
        }

        #endregion

        public override string ToString()
        {
            return "Bottom Flange Thickness:" + BottomFlangeThickness + "\r\n" +
                "Far Leg Thickness:" + FarLegThickness + "\r\n" +
                "Flange Slope:" + FlangeSlope + "\r\n" +
                "Height:" + Height + "\r\n" +
                "Inner Diameter:" + InnerDiameter + "\r\n" +
                "Length:" + Length + "\r\n" +
                "Near Leg Thickness:" + NearLegThickness + "\r\n" +
                "Outer Diameter:" + OuterDiameter + "\r\n" +
                "Profile:" + Profile + "\r\n" +
                "Profile ID:" + ProfileID + "\r\n" +
                "Rounding Radius 1:" + RoundingRadius1 + "\r\n" +
                "Rounding Radius 2:" + RoundingRadius2 + "\r\n" +
                "Shape Type:" + ShapeType + "\r\n" +
                "Thickness:" + Thickness + "\r\n" +
                "Top Flange Thickness:" + TopFlangeThickness + "\r\n" +
                "Web Thickness:" + WebThickness + "\r\n" +
                "Weight Per Length:" + WeightPerLength + "\r\n" +
                "Width:" + Width + "\r\n";
        }
    }

}
