﻿namespace ShapeLibrary
{
    public class Line
    {
        private Vertex vertex1;
        private Vertex vertex2;

        public Line(Vertex vertex1, Vertex vertex2)
        {
            this.vertex1 = vertex1;
            this.vertex2 = vertex2;
        }

        public Vertex getVertex1()
        {
            return this.vertex1;
        }

        public Vertex getVertex2()
        {
            return this.vertex2;
        }
    }
}
