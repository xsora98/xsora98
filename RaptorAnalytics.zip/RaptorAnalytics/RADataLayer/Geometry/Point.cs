﻿using System.Numerics;

namespace ShapeLibrary
{ 
    public class Point
    {
        #region//Storage

        private float x;
        private float y;
        private float z;

        public float X { get { return x; } set { x = value; } }
        public float Y { get { return y; } set { y = value; } }
        public float Z { get { return z; } set { z = value; } }

        #endregion

        #region//Constructor

        public Point(float x, float y, float z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public Point()
        {
            this.x = 0;
            this.y = 0;
            this.z = 0;
        }
        #endregion
        public Vector3 ToVector3()
        {
            return new Vector3(x, y, z);
        }

        public void Add(Point point)
        {
            this.x += point.x;
            this.y += point.y;
            this.z += point.z;
        }

        public void Subtract(Point point)
        {
            this.x -= point.x;
            this.y -= point.y;
            this.z -= point.z;
        }
    }
}
