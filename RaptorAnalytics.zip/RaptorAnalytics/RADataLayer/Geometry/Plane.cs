﻿using System.Numerics;


namespace ShapeLibrary
{
    public class Plane
    {

        #region //Storage

        public Vector3 firstPoint, secondPoint, thirdPoint, fourthPoint;
        public string orientation;
        public float orientationPoint;

        #endregion

        #region //Constructor
        public Plane(Vector3 point1, Vector3 point2, Vector3 point3, Vector3 point4, string orient, float orientPoint)
        {
            this.firstPoint = point1;
            this.secondPoint = point2;
            this.thirdPoint = point3;
            this.fourthPoint = point4;
            this.orientation = orient;
            this.orientationPoint = orientPoint;
        }

        #endregion
    }
}
