﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class LShape : MultiSolid
    {
        public Solid Web;
        public Solid Flange;

        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            listSolids = new List<Solid>(2);
            listSolids.Add(new Solid());
            listSolids.Add(new Solid());

            var webHeight = data.Height - data.TopFlangeThickness;
            var webThickness = data.WebThickness;
            var webLength = data.Length;

            var bottomFlangeHeight = data.WebThickness;
            var FlangeLength = data.Length;
            var FlangeWidth = data.Width;

            var webStartPosition = new Vector3(data.TopFlangeThickness, 0, 0);

            //Top flange
            listSolids[0].GenerateSolidPlanes(FlangeWidth, bottomFlangeHeight, FlangeLength, Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, Solid.ORIGIN);
            Flange = listSolids[0];
            //web
            listSolids[1].GenerateSolidPlanes(webHeight, webThickness, webLength, Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, webStartPosition);
            Web = listSolids[1];

            return this;
        }
    }
}
