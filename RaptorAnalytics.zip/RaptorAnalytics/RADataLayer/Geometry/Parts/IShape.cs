﻿using System.Collections.Generic;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class IShape : MultiSolid
    {
        public Solid Web;

        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            listSolids = new List<Solid>(1);

            listSolids.Add(new Solid());
            listSolids[0].GenerateSolidPlanes(data.Height,data.WebThickness,data.Length, Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, Solid.ORIGIN);
            Web = listSolids[0];

            return this;
        }
    }
}
