﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class HShape : MultiSolid
    {
        #region //Storage

        public Solid TopFlange;
        public Solid BottomFlange;
        public Solid Web;

        #endregion

        #region //Methods
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {

            listSolids = new List<Solid>(3);

            listSolids.Add(new Solid());
            listSolids.Add(new Solid());
            listSolids.Add(new Solid());

            var topFlangeHeight = data.TopFlangeThickness;
            var bottomFlangeHeight = data.BottomFlangeThickness;

            var webHeight = data.Height - data.TopFlangeThickness - data.BottomFlangeThickness;
            var webThickness = data.WebThickness;
            var webLength = data.Length;

            var FlangeLength = data.Length;
            var FlangeWidth = data.Width;

            var TopFlangeStartPosition = new Vector3(data.Height-data.BottomFlangeThickness,0, 0);
            var WebStartPosition = new Vector3(data.TopFlangeThickness, data.Width / 2, 0);

            //top flange
            listSolids[0].GenerateSolidPlanes(FlangeWidth, topFlangeHeight, FlangeLength, 
                                          Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, TopFlangeStartPosition);
            TopFlange = listSolids[0];

            //web
            listSolids[1].GenerateSolidPlanes(webHeight, webThickness, webLength, 
                                          Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, WebStartPosition);
            Web = listSolids[1];

            //bottom flange
            listSolids[2].GenerateSolidPlanes(FlangeWidth, bottomFlangeHeight, FlangeLength, 
                                          Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, Solid.ORIGIN);
            BottomFlange = listSolids[2];
           
            return this;
        }
        #endregion
    }
}
