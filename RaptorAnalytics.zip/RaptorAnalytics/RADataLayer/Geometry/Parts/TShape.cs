﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class TShape : MultiSolid
    {

        #region //Storage

        public Solid TopFlange;
        public Solid Web;

        #endregion



        #region //Methods
        /// <summary>
        /// 
        /// Generates solids required to represent shape, with the first solid indexed in the list being the topmost, the second one being the one below, etc. 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            listSolids = new List<Solid>(2);

            listSolids.Add(new Solid());
            listSolids.Add(new Solid());

            var topFlangeHeight = data.TopFlangeThickness;

            var webHeight = data.Height - data.TopFlangeThickness;
            var webThickness = data.WebThickness;
            var webLength = data.Length;

            var FlangeLength = data.Length;
            var FlangeWidth = data.Width;

            var WebStartPosition = new Vector3(data.TopFlangeThickness, data.Width / 2, 0);

            //top flange
            listSolids[0].GenerateSolidPlanes(FlangeWidth, topFlangeHeight, FlangeLength,
                                          Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, Solid.ORIGIN);
            TopFlange = listSolids[0];

            //web
            listSolids[1].GenerateSolidPlanes(webHeight, webThickness, webLength,
                                          Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, WebStartPosition);
            Web = listSolids[1];

            return this;
        }
        #endregion
    }
}
