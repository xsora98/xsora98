﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public abstract class MultiSolid
    {
        #region//Storage

        public List<Solid> listSolids = new List<Solid>();
  

        #endregion

        #region//Constructors

        public MultiSolid()
        {}
        public MultiSolid(List<Solid> solidList)
        {
            listSolids = solidList;
        }

        #endregion

        #region //Methods

        public abstract MultiSolid GenerateSolidsForPart(RawShapeData data);
        

        #endregion


    }
}
