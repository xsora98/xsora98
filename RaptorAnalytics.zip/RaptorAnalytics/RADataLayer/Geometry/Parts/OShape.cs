﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class OShape : MultiSolid
    {
        #region //Storage

        public Solid TopFlange;
        public Solid BottomFlange;
        public Solid LeftWeb;
        public Solid RightWeb;

        #endregion

        #region //Methods
        /// <summary>
        /// 
        /// Generates solids required for a tube object in clockwise order
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            listSolids = new List<Solid>(4);


            listSolids.Add(new Solid());
            listSolids.Add(new Solid());
            listSolids.Add(new Solid());
            listSolids.Add(new Solid());

            var webHeight = data.Height - data.Thickness * 2;
            var webThickness = data.Thickness;
            var webLength = data.Length;

            var topFlangeHeight = data.Thickness;
            var bottomFlangeHeight = data.Thickness;

            var FlangeLength = data.Length;
            var FlangeWidth = data.Width;

            var topFlangeStartPosition = new Vector3(data.Height-data.Thickness, 0, 0);
            var rightWebStartPosition = new Vector3(data.Thickness,FlangeWidth-data.Thickness,0);
            var leftWebStartPosition = new Vector3(data.Thickness, 0, 0);

            //top flange
            listSolids[0].GenerateSolidPlanes(FlangeWidth, topFlangeHeight, FlangeLength, Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, topFlangeStartPosition); ;
            TopFlange = listSolids[0];

            //left web
            listSolids[1].GenerateSolidPlanes(webHeight, webThickness, webLength, Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, leftWebStartPosition);
            LeftWeb = listSolids[1];

            //right web
            listSolids[2].GenerateSolidPlanes(webHeight, webThickness, webLength, Solid.DirectionX, Solid.DirectionY, Solid.DirectionZ, rightWebStartPosition);
            RightWeb = listSolids[2];

            //bottom flange
            listSolids[3].GenerateSolidPlanes(FlangeWidth, bottomFlangeHeight, FlangeLength, Solid.DirectionY, Solid.DirectionX, Solid.DirectionZ, Solid.ORIGIN);
            BottomFlange = listSolids[3];

            return this;
        }

        #endregion
    }
}
