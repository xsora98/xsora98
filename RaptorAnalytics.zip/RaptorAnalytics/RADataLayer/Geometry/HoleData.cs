﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlDeserialize.XmlProcedures;

namespace RADataLayer.Geometry
{
    public class HoleData
    {
        public List<Hole> holes = new List<Hole>();

        public HoleData()
        {
            var shapeData = XmlContainer.shapeQueue[XmlContainer.shapeQueue.Count - 1].HolesInAPart;

            InitData(shapeData);
        }

        public void InitData(ShapeHole[] holesData)
        {
            for (int i = 0; i < holesData.Length; i++)
                this.holes.Add(new Hole(holesData[i]));
        }

    }

    public class Hole
    {
        //public string holeType;
        public float locationX;
        public float locationY;
        public float locationZ;
        public string partSurface;
        public float diameter;

        public Hole(ShapeHole hole)
        {
            this.locationX = hole.Location.X;
            this.locationY = hole.Location.Y;
            this.locationZ = hole.Location.Z;
            this.partSurface = hole.partSurface;
            this.diameter = hole.Diameter;
        }
    }
}
