﻿using ShapeLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RADataLayer
{
    public static class ProductContainer
    {
        public static List<MultiSolid> listImportedProduct = new List<MultiSolid>();
    }
}
