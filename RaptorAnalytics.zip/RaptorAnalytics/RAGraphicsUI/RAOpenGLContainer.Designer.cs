﻿namespace RAGraphicsUI
{
    partial class RAOpenGLContainer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.RenderPanel = new Eto.OpenTK.WinForms.WinGLUserControl();
            this.timerGraphicsLuncher = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // RenderPanel
            // 
            this.RenderPanel.BackColor = System.Drawing.Color.Black;
            this.RenderPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RenderPanel.Location = new System.Drawing.Point(0, 0);
            this.RenderPanel.Margin = new System.Windows.Forms.Padding(4);
            this.RenderPanel.Name = "RenderPanel";
            this.RenderPanel.Size = new System.Drawing.Size(983, 551);
            this.RenderPanel.TabIndex = 0;
            this.RenderPanel.VSync = false;
            this.RenderPanel.Load += new System.EventHandler(this.RenderPanel_Load);
            this.RenderPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RenderPanel_MouseMove);
            this.RenderPanel.Resize += new System.EventHandler(this.RenderPanel_Resize);
            this.RenderPanel.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.RenderPanel_MouseWheel);
            // 
            // timerGraphicsLuncher
            // 
            this.timerGraphicsLuncher.Tick += new System.EventHandler(this.timerGraphicsLuncher_Tick);
            // 
            // RAOpenGLContainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.RenderPanel);
            this.Name = "RAOpenGLContainer";
            this.Size = new System.Drawing.Size(983, 551);
            this.ResumeLayout(false);

        }


        private Eto.OpenTK.WinForms.WinGLUserControl RenderPanel;
        private System.Windows.Forms.Timer timerGraphicsLuncher;
        #endregion
    }
}
