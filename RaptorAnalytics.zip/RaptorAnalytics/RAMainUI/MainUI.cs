﻿using RAManagementLayer;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;



namespace RAMainUI
{
    public partial class MainUI : Form
    {
        public Size panel2Cpy;
        public Size panel3Cpy;
        public Size panel4Cpy;

        public System.Drawing.Point panel4L;

        public MainUI()
        {
            InitializeComponent();
            panel2Cpy = panelGraphicsContainer.Size;
            panel3Cpy = panelErrorLogContainer.Size;
            panel4Cpy = panelDetailsContainer.Size;
            panel4L = panelDetailsContainer.Location;
        }




        private void winGLUserControl1_Resize(object sender, EventArgs e)
        {
        }


        private void renderPanelToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            
            if (renderPanelToolStripMenuItem.CheckState == CheckState.Unchecked)
            {
                panelGraphicsContainer.Visible = false;
                panelDetailsContainer.Width = panelMainContainer.Width;
                panelDetailsContainer.Location = new System.Drawing.Point(0, 0);

            }
            else
            {
                //Need update to work properly
                panelGraphicsContainer.Visible = true;
                panelDetailsContainer.Width = panel4Cpy.Width;
                panelDetailsContainer.Location = panel4L;
            }
        }

        private void simulationDetailsToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (simulationDetailsToolStripMenuItem.CheckState == CheckState.Unchecked)
            {
                panelDetailsContainer.Visible = false;
                panelGraphicsContainer.Width = panelMainContainer.Width;
            }else
            {
                panelDetailsContainer.Visible = true;
                panelGraphicsContainer.Width = panel2Cpy.Width;
            }
        }

        private void errorListToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (errorListToolStripMenuItem.CheckState==CheckState.Unchecked)
            {
                panelErrorLogContainer.Visible = false;
                panelGraphicsContainer.Height = panelMainContainer.Height;
                panelDetailsContainer.Height = panelMainContainer.Height;
            }else
            {
                panelErrorLogContainer.Visible = true;
                panelGraphicsContainer.Height = panel2Cpy.Height;
                panelDetailsContainer.Height = panel4Cpy.Height;
            }
        }


        private void loadShapeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filePath;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                    ProductManager.ImportNewProductPart(filePath);

                    /* using (StreamWriter writer = new StreamWriter(openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy")))
                     {
                         for (int i = 0; i < lines.Length; i++)
                         {
                             if (lines[i].Contains("Hole xsi:type="))
                             {
                                 list.Add(lines[i].Substring(lines[i].IndexOf("=\"") + 2, lines[i].IndexOf("\">") - lines[i].IndexOf("=\"") - 2));
                                 lines[i] = lines[i].Substring(0, lines[i].IndexOf("<")) + "<Hole>";
                                 writer.WriteLine(lines[i]);
                             }
                             else
                             {
                                 writer.WriteLine(lines[i]);
                             }
                         }
                     }*/

                    //File.Copy(openFileDialog.FileName, openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy"), true);
                    //DeserializeObject(openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy"), xOver);
                }
            }
        }

        private void loadMachineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                }
            }
        }

        private void loadToolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                }
            }
        }


        private void loadSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                }
            }
        }

        private void MainUI_Load(object sender, EventArgs e)
        {
            panelGraphicsContainer.Focus();
        }

        private void MainUI_SizeChanged(object sender, EventArgs e)
        {
            panel2Cpy = panelGraphicsContainer.Size;
            panel3Cpy = panelErrorLogContainer.Size;
            panel4Cpy = panelDetailsContainer.Size;
            panel4L = panelDetailsContainer.Location;
        }
    }
}
