﻿using System;
using System.Collections.Generic;
using System.Drawing;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using RADataLayer;
using RAGraphicsControlLayer;
using ShapeLibrary;

namespace GraphicsControlLayer
{
    public class RenderControl
    {
        public static int _vertexArrayObject;
        public static int _vertexBufferObject;
        public static int vertex_buffer_object, color_buffer_object;

        public static float rotatingX=0.5f;
        public static float rotatingY=0.5f;
        public static float rotatingZ=0.5f;
        public static List<Plane> test = new List<Plane>();
        public static List<Plane> testx = new List<Plane>();
        public static List<float> lst = new List<float>();
        public static List<float> lstColor = new List<float>();
        public static bool isLoaded = false;

        //shader
        public static Shader shader;

        private static string vertexShaderCode = @"#version 330 core
layout (location = 0) in vec3 aPos;
layout(location = 1) in vec3 vertexColor;

uniform mat4 view;
uniform mat4 projection;
out vec3 fragmentColor;
void main(){
    gl_Position = projection * view * vec4(aPos, 1.0); 
	fragmentColor=vertexColor;
}";

        private static string fragmentShaderCode = @"#version 330

in vec3 fragmentColor;

out vec3 color;

void main(){
    color = fragmentColor;
}";
        public static int ColorToRgba32(Color c)
        {
            return (int)((c.A << 24) | (c.B << 16) | (c.G << 8) | c.R);
        }

        public static void RenderFrame(Eto.OpenTK.WinForms.WinGLUserControl RenderPanel, Matrix4 lookAt, int _vertexArrayObject, List<float> test, float _angle)
        {
            RenderPanel.MakeCurrent();
            GL.ClearColor(Color.Purple);
            GL.Enable(EnableCap.DepthTest);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref lookAt);
            GL.Rotate(_angle, 0.0f, 1.0f, 0.0f);
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.BindVertexArray(_vertexArrayObject);
            GL.DrawArrays(PrimitiveType.Triangles, 0, test.ToArray().Length);
            RenderPanel.SwapBuffers();
        }

        public static void RenderFrame(Eto.OpenTK.WinForms.WinGLUserControl RenderPanel, Matrix4 lookat, int _vertexArrayObject, List<float> test)
        {
            RenderPanel.MakeCurrent();

            GL.Enable(EnableCap.DepthTest);


            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref lookat);

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            GL.BindVertexArray(_vertexArrayObject);
            GL.DrawArrays(PrimitiveType.Triangles, 0, test.ToArray().Length);
            RenderPanel.SwapBuffers();
        }
        public static void RenderFrameWithContour(Eto.OpenTK.WinForms.WinGLUserControl RenderPanel, Matrix4 lookat, Matrix4 projection)
        {

            RenderPanel.MakeCurrent();
            GL.ClearColor(Color.DarkGray);
            /*GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.DepthClamp);*/



            GL.Enable(EnableCap.LineSmooth);
            GL.Hint(HintTarget.LineSmoothHint, HintMode.Nicest);


            GL.Enable(EnableCap.PointSmooth);
            GL.Hint(HintTarget.PointSmoothHint, HintMode.Nicest);
            

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref lookat);

            GL.Rotate(rotatingY, new Vector3d(0.0, 0.0, 1.0));
            GL.Rotate(rotatingX, new Vector3d(0.0, 1.0, 0.0));
            GL.Rotate(rotatingZ, new Vector3d(1.0, 0.0, 0.0));

            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            //GL.BindVertexArray(_vertexArrayObject);


            //GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            if (isLoaded)
            {
                shader.UseProgram();
                //int modelLoc = GL.GetUniformLocation(shader.ProgramID, "model");
                int viewLoc = GL.GetUniformLocation(shader.ProgramID, "view");
                int projLoc = GL.GetUniformLocation(shader.ProgramID, "projection");
                //var model = Matrix4.Identity;
                //shader.SetMatrix4(modelLoc, model);
                shader.SetMatrix4(viewLoc, lookat);
                shader.SetMatrix4(projLoc, projection);
                //GL.UniformMatrix4(viewLoc, true, ref lookat);
                //GL.UniformMatrix4(projLoc, true, ref projection);
                
            }
            




            GL.Enable(EnableCap.DepthTest);

            DrawMainCoordinateSystem();

            DrawProductParts();

            //ATM this should remain commented for future testing
            
            //GL.Begin(PrimitiveType.Polygon);
            //GL.Color4(Color.Blue);
            //for (int i = 0; i < test.Count; i++)
            //    GL.Vertex3(new Vector3(test[i].SpaceCoordinates.X, test[i].SpaceCoordinates.Y, test[i].SpaceCoordinates.Z));
            //GL.End();



            //GL.Begin(PrimitiveType.Lines);
            //GL.Color4(Color.Black);
            //GL.LineWidth(0.5f);
            //for (int i = 0; i < test2.Count; i++)
            //    GL.Vertex3(new Vector3(test2[i].SpaceCoordinates.X, test2[i].SpaceCoordinates.Y, test2[i].SpaceCoordinates.Z));
            //GL.End();

            RenderPanel.SwapBuffers();
        }



        private static void DrawProductParts()
        {
            if (ProductContainer.listImportedProduct == null) return;
            if (ProductContainer.listImportedProduct.Count == 0) return;

            foreach (MultiSolid ms in ProductContainer.listImportedProduct)
            {
                if (ms.listSolids == null || ms.listSolids.Count == 0) continue;

                foreach (Solid s in ms.listSolids)
                {
                    DrawOneSolid(s);
                }
            }
        }

        private static void DrawOneSolid(Solid solidToDraw)
        {
            if (solidToDraw == null) return;


            if (solidToDraw.listSolidPlanes == null) return;

            //Uncomment the following line to see the triangles
            //GL.PolygonMode(MaterialFace.FrontAndBack, PolygonMode.Line);

            foreach (Plane plane in solidToDraw.listSolidPlanes)
            {

                GL.Begin(PrimitiveType.Lines);
                GL.Color4(Color.Black);
                GL.LineWidth(1f);
                GL.Vertex3(new Vector3(plane.firstPoint.X, plane.firstPoint.Y, plane.firstPoint.Z));
                GL.Vertex3(new Vector3(plane.secondPoint.X, plane.secondPoint.Y, plane.secondPoint.Z));
                GL.End();

                GL.Begin(PrimitiveType.Lines);
                GL.Color4(Color.Black);
                GL.LineWidth(1f);
                GL.Vertex3(new Vector3(plane.secondPoint.X, plane.secondPoint.Y, plane.secondPoint.Z));
                GL.Vertex3(new Vector3(plane.thirdPoint.X, plane.thirdPoint.Y, plane.thirdPoint.Z));
                GL.End();

                GL.Begin(PrimitiveType.Lines);
                GL.Color4(Color.Black);
                GL.LineWidth(1f);
                GL.Vertex3(new Vector3(plane.thirdPoint.X, plane.thirdPoint.Y, plane.thirdPoint.Z));
                GL.Vertex3(new Vector3(plane.fourthPoint.X, plane.fourthPoint.Y, plane.fourthPoint.Z));
                GL.End();

                GL.Begin(PrimitiveType.Lines);
                GL.Color4(Color.Black);
                GL.LineWidth(1f);
                GL.Vertex3(new Vector3(plane.fourthPoint.X, plane.fourthPoint.Y, plane.fourthPoint.Z));
                GL.Vertex3(new Vector3(plane.firstPoint.X, plane.firstPoint.Y, plane.firstPoint.Z));
                GL.End();

            }

            
            //GL.Color4(Color.MediumPurple);
            GL.EnableVertexAttribArray(0);
            GL.BindBuffer(BufferTarget.ArrayBuffer, vertex_buffer_object);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);
            GL.BindBuffer(BufferTarget.ArrayBuffer, color_buffer_object);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.DrawArrays(PrimitiveType.Triangles, 0, lst.Count);
            GL.DisableVertexAttribArray(0);
            GL.DisableVertexAttribArray(1);

        }

        private static void DrawMainCoordinateSystem()
        {
            //Draw Coordynate system
            //Draw axes X
            GL.Begin(PrimitiveType.Lines);
            GL.Color4(Color.Red);
            GL.LineWidth(10f);
            GL.Vertex3(new Vector3(0, 0, 0));
            GL.Vertex3(new Vector3(50, 0, 0));
            GL.End();
            GL.Begin(PrimitiveType.Lines);
            GL.Color4(Color.Green);
            GL.LineWidth(10f);
            GL.Vertex3(new Vector3(0, 0, 0));
            GL.Vertex3(new Vector3(0, 50, 0));
            GL.End();
            GL.Begin(PrimitiveType.Lines);
            GL.Color4(Color.Blue);
            GL.LineWidth(10f);
            GL.Vertex3(new Vector3(0, 0, 0));
            GL.Vertex3(new Vector3(0, 0, 50));
            GL.End();
        }


        public static void Resize(Eto.OpenTK.WinForms.WinGLUserControl RenderPanel, ICamera cam)
        {
            float aspect_ratio = (float)RenderPanel.ClientSize.Width / (float)RenderPanel.ClientSize.Height;

            //float aspect_ratio = Math.Max(RenderPanel.ClientSize.Width, 1) / (float)Math.Max(RenderPanel.ClientSize.Height, 1);
           // Matrix4 perspective = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver2, aspect_ratio, 0.1f, 10000);

            Matrix4 perspective = cam.GetProjectionMatrix((float) RenderPanel.ClientSize.Width, (float) RenderPanel.ClientSize.Height);

            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref perspective);
            GL.Viewport(0, 0, RenderPanel.Width, RenderPanel.Height);
        }

        public static void RenderStart(Eto.OpenTK.WinForms.WinGLUserControl RenderPanel)
        {
            _vertexBufferObject = GL.GenBuffer();
            _vertexArrayObject = GL.GenVertexArray();
            
            GL.Viewport(0, 0, RenderPanel.Width, RenderPanel.Height);
            /*GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
            

            GL.BindVertexArray(_vertexArrayObject);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
            GL.EnableVertexAttribArray(0);

            GL.VertexAttribPointer(1, 6, VertexAttribPointerType.Float, true, 3 * sizeof(float), colors);
            GL.EnableVertexAttribArray(1);*/

            //GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
            //

            /* if (ProductContainer.listImportedProduct == null) return;
             if (ProductContainer.listImportedProduct.Count == 0) return;

             foreach (MultiSolid ms in ProductContainer.listImportedProduct)
             {
                 if (ms.listSolids == null || ms.listSolids.Count == 0) continue;

                 foreach (Solid s in ms.listSolids)
                 {
                     DrawOneSolid(s);
                 }
             }*/
            //GL.BufferData(BufferTarget.ArrayBuffer, lst.ToArray().Length * sizeof(float), lst.ToArray(), BufferUsageHint.StaticDraw);
          
           // shader.UseProgram();
        }

        public static void VertexGenTest()
        {
            foreach (MultiSolid ms in ProductContainer.listImportedProduct)
            {
                if (ms.listSolids == null || ms.listSolids.Count == 0) continue;

                foreach (Solid s in ms.listSolids)
                {
                    lst.AddRange(s.GetTriangleArray());
                    lstColor.AddRange(s.colorList);
                }
            }
            shader = new Shader(vertexShaderCode, fragmentShaderCode);
            shader.Load();
            GL.GenBuffers(1, out vertex_buffer_object);
            GL.GenBuffers(1, out color_buffer_object);
            GL.BindBuffer(BufferTarget.ArrayBuffer,vertex_buffer_object);
            GL.BufferData(BufferTarget.ArrayBuffer, lst.ToArray().Length * sizeof(float), lst.ToArray(), BufferUsageHint.StaticDraw);
            GL.BindBuffer(BufferTarget.ArrayBuffer,color_buffer_object);
            GL.BufferData(BufferTarget.ArrayBuffer, lstColor.ToArray().Length * sizeof(float), lstColor.ToArray(), BufferUsageHint.StaticDraw);
            
            isLoaded = true;
            //solve shader
        }

    }
}
