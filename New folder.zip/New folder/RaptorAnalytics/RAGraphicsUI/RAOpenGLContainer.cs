﻿using System;
using System.Windows.Forms;
using OpenTK.Input;
using GraphicsControlLayer;
using RAGraphicsControlLayer;

namespace RAGraphicsUI
{
    public partial class RAOpenGLContainer : UserControl
    {

        ICamera cam = new Camera(true);
        //ICamera cam = new WalkAroundCamera();



        System.Drawing.Point pMouseLastPos;     

        public RAOpenGLContainer()
        {
            InitializeComponent();
        }

        private void ProcessInput()
        {

            if (Keyboard.GetState().IsKeyDown(Key.W))
            {
                cam.Move(0f, 0.1f, 0f);
            }

            if (Keyboard.GetState().IsKeyDown(Key.S))
            {
                cam.Move(0f, -0.1f, 0f);
            }

            if (Keyboard.GetState().IsKeyDown(Key.A))
            {
                cam.Move(-0.1f, 0f, 0f);
            }

            if (Keyboard.GetState().IsKeyDown(Key.D))
            {
                cam.Move(0.1f, 0f, 0f);
            }

            if (Keyboard.GetState().IsKeyDown(Key.Q))
            {
                cam.Move(0f, 0f, 0.1f);
            }

            if (Keyboard.GetState().IsKeyDown(Key.E))
            {
                cam.Move(0f, 0f, -0.1f);
            }
            if (Keyboard.GetState().IsKeyDown(Key.Y))
            {
                RenderControl.rotatingY += 0.5f;
            }
            if (Keyboard.GetState().IsKeyDown(Key.X))
            {
                RenderControl.rotatingX += 0.5f;
            }
            if (Keyboard.GetState().IsKeyDown(Key.Z))
            {
                RenderControl.rotatingZ += 0.5f;
            }
 
        }

        private void timerGraphicsLuncher_Tick(object sender, EventArgs e)
        {
            ProcessInput();            
            RenderControl.RenderFrameWithContour(RenderPanel, cam.GetViewMatrix2(), cam.GetProjectionMatrix((float)RenderPanel.Width, (float)RenderPanel.Height));
        }

        private void RenderPanel_Load(object sender, EventArgs e)
        {

            RenderControl.RenderStart(RenderPanel);

            timerGraphicsLuncher.Interval = 50;   // 1000 ms per sec / 50 ms per frame = 20 FPS
            timerGraphicsLuncher.Start();
            timerGraphicsLuncher.Tick += new EventHandler(timerGraphicsLuncher_Tick);
        }

        private void RenderPanel_Resize(object sender, EventArgs e)
        {
            if (cam != null)
            {
                RenderControl.Resize(RenderPanel, cam);
            }
        }

        private void RenderPanel_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                cam.ZoomIn(e.Delta/20);
            }
            else if (e.Delta < 0)
            {
                cam.ZoomOut(Math.Abs(e.Delta)/20);
            }
        }



        private void RenderPanel_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && pMouseLastPos != null)
            {
                int nDeltaX = e.Location.X - pMouseLastPos.X;
                int nDeltaY = e.Location.Y - pMouseLastPos.Y;
                
                cam.RotateCameraPos(nDeltaX, nDeltaY);
            }
            else if (e.Button == MouseButtons.Left && pMouseLastPos != null)
            {
                int nDeltaX = e.Location.X - pMouseLastPos.X;
                int nDeltaY = e.Location.Y - pMouseLastPos.Y;

                cam.MoveCameraPos(nDeltaX, nDeltaY);
            }

            pMouseLastPos = e.Location;
        }
    }
}
