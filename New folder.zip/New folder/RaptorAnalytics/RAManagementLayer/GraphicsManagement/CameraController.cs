﻿//using OpenTK;
//using GraphicsControlLayer;

namespace ManagementLayer.GraphicsManagement
{
    public static class CameraController
    {
        //public static Camera Init() 
        //{
        //    //Camera camera = new Camera();
        //    //camera.lookat = Matrix4.LookAt(camera.eye, camera.target, camera.up);

        //    //return camera;
        //}
    }
}
