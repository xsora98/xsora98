﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;
using XmlDeserialize.XmlProcedures;

namespace RAManagementLayer
{
    public static class UIController
    {
        public static void OpenXML3D()
        {
            
            string filePath ;
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;
                    
                    ProductManager.ImportNewProductPart(filePath);

                    /* using (StreamWriter writer = new StreamWriter(openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy")))
                     {
                         for (int i = 0; i < lines.Length; i++)
                         {
                             if (lines[i].Contains("Hole xsi:type="))
                             {
                                 list.Add(lines[i].Substring(lines[i].IndexOf("=\"") + 2, lines[i].IndexOf("\">") - lines[i].IndexOf("=\"") - 2));
                                 lines[i] = lines[i].Substring(0, lines[i].IndexOf("<")) + "<Hole>";
                                 writer.WriteLine(lines[i]);
                             }
                             else
                             {
                                 writer.WriteLine(lines[i]);
                             }
                         }
                     }*/
                    
                    //File.Copy(openFileDialog.FileName, openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy"), true);
                    //DeserializeObject(openFileDialog.FileName.Insert(openFileDialog.FileName.IndexOf("."), "_cpy"), xOver);
                }
            }

        }

        public static void OpenMachine()
        {
            
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                   
                }
            }

        }

        public static void OpenTool()
        {

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Directory.GetCurrentDirectory();
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                }
            }

        }
    }
}
