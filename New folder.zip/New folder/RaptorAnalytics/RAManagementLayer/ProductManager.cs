﻿using GraphicsControlLayer;
using RADataLayer;
using ShapeLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlDeserialize.Geometry;
using XmlDeserialize.XmlProcedures;
using static RADataLayer.Enumerations;

namespace RAManagementLayer
{
    public static class ProductManager
    {
        

        public static void ImportNewProductPart(string sPartPath)
        {

             
            XmlContainer.ProcessPartXml(sPartPath, out Shape shapeToCreate, out eProductTypes partType);

            switch (partType)
            {
                case eProductTypes.Plate:
                    {
                        IShape newShape = new IShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();

                    }
                    break;
                case eProductTypes.Angle:
                    {
                        LShape newShape = new LShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();
                    }
                    break;
                case eProductTypes.Channel:
                    {
                        CShape newShape = new CShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();
                    }
                    break;
                case eProductTypes.Beam:
                    {
                        HShape newShape = new HShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();
                    }
                    break;
                case eProductTypes.Tube:
                    {
                        OShape newShape = new OShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();
                    }
                    break;
                case eProductTypes.TShape:
                    {
                        TShape newShape = new TShape();

                        //create the part from shapeToCreate

                        ProductContainer.listImportedProduct.Add(newShape);

                        RawShapeData rawShapeData = new RawShapeData(shapeToCreate);
                        newShape.GenerateSolidsForPart(rawShapeData);
                        RenderControl.VertexGenTest();
                    }
                    break;
            }


        }






    }
}
