﻿
namespace RAMainUI
{
    partial class MainUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStripMainMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadShapeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadMachineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCNCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shapeInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.machineInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pauseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renderPanelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulationDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.errorListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelMainContainer = new System.Windows.Forms.Panel();
            this.panelGraphicsContainer = new System.Windows.Forms.Panel();
            this.winGLUserControl1 = new System.Windows.Forms.Panel();
            this.panelDetailsContainer = new System.Windows.Forms.Panel();
            this.textBoxShapeDetails = new System.Windows.Forms.TextBox();
            this.panelErrorLogContainer = new System.Windows.Forms.Panel();
            this.textBoxErrorLogs = new System.Windows.Forms.TextBox();
            this.timerGraphicsLuncher = new System.Windows.Forms.Timer(this.components);
            this.raOpenGLContainer1 = new RAGraphicsUI.RAOpenGLContainer();
            this.menuStripMainMenu.SuspendLayout();
            this.panelMainContainer.SuspendLayout();
            this.panelGraphicsContainer.SuspendLayout();
            this.winGLUserControl1.SuspendLayout();
            this.panelDetailsContainer.SuspendLayout();
            this.panelErrorLogContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripMainMenu
            // 
            this.menuStripMainMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripMainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.infoToolStripMenuItem,
            this.simulationToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStripMainMenu.Location = new System.Drawing.Point(0, 0);
            this.menuStripMainMenu.Name = "menuStripMainMenu";
            this.menuStripMainMenu.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStripMainMenu.Size = new System.Drawing.Size(1290, 24);
            this.menuStripMainMenu.TabIndex = 0;
            this.menuStripMainMenu.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadShapeToolStripMenuItem,
            this.loadMachineToolStripMenuItem,
            this.loadToolToolStripMenuItem,
            this.loadSettingsToolStripMenuItem,
            this.loadCNCToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadShapeToolStripMenuItem
            // 
            this.loadShapeToolStripMenuItem.Name = "loadShapeToolStripMenuItem";
            this.loadShapeToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.loadShapeToolStripMenuItem.Text = "Load shape";
            this.loadShapeToolStripMenuItem.Click += new System.EventHandler(this.loadShapeToolStripMenuItem_Click);
            // 
            // loadMachineToolStripMenuItem
            // 
            this.loadMachineToolStripMenuItem.Name = "loadMachineToolStripMenuItem";
            this.loadMachineToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.loadMachineToolStripMenuItem.Text = "Load machine";
            this.loadMachineToolStripMenuItem.Click += new System.EventHandler(this.loadMachineToolStripMenuItem_Click);
            // 
            // loadToolToolStripMenuItem
            // 
            this.loadToolToolStripMenuItem.Name = "loadToolToolStripMenuItem";
            this.loadToolToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.loadToolToolStripMenuItem.Text = "Load tool";
            this.loadToolToolStripMenuItem.Click += new System.EventHandler(this.loadToolToolStripMenuItem_Click);
            // 
            // loadSettingsToolStripMenuItem
            // 
            this.loadSettingsToolStripMenuItem.Name = "loadSettingsToolStripMenuItem";
            this.loadSettingsToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.loadSettingsToolStripMenuItem.Text = "Load settings";
            this.loadSettingsToolStripMenuItem.Click += new System.EventHandler(this.loadSettingsToolStripMenuItem_Click);
            // 
            // loadCNCToolStripMenuItem
            // 
            this.loadCNCToolStripMenuItem.Name = "loadCNCToolStripMenuItem";
            this.loadCNCToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.loadCNCToolStripMenuItem.Text = "Load CNC";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shapeInfoToolStripMenuItem,
            this.machineInfoToolStripMenuItem,
            this.toolInfoToolStripMenuItem});
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.infoToolStripMenuItem.Text = "Info";
            // 
            // shapeInfoToolStripMenuItem
            // 
            this.shapeInfoToolStripMenuItem.Name = "shapeInfoToolStripMenuItem";
            this.shapeInfoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.shapeInfoToolStripMenuItem.Text = "Shape info";
            // 
            // machineInfoToolStripMenuItem
            // 
            this.machineInfoToolStripMenuItem.Name = "machineInfoToolStripMenuItem";
            this.machineInfoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.machineInfoToolStripMenuItem.Text = "Machine info";
            // 
            // toolInfoToolStripMenuItem
            // 
            this.toolInfoToolStripMenuItem.Name = "toolInfoToolStripMenuItem";
            this.toolInfoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.toolInfoToolStripMenuItem.Text = "Tool info";
            // 
            // simulationToolStripMenuItem
            // 
            this.simulationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.stopToolStripMenuItem,
            this.pauseToolStripMenuItem});
            this.simulationToolStripMenuItem.Name = "simulationToolStripMenuItem";
            this.simulationToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.simulationToolStripMenuItem.Text = "Simulation";
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.startToolStripMenuItem.Text = "Start";
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.stopToolStripMenuItem.Text = "Stop";
            // 
            // pauseToolStripMenuItem
            // 
            this.pauseToolStripMenuItem.Name = "pauseToolStripMenuItem";
            this.pauseToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.pauseToolStripMenuItem.Text = "Pause";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem,
            this.renderPanelToolStripMenuItem,
            this.simulationDetailsToolStripMenuItem,
            this.errorListToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            // 
            // renderPanelToolStripMenuItem
            // 
            this.renderPanelToolStripMenuItem.Checked = true;
            this.renderPanelToolStripMenuItem.CheckOnClick = true;
            this.renderPanelToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.renderPanelToolStripMenuItem.Name = "renderPanelToolStripMenuItem";
            this.renderPanelToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.renderPanelToolStripMenuItem.Text = "Render panel";
            this.renderPanelToolStripMenuItem.CheckedChanged += new System.EventHandler(this.renderPanelToolStripMenuItem_CheckedChanged);
            // 
            // simulationDetailsToolStripMenuItem
            // 
            this.simulationDetailsToolStripMenuItem.Checked = true;
            this.simulationDetailsToolStripMenuItem.CheckOnClick = true;
            this.simulationDetailsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.simulationDetailsToolStripMenuItem.Name = "simulationDetailsToolStripMenuItem";
            this.simulationDetailsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.simulationDetailsToolStripMenuItem.Text = "Simulation details";
            this.simulationDetailsToolStripMenuItem.CheckedChanged += new System.EventHandler(this.simulationDetailsToolStripMenuItem_CheckedChanged);
            // 
            // errorListToolStripMenuItem
            // 
            this.errorListToolStripMenuItem.Checked = true;
            this.errorListToolStripMenuItem.CheckOnClick = true;
            this.errorListToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.errorListToolStripMenuItem.Name = "errorListToolStripMenuItem";
            this.errorListToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.errorListToolStripMenuItem.Text = "Error list";
            this.errorListToolStripMenuItem.CheckedChanged += new System.EventHandler(this.errorListToolStripMenuItem_CheckedChanged);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // panelMainContainer
            // 
            this.panelMainContainer.AutoSize = true;
            this.panelMainContainer.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panelMainContainer.Controls.Add(this.panelGraphicsContainer);
            this.panelMainContainer.Controls.Add(this.panelDetailsContainer);
            this.panelMainContainer.Controls.Add(this.panelErrorLogContainer);
            this.panelMainContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMainContainer.Location = new System.Drawing.Point(0, 24);
            this.panelMainContainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelMainContainer.Name = "panelMainContainer";
            this.panelMainContainer.Size = new System.Drawing.Size(1290, 671);
            this.panelMainContainer.TabIndex = 1;
            // 
            // panelGraphicsContainer
            // 
            this.panelGraphicsContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelGraphicsContainer.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panelGraphicsContainer.Controls.Add(this.winGLUserControl1);
            this.panelGraphicsContainer.Location = new System.Drawing.Point(3, 3);
            this.panelGraphicsContainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelGraphicsContainer.Name = "panelGraphicsContainer";
            this.panelGraphicsContainer.Size = new System.Drawing.Size(1025, 566);
            this.panelGraphicsContainer.TabIndex = 3;
            // 
            // winGLUserControl1
            // 
            this.winGLUserControl1.BackColor = System.Drawing.Color.Black;
            this.winGLUserControl1.Controls.Add(this.raOpenGLContainer1);
            this.winGLUserControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.winGLUserControl1.Location = new System.Drawing.Point(0, 0);
            this.winGLUserControl1.Margin = new System.Windows.Forms.Padding(4);
            this.winGLUserControl1.Name = "winGLUserControl1";
            this.winGLUserControl1.Size = new System.Drawing.Size(1025, 566);
            this.winGLUserControl1.TabIndex = 0;
            this.winGLUserControl1.Resize += new System.EventHandler(this.winGLUserControl1_Resize);
            // 
            // panelDetailsContainer
            // 
            this.panelDetailsContainer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelDetailsContainer.AutoSize = true;
            this.panelDetailsContainer.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panelDetailsContainer.Controls.Add(this.textBoxShapeDetails);
            this.panelDetailsContainer.Location = new System.Drawing.Point(1032, 3);
            this.panelDetailsContainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelDetailsContainer.Name = "panelDetailsContainer";
            this.panelDetailsContainer.Size = new System.Drawing.Size(256, 566);
            this.panelDetailsContainer.TabIndex = 2;
            // 
            // textBoxShapeDetails
            // 
            this.textBoxShapeDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxShapeDetails.HideSelection = false;
            this.textBoxShapeDetails.Location = new System.Drawing.Point(0, 0);
            this.textBoxShapeDetails.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxShapeDetails.Multiline = true;
            this.textBoxShapeDetails.Name = "textBoxShapeDetails";
            this.textBoxShapeDetails.ReadOnly = true;
            this.textBoxShapeDetails.Size = new System.Drawing.Size(256, 566);
            this.textBoxShapeDetails.TabIndex = 0;
            this.textBoxShapeDetails.Text = "Details information";
            // 
            // panelErrorLogContainer
            // 
            this.panelErrorLogContainer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelErrorLogContainer.AutoSize = true;
            this.panelErrorLogContainer.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panelErrorLogContainer.Controls.Add(this.textBoxErrorLogs);
            this.panelErrorLogContainer.Location = new System.Drawing.Point(3, 575);
            this.panelErrorLogContainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelErrorLogContainer.Name = "panelErrorLogContainer";
            this.panelErrorLogContainer.Size = new System.Drawing.Size(1285, 89);
            this.panelErrorLogContainer.TabIndex = 1;
            // 
            // textBoxErrorLogs
            // 
            this.textBoxErrorLogs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBoxErrorLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxErrorLogs.HideSelection = false;
            this.textBoxErrorLogs.Location = new System.Drawing.Point(0, 0);
            this.textBoxErrorLogs.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxErrorLogs.Multiline = true;
            this.textBoxErrorLogs.Name = "textBoxErrorLogs";
            this.textBoxErrorLogs.ReadOnly = true;
            this.textBoxErrorLogs.Size = new System.Drawing.Size(1285, 89);
            this.textBoxErrorLogs.TabIndex = 3;
            this.textBoxErrorLogs.Text = "Error list";
            // 
            // raOpenGLContainer1
            // 
            this.raOpenGLContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.raOpenGLContainer1.Location = new System.Drawing.Point(0, 0);
            this.raOpenGLContainer1.Margin = new System.Windows.Forms.Padding(5);
            this.raOpenGLContainer1.Name = "raOpenGLContainer1";
            this.raOpenGLContainer1.Size = new System.Drawing.Size(1025, 566);
            this.raOpenGLContainer1.TabIndex = 0;
            // 
            // MainUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 695);
            this.Controls.Add(this.panelMainContainer);
            this.Controls.Add(this.menuStripMainMenu);
            this.MainMenuStrip = this.menuStripMainMenu;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainUI";
            this.Text = "Raptor Analytics";
            this.Load += new System.EventHandler(this.MainUI_Load);
            this.SizeChanged += new System.EventHandler(this.MainUI_SizeChanged);
            this.menuStripMainMenu.ResumeLayout(false);
            this.menuStripMainMenu.PerformLayout();
            this.panelMainContainer.ResumeLayout(false);
            this.panelMainContainer.PerformLayout();
            this.panelGraphicsContainer.ResumeLayout(false);
            this.winGLUserControl1.ResumeLayout(false);
            this.panelDetailsContainer.ResumeLayout(false);
            this.panelDetailsContainer.PerformLayout();
            this.panelErrorLogContainer.ResumeLayout(false);
            this.panelErrorLogContainer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripMainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadShapeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadMachineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shapeInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machineInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pauseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.Panel panelMainContainer;
        private System.Windows.Forms.Panel panelDetailsContainer;
        private System.Windows.Forms.Panel panelErrorLogContainer;
        private System.Windows.Forms.ToolStripMenuItem renderPanelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem simulationDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem errorListToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxShapeDetails;
        private System.Windows.Forms.Panel panelGraphicsContainer;
        private System.Windows.Forms.Panel winGLUserControl1;
        private System.Windows.Forms.Timer timerGraphicsLuncher;
        private System.Windows.Forms.TextBox textBoxErrorLogs;
        private RAGraphicsUI.RAOpenGLContainer raOpenGLContainer1;
        private System.Windows.Forms.ToolStripMenuItem loadSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCNCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
    }
}

