﻿namespace RADataLayer
{
    public static class Enumerations
    {

        public static string[] _producttypes = new string[] {"None", "Angle", "Beam", "Channel", "Plate", "Tube", "TShape" };

        public static string[] ProductTypes
        {
            get => _producttypes;
        }

        public enum eProductTypes
        {
            None = 0,
            Angle = 1,
            Beam = 2,
            Channel = 3,
            Plate = 4,
            Tube = 5,
            TShape = 6
        }






    }
}
