﻿using System.IO;
using System.Xml.Serialization;

namespace XmlDeserialize.XmlProcedures
{
    public class XmlDeserializer
    {

        public static Shape DeserializeObject(string FileName, XmlAttributeOverrides xtr)
        {
            var serializer = new XmlSerializer(typeof(Shape), xtr);
            using (Stream reader = new FileStream(FileName, FileMode.Open))
                return (Shape)serializer.Deserialize(reader);
        }
    }
}
