﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Numerics;
using LibTessDotNet;

namespace ShapeLibrary
{
    public class Solid
    {
        #region// Storage

        private List<Triangle> triangles;
        public List<Triangle> Triangles { get { return triangles; } private set { this.triangles = Triangles; } }

        public List<Line> contourLines;

        public List<Plane> listSolidPlanes;

        public List<Vector3> trianglesList = new List<Vector3>();

        public List<float> colorList = new List<float>();

        public static readonly Vector3 DirectionX = new Vector3(1, 0, 0);
        public static readonly Vector3 DirectionY = new Vector3(0, 1, 0);
        public static readonly Vector3 DirectionZ = new Vector3(0, 0, 1);

        public static readonly Vector3 ORIGIN = new Vector3(0,0,0);


        #endregion

        #region //Constructor

        public Solid() { }
        public Solid(List<Triangle> triangleList)
        {
            triangles = triangleList;
        }

        #endregion

        #region //GenerateSolids

        /// <summary>
        /// 
        /// Returns a rectangular shape used for representing flanges and webs, with the points in counterclockwise order
        /// </summary>
        /// <param name="Width"></param>
        /// <param name="Height"></param>
        /// <param name="Thickness"></param>
        /// <returns></returns>
        public static List<Plane> GenerateSolidContourRectangle(float Width, float Height, float length)
        {
            Vertex origin = new Vertex(new Point(0, 0, 0), Color.Gray);
            List<Vertex> contour = new List<Vertex>(8);
            List<Vertex> frontFace = new List<Vertex>();
            List<Vertex> backFace = new List<Vertex>();
            List<Plane> planeList = new List<Plane>();
            //Frontface
            frontFace.Add(origin);
            frontFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X + Width, origin.SpaceCoordinates.Y, origin.SpaceCoordinates.Z), Color.Gray));
            frontFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X + Width, origin.SpaceCoordinates.Y + Height, origin.SpaceCoordinates.Z), Color.Gray));
            frontFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X, origin.SpaceCoordinates.Y + Height, origin.SpaceCoordinates.Z), Color.Gray));
            frontFace.Add(origin);


            //Backface
            backFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X, origin.SpaceCoordinates.Y, origin.SpaceCoordinates.Z + length), Color.Gray));
            backFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X + Width, origin.SpaceCoordinates.Y, origin.SpaceCoordinates.Z + length), Color.Gray));
            backFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X + Width, origin.SpaceCoordinates.Y + Height, origin.SpaceCoordinates.Z + length), Color.Gray));
            backFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X, origin.SpaceCoordinates.Y + Height, origin.SpaceCoordinates.Z + length), Color.Gray));
            backFace.Add(new Vertex(new Point(origin.SpaceCoordinates.X, origin.SpaceCoordinates.Y, origin.SpaceCoordinates.Z + length), Color.Gray));

            planeList.Add(new Plane(frontFace[0].ToVector3(), frontFace[1].ToVector3(), frontFace[2].ToVector3(), frontFace[3].ToVector3(), "Front", frontFace[0].ToVector3().Z));
            planeList.Add(new Plane(backFace[0].ToVector3(), backFace[1].ToVector3(), backFace[2].ToVector3(), backFace[3].ToVector3(), "Back", backFace[0].ToVector3().Z));
            
            for (int i = 0; i < frontFace.Count - 1; i++)
            {
                if (frontFace[i].ToVector3().X == frontFace[i + 1].ToVector3().X)
                {
                    planeList.Add(new Plane(frontFace[i].ToVector3(), backFace[i].ToVector3(), backFace[i + 1].ToVector3(), frontFace[i + 1].ToVector3(), "Vertical", frontFace[i].ToVector3().X));
                }
                else if (frontFace[i].ToVector3().Y == frontFace[i + 1].ToVector3().Y)
                {
                    planeList.Add(new Plane(frontFace[i].ToVector3(), backFace[i].ToVector3(), backFace[i + 1].ToVector3(), frontFace[i + 1].ToVector3(), "Horizontal", frontFace[i].ToVector3().Y));
                }
            }

            return planeList;
               /*PlaneGenerator planeGenerator = new PlaneGenerator(planeList);
                return planeGenerator.MainPlane;*/
        }


        private List<Triangle> GenerateTrianglesFromSolidPoints(List<Vertex> vertices) 
        {
            throw new NotImplementedException();
        }

        private List<Line> GenerateContourLinesFromSolidPoints(List<Vertex> vertices) 
        {
            throw new NotImplementedException();

        }     
        public void GenerateSolidPlanes(float fWidthOrHeight, float fThickness, float fLength, Vector3 vDirWidthHeight, Vector3 vDirThickess, Vector3 vDirLength, Vector3 vOrigin)
        {
            listSolidPlanes = new List<Plane>();
            var lstFront = new List<Vector3>();
            var lstBack = new List<Vector3>();
            //calculate distance vectors 
            Vector3 vWidthHeight = vDirWidthHeight * fWidthOrHeight;
            Vector3 vThick = vDirThickess * fThickness;
            Vector3 vLength = vDirLength * fLength;

            //calculate front points
            Vector3 planeFront1 = new Vector3(vOrigin.X, vOrigin.Y, vOrigin.Z);
            lstFront.Add(planeFront1);
            Vector3 planeFront2 = vOrigin + vLength;
            lstFront.Add(planeFront2);
            Vector3 planeFront3 = vOrigin + vLength + vWidthHeight;
            lstFront.Add(planeFront3);
            Vector3 planeFront4 = vOrigin + vWidthHeight;
            lstFront.Add(planeFront4);
            lstFront.Add(planeFront1);

            Plane planeFront = new Plane(planeFront1, planeFront2, planeFront3, planeFront4, "Front", planeFront1.Z);

            //calculate back points points 
            Vector3 planeBack1 = planeFront1 + vThick;
            lstBack.Add(planeBack1);
            Vector3 planeBack2 = planeFront2 + vThick;
            lstBack.Add(planeBack2);
            Vector3 planeBack3 = planeFront3 + vThick;
            lstBack.Add(planeBack3);
            Vector3 planeBack4 = planeFront4 + vThick;
            lstBack.Add(planeBack4);
            lstBack.Add(planeBack1);

            Plane planeBack = new Plane(planeBack1, planeBack2, planeBack3, planeBack4, "Back", planeBack1.Z);

            listSolidPlanes.Add(planeFront);
            listSolidPlanes.Add(planeBack);

            int nIndexPrevPoint = 3;
            for (int nIndexPoint = 0; nIndexPoint < 4; nIndexPoint++)
            {
                listSolidPlanes.Add(new Plane(lstFront[nIndexPrevPoint], lstBack[nIndexPrevPoint], lstBack[nIndexPoint], lstFront[nIndexPoint], "Vertical", lstFront[nIndexPrevPoint].Z));

                nIndexPrevPoint = nIndexPoint;
            }

            //Calling Tesselateion function
            Tesselate(listSolidPlanes);

            #endregion
        }

        public void Tesselate(List<Plane> planes)
        {
            Tess tess = new Tess();
            foreach (Plane plane in planes)
            {
                var v = new ContourVertex[4];
                v[0].Position = new Vec3(plane.firstPoint.X, plane.firstPoint.Y, plane.firstPoint.Z);
                v[1].Position = new Vec3(plane.secondPoint.X, plane.secondPoint.Y, plane.secondPoint.Z);
                v[2].Position = new Vec3(plane.thirdPoint.X, plane.thirdPoint.Y, plane.thirdPoint.Z);
                v[3].Position = new Vec3(plane.fourthPoint.X, plane.fourthPoint.Y, plane.fourthPoint.Z);
                tess.AddContour(v, ContourOrientation.Original);
                tess.Tessellate(WindingRule.EvenOdd, ElementType.Polygons, 3);
                for (int i = 0; i < tess.ElementCount; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int index = tess.Elements[i * 3 + j];
                        if (index == -1)
                            continue;
                        trianglesList.Add(new Vector3(tess.Vertices[index].Position.X, tess.Vertices[index].Position.Y, tess.Vertices[index].Position.Z));
                    }
                }
            }

        }

        public List<float> GetTriangleArray()
        {
            List<float> list = new List<float>();

            foreach(Vector3 vec in trianglesList)
            {
                list.Add(vec.X);
                list.Add(vec.Y);
                list.Add(vec.Z);

                colorList.Add(1.0f);
                colorList.Add(0.0f);
                colorList.Add(1.0f);
            }

            return list;
        }

    }
}
