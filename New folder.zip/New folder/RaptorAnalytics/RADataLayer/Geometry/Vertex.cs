﻿using System.Drawing;
using System.Numerics;


namespace ShapeLibrary
{
    public class Vertex
    {
         #region//Storage

        private Point spaceCoordinates;
        private Color color;

        public Point SpaceCoordinates { get { return spaceCoordinates; } set { spaceCoordinates = value; } }

        public Color Color { get { return color; } set { color = value; } }

        #endregion

        #region//Constructor

        public Vertex(Point point, Color color)
        {
            this.spaceCoordinates = point;
            this.color = color;
        }

        public Vertex(Point point)
        {
            this.spaceCoordinates = point;
        }

        public Vertex(Color color)
        {
            this.color = color;
        }

        public Vertex() 
        {
;            this.spaceCoordinates = new Point(0, 0, 0);
            this.color = Color.Black;
        }
        #endregion

        #region //Operations

        public Vector3 ToVector3()
        {
            return new Vector3(this.spaceCoordinates.X, this.spaceCoordinates.Y, this.spaceCoordinates.Z);
        }

        #endregion
    }
}
