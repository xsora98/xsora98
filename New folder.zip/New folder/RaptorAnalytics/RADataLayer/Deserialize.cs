﻿using System;

namespace XmlDeserialize
{

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Shape
    {

        private object productDataField;

        private object materialChangeLogField;

        private object materialInformationField;

        private ShapeProcessingSpecs processingSpecsField;

        private object runNumberField;

        private object heatNumberField;

        private string sourceMaterialGUIDField;

        private decimal absoluteRoundingNumberField;

        private string shapeSourceField;

        private object sourceFilePathField;

        private bool areCorrectionsAppliedField;

        private ShapeProjectInfo projectInfoField;

        private ShapeFabricationInformation fabricationInformationField;

        private ShapeProductionInformation productionInformationField;

        private ShapeDesign designField;

        private ShapeTwoDPoint[] profilePointsInnerField;

        private ShapeTwoDPoint1[] profilePointsField;

        private object copeGroupsField;

        private decimal zwebField;

        private decimal zundersideField;

        private decimal zwebUField;

        private decimal zundersideUField;

        private decimal ytField;

        private decimal ybField;

        private byte rightEdgeMiterYField;

        private byte rightEdgeMiterZField;

        private byte leftEdgeMiterYField;

        private byte leftEdgeMiterZField;

        private object copesField;

        private object scribesField;

        private object rectangleScribesField;

        private object weldsField;

        private string partIDField;

        private ShapeConstructionPoints constructionPointsField;

        private ShapeConstructionLines constructionLinesField;

        private ShapeTools toolsField;

        private ShapeRawShapeData rawShapeDataField;

        private string partMultipartIDField;

        private object allFacesField;

        private bool hollowCenterField;

        private bool isColumnField;

        private ShapeHole[] holesInAPartField;

        private ShapePopMark[] popMarksField;

        private byte numberOfPiecesField;

        private string nameField;

        private string shapeStringField;

        private string versionField;

        /// <remarks/>
        public object ProductData
        {
            get
            {
                return this.productDataField;
            }
            set
            {
                this.productDataField = value;
            }
        }

        /// <remarks/>
        public object MaterialChangeLog
        {
            get
            {
                return this.materialChangeLogField;
            }
            set
            {
                this.materialChangeLogField = value;
            }
        }

        /// <remarks/>
        public object MaterialInformation
        {
            get
            {
                return this.materialInformationField;
            }
            set
            {
                this.materialInformationField = value;
            }
        }

        /// <remarks/>
        public ShapeProcessingSpecs ProcessingSpecs
        {
            get
            {
                return this.processingSpecsField;
            }
            set
            {
                this.processingSpecsField = value;
            }
        }

        /// <remarks/>
        public object RunNumber
        {
            get
            {
                return this.runNumberField;
            }
            set
            {
                this.runNumberField = value;
            }
        }

        /// <remarks/>
        public object HeatNumber
        {
            get
            {
                return this.heatNumberField;
            }
            set
            {
                this.heatNumberField = value;
            }
        }

        /// <remarks/>
        public string SourceMaterialGUID
        {
            get
            {
                return this.sourceMaterialGUIDField;
            }
            set
            {
                this.sourceMaterialGUIDField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public string ShapeSource
        {
            get
            {
                return this.shapeSourceField;
            }
            set
            {
                this.shapeSourceField = value;
            }
        }

        /// <remarks/>
        public object SourceFilePath
        {
            get
            {
                return this.sourceFilePathField;
            }
            set
            {
                this.sourceFilePathField = value;
            }
        }

        /// <remarks/>
        public bool AreCorrectionsApplied
        {
            get
            {
                return this.areCorrectionsAppliedField;
            }
            set
            {
                this.areCorrectionsAppliedField = value;
            }
        }

        /// <remarks/>
        public ShapeProjectInfo projectInfo
        {
            get
            {
                return this.projectInfoField;
            }
            set
            {
                this.projectInfoField = value;
            }
        }

        /// <remarks/>
        public ShapeFabricationInformation FabricationInformation
        {
            get
            {
                return this.fabricationInformationField;
            }
            set
            {
                this.fabricationInformationField = value;
            }
        }

        /// <remarks/>
        public ShapeProductionInformation ProductionInformation
        {
            get
            {
                return this.productionInformationField;
            }
            set
            {
                this.productionInformationField = value;
            }
        }

        /// <remarks/>
        public ShapeDesign Design
        {
            get
            {
                return this.designField;
            }
            set
            {
                this.designField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("TwoDPoint", IsNullable = false)]
        public ShapeTwoDPoint[] ProfilePointsInner
        {
            get
            {
                return this.profilePointsInnerField;
            }
            set
            {
                this.profilePointsInnerField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("TwoDPoint", IsNullable = false)]
        public ShapeTwoDPoint1[] ProfilePoints
        {
            get
            {
                return this.profilePointsField;
            }
            set
            {
                this.profilePointsField = value;
            }
        }

        /// <remarks/>
        public object CopeGroups
        {
            get
            {
                return this.copeGroupsField;
            }
            set
            {
                this.copeGroupsField = value;
            }
        }

        /// <remarks/>
        public decimal Zweb
        {
            get
            {
                return this.zwebField;
            }
            set
            {
                this.zwebField = value;
            }
        }

        /// <remarks/>
        public decimal Zunderside
        {
            get
            {
                return this.zundersideField;
            }
            set
            {
                this.zundersideField = value;
            }
        }

        /// <remarks/>
        public decimal ZwebU
        {
            get
            {
                return this.zwebUField;
            }
            set
            {
                this.zwebUField = value;
            }
        }

        /// <remarks/>
        public decimal ZundersideU
        {
            get
            {
                return this.zundersideUField;
            }
            set
            {
                this.zundersideUField = value;
            }
        }

        /// <remarks/>
        public decimal Yt
        {
            get
            {
                return this.ytField;
            }
            set
            {
                this.ytField = value;
            }
        }

        /// <remarks/>
        public decimal Yb
        {
            get
            {
                return this.ybField;
            }
            set
            {
                this.ybField = value;
            }
        }

        /// <remarks/>
        public byte RightEdgeMiterY
        {
            get
            {
                return this.rightEdgeMiterYField;
            }
            set
            {
                this.rightEdgeMiterYField = value;
            }
        }

        /// <remarks/>
        public byte RightEdgeMiterZ
        {
            get
            {
                return this.rightEdgeMiterZField;
            }
            set
            {
                this.rightEdgeMiterZField = value;
            }
        }

        /// <remarks/>
        public byte LeftEdgeMiterY
        {
            get
            {
                return this.leftEdgeMiterYField;
            }
            set
            {
                this.leftEdgeMiterYField = value;
            }
        }

        /// <remarks/>
        public byte LeftEdgeMiterZ
        {
            get
            {
                return this.leftEdgeMiterZField;
            }
            set
            {
                this.leftEdgeMiterZField = value;
            }
        }

        /// <remarks/>
        public object Copes
        {
            get
            {
                return this.copesField;
            }
            set
            {
                this.copesField = value;
            }
        }

        /// <remarks/>
        public object Scribes
        {
            get
            {
                return this.scribesField;
            }
            set
            {
                this.scribesField = value;
            }
        }

        /// <remarks/>
        public object RectangleScribes
        {
            get
            {
                return this.rectangleScribesField;
            }
            set
            {
                this.rectangleScribesField = value;
            }
        }

        /// <remarks/>
        public object Welds
        {
            get
            {
                return this.weldsField;
            }
            set
            {
                this.weldsField = value;
            }
        }

        /// <remarks/>
        public string PartID
        {
            get
            {
                return this.partIDField;
            }
            set
            {
                this.partIDField = value;
            }
        }

        /// <remarks/>
        public ShapeConstructionPoints ConstructionPoints
        {
            get
            {
                return this.constructionPointsField;
            }
            set
            {
                this.constructionPointsField = value;
            }
        }

        /// <remarks/>
        public ShapeConstructionLines ConstructionLines
        {
            get
            {
                return this.constructionLinesField;
            }
            set
            {
                this.constructionLinesField = value;
            }
        }

        /// <remarks/>
        public ShapeTools Tools
        {
            get
            {
                return this.toolsField;
            }
            set
            {
                this.toolsField = value;
            }
        }

        /// <remarks/>
        public ShapeRawShapeData RawShapeData
        {
            get
            {
                return this.rawShapeDataField;
            }
            set
            {
                this.rawShapeDataField = value;
            }
        }

        /// <remarks/>
        public string PartMultipartID
        {
            get
            {
                return this.partMultipartIDField;
            }
            set
            {
                this.partMultipartIDField = value;
            }
        }

        /// <remarks/>
        public object AllFaces
        {
            get
            {
                return this.allFacesField;
            }
            set
            {
                this.allFacesField = value;
            }
        }

        /// <remarks/>
        public bool HollowCenter
        {
            get
            {
                return this.hollowCenterField;
            }
            set
            {
                this.hollowCenterField = value;
            }
        }

        /// <remarks/>
        public bool IsColumn
        {
            get
            {
                return this.isColumnField;
            }
            set
            {
                this.isColumnField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Hole", IsNullable = false)]
        public ShapeHole[] HolesInAPart
        {
            get
            {
                return this.holesInAPartField;
            }
            set
            {
                this.holesInAPartField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("PopMark", IsNullable = false)]
        public ShapePopMark[] PopMarks
        {
            get
            {
                return this.popMarksField;
            }
            set
            {
                this.popMarksField = value;
            }
        }

        /// <remarks/>
        public byte NumberOfPieces
        {
            get
            {
                return this.numberOfPiecesField;
            }
            set
            {
                this.numberOfPiecesField = value;
            }
        }

        /// <remarks/>
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string ShapeString
        {
            get
            {
                return this.shapeStringField;
            }
            set
            {
                this.shapeStringField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeProcessingSpecs
    {

        private byte cutWidthField;

        private byte fillerSizeField;

        private byte minimumFrontPieceField;

        private byte minumumEndPieceField;

        private string nestingField;

        private object machineIdentificationField;

        private object machineNameField;

        private object taskNameField;

        private object taskAreaNameField;

        private ShapeProcessingSpecsProcessingInformation processingInformationField;

        /// <remarks/>
        public byte CutWidth
        {
            get
            {
                return this.cutWidthField;
            }
            set
            {
                this.cutWidthField = value;
            }
        }

        /// <remarks/>
        public byte FillerSize
        {
            get
            {
                return this.fillerSizeField;
            }
            set
            {
                this.fillerSizeField = value;
            }
        }

        /// <remarks/>
        public byte MinimumFrontPiece
        {
            get
            {
                return this.minimumFrontPieceField;
            }
            set
            {
                this.minimumFrontPieceField = value;
            }
        }

        /// <remarks/>
        public byte MinumumEndPiece
        {
            get
            {
                return this.minumumEndPieceField;
            }
            set
            {
                this.minumumEndPieceField = value;
            }
        }

        /// <remarks/>
        public string Nesting
        {
            get
            {
                return this.nestingField;
            }
            set
            {
                this.nestingField = value;
            }
        }

        /// <remarks/>
        public object MachineIdentification
        {
            get
            {
                return this.machineIdentificationField;
            }
            set
            {
                this.machineIdentificationField = value;
            }
        }

        /// <remarks/>
        public object MachineName
        {
            get
            {
                return this.machineNameField;
            }
            set
            {
                this.machineNameField = value;
            }
        }

        /// <remarks/>
        public object TaskName
        {
            get
            {
                return this.taskNameField;
            }
            set
            {
                this.taskNameField = value;
            }
        }

        /// <remarks/>
        public object TaskAreaName
        {
            get
            {
                return this.taskAreaNameField;
            }
            set
            {
                this.taskAreaNameField = value;
            }
        }

        /// <remarks/>
        public ShapeProcessingSpecsProcessingInformation processingInformation
        {
            get
            {
                return this.processingInformationField;
            }
            set
            {
                this.processingInformationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeProcessingSpecsProcessingInformation
    {

        private System.DateTime durationField;

        private System.DateTime startTimeField;

        private System.DateTime stopTimeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(DataType = "time")]
        public System.DateTime Duration
        {
            get
            {
                return this.durationField;
            }
            set
            {
                this.durationField = value;
            }
        }

        /// <remarks/>
        public System.DateTime StartTime
        {
            get
            {
                return this.startTimeField;
            }
            set
            {
                this.startTimeField = value;
            }
        }

        /// <remarks/>
        public System.DateTime StopTime
        {
            get
            {
                return this.stopTimeField;
            }
            set
            {
                this.stopTimeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeProjectInfo
    {

        private string projectInfoIDField;

        private object projectNameField;

        private string projectNumberField;

        private string originField;

        private System.DateTime startDateField;

        private System.DateTime endDateField;

        private object notesField;

        private object addressField;

        private object builderField;

        private object fabricatorField;

        private object descriptionField;

        private object designerField;

        /// <remarks/>
        public string ProjectInfoID
        {
            get
            {
                return this.projectInfoIDField;
            }
            set
            {
                this.projectInfoIDField = value;
            }
        }

        /// <remarks/>
        public object ProjectName
        {
            get
            {
                return this.projectNameField;
            }
            set
            {
                this.projectNameField = value;
            }
        }

        /// <remarks/>
        public string ProjectNumber
        {
            get
            {
                return this.projectNumberField;
            }
            set
            {
                this.projectNumberField = value;
            }
        }

        /// <remarks/>
        public string Origin
        {
            get
            {
                return this.originField;
            }
            set
            {
                this.originField = value;
            }
        }

        /// <remarks/>
        public System.DateTime StartDate
        {
            get
            {
                return this.startDateField;
            }
            set
            {
                this.startDateField = value;
            }
        }

        /// <remarks/>
        public System.DateTime EndDate
        {
            get
            {
                return this.endDateField;
            }
            set
            {
                this.endDateField = value;
            }
        }

        /// <remarks/>
        public object Notes
        {
            get
            {
                return this.notesField;
            }
            set
            {
                this.notesField = value;
            }
        }

        /// <remarks/>
        public object Address
        {
            get
            {
                return this.addressField;
            }
            set
            {
                this.addressField = value;
            }
        }

        /// <remarks/>
        public object Builder
        {
            get
            {
                return this.builderField;
            }
            set
            {
                this.builderField = value;
            }
        }

        /// <remarks/>
        public object Fabricator
        {
            get
            {
                return this.fabricatorField;
            }
            set
            {
                this.fabricatorField = value;
            }
        }

        /// <remarks/>
        public object Description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public object Designer
        {
            get
            {
                return this.designerField;
            }
            set
            {
                this.designerField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeFabricationInformation
    {

        private string fabricationInformationGUIDField;

        private object orderIdentificationField;

        private object drawingIdentificationField;

        private object partPhaseIdentificationField;

        private object pieceIdentificationField;

        private object steelGradeField;

        private object batchField;

        private object loadField;

        /// <remarks/>
        public string FabricationInformationGUID
        {
            get
            {
                return this.fabricationInformationGUIDField;
            }
            set
            {
                this.fabricationInformationGUIDField = value;
            }
        }

        /// <remarks/>
        public object OrderIdentification
        {
            get
            {
                return this.orderIdentificationField;
            }
            set
            {
                this.orderIdentificationField = value;
            }
        }

        /// <remarks/>
        public object DrawingIdentification
        {
            get
            {
                return this.drawingIdentificationField;
            }
            set
            {
                this.drawingIdentificationField = value;
            }
        }

        /// <remarks/>
        public object PartPhaseIdentification
        {
            get
            {
                return this.partPhaseIdentificationField;
            }
            set
            {
                this.partPhaseIdentificationField = value;
            }
        }

        /// <remarks/>
        public object PieceIdentification
        {
            get
            {
                return this.pieceIdentificationField;
            }
            set
            {
                this.pieceIdentificationField = value;
            }
        }

        /// <remarks/>
        public object SteelGrade
        {
            get
            {
                return this.steelGradeField;
            }
            set
            {
                this.steelGradeField = value;
            }
        }

        /// <remarks/>
        public object Batch
        {
            get
            {
                return this.batchField;
            }
            set
            {
                this.batchField = value;
            }
        }

        /// <remarks/>
        public object Load
        {
            get
            {
                return this.loadField;
            }
            set
            {
                this.loadField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeProductionInformation
    {

        private ShapeProductionInformationLotInformation lotInformationField;

        private string idField;

        /// <remarks/>
        public ShapeProductionInformationLotInformation LotInformation
        {
            get
            {
                return this.lotInformationField;
            }
            set
            {
                this.lotInformationField = value;
            }
        }

        /// <remarks/>
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeProductionInformationLotInformation
    {

        private byte numberField;

        private object nameField;

        /// <remarks/>
        public byte Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        public object Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeDesign
    {

        private string designIDField;

        private bool isScrapField;

        /// <remarks/>
        public string DesignID
        {
            get
            {
                return this.designIDField;
            }
            set
            {
                this.designIDField = value;
            }
        }

        /// <remarks/>
        public bool IsScrap
        {
            get
            {
                return this.isScrapField;
            }
            set
            {
                this.isScrapField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeTwoDPoint
    {

        private decimal absoluteRoundingNumberField;

        private decimal xField;

        private decimal yField;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public decimal X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeTwoDPoint1
    {

        private decimal absoluteRoundingNumberField;

        private decimal xField;

        private decimal yField;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public decimal X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionPoints
    {

        private ShapeConstructionPointsConstructionPoint constructionPointField;

        /// <remarks/>
        public ShapeConstructionPointsConstructionPoint ConstructionPoint
        {
            get
            {
                return this.constructionPointField;
            }
            set
            {
                this.constructionPointField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionPointsConstructionPoint
    {

        private decimal absoluteRoundingNumberField;

        private string constructionPointIDField;

        private ShapeConstructionPointsConstructionPointLocation locationField;

        private string referenceOptionField;

        private byte surfaceField;

        private string partSurfaceField;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public string ConstructionPointID
        {
            get
            {
                return this.constructionPointIDField;
            }
            set
            {
                this.constructionPointIDField = value;
            }
        }

        /// <remarks/>
        public ShapeConstructionPointsConstructionPointLocation Location
        {
            get
            {
                return this.locationField;
            }
            set
            {
                this.locationField = value;
            }
        }

        /// <remarks/>
        public string ReferenceOption
        {
            get
            {
                return this.referenceOptionField;
            }
            set
            {
                this.referenceOptionField = value;
            }
        }

        /// <remarks/>
        public byte Surface
        {
            get
            {
                return this.surfaceField;
            }
            set
            {
                this.surfaceField = value;
            }
        }

        /// <remarks/>
        public string PartSurface
        {
            get
            {
                return this.partSurfaceField;
            }
            set
            {
                this.partSurfaceField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionPointsConstructionPointLocation
    {

        private ushort xField;

        private decimal yField;

        private decimal zField;

        private decimal absoluteRoundingNumberField;

        /// <remarks/>
        public ushort X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }

        /// <remarks/>
        public decimal Z
        {
            get
            {
                return this.zField;
            }
            set
            {
                this.zField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionLines
    {

        private ShapeConstructionLinesConstructionLine constructionLineField;

        /// <remarks/>
        public ShapeConstructionLinesConstructionLine ConstructionLine
        {
            get
            {
                return this.constructionLineField;
            }
            set
            {
                this.constructionLineField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionLinesConstructionLine
    {

        private decimal absoluteRoundingNumberField;

        private string constructionLineIDField;

        private ShapeConstructionLinesConstructionLineStartPoint startPointField;

        private ShapeConstructionLinesConstructionLineEndPoint endPointField;

        private byte surfaceField;

        private string partSurfaceField;

        private string referenceOptionField;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public string ConstructionLineID
        {
            get
            {
                return this.constructionLineIDField;
            }
            set
            {
                this.constructionLineIDField = value;
            }
        }

        /// <remarks/>
        public ShapeConstructionLinesConstructionLineStartPoint StartPoint
        {
            get
            {
                return this.startPointField;
            }
            set
            {
                this.startPointField = value;
            }
        }

        /// <remarks/>
        public ShapeConstructionLinesConstructionLineEndPoint EndPoint
        {
            get
            {
                return this.endPointField;
            }
            set
            {
                this.endPointField = value;
            }
        }

        /// <remarks/>
        public byte Surface
        {
            get
            {
                return this.surfaceField;
            }
            set
            {
                this.surfaceField = value;
            }
        }

        /// <remarks/>
        public string PartSurface
        {
            get
            {
                return this.partSurfaceField;
            }
            set
            {
                this.partSurfaceField = value;
            }
        }

        /// <remarks/>
        public string ReferenceOption
        {
            get
            {
                return this.referenceOptionField;
            }
            set
            {
                this.referenceOptionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionLinesConstructionLineStartPoint
    {

        private byte xField;

        private decimal yField;

        private decimal zField;

        private decimal absoluteRoundingNumberField;

        /// <remarks/>
        public byte X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }

        /// <remarks/>
        public decimal Z
        {
            get
            {
                return this.zField;
            }
            set
            {
                this.zField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeConstructionLinesConstructionLineEndPoint
    {

        private ushort xField;

        private decimal yField;

        private decimal zField;

        private decimal absoluteRoundingNumberField;

        /// <remarks/>
        public ushort X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }

        /// <remarks/>
        public decimal Z
        {
            get
            {
                return this.zField;
            }
            set
            {
                this.zField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeTools
    {

        private object webToolsField;

        private object topFlangeToolsField;

        private object bottomFlangeToolsField;

        private object undersideToolsField;

        private object allToolsField;

        /// <remarks/>
        public object WebTools
        {
            get
            {
                return this.webToolsField;
            }
            set
            {
                this.webToolsField = value;
            }
        }

        /// <remarks/>
        public object TopFlangeTools
        {
            get
            {
                return this.topFlangeToolsField;
            }
            set
            {
                this.topFlangeToolsField = value;
            }
        }

        /// <remarks/>
        public object BottomFlangeTools
        {
            get
            {
                return this.bottomFlangeToolsField;
            }
            set
            {
                this.bottomFlangeToolsField = value;
            }
        }

        /// <remarks/>
        public object UndersideTools
        {
            get
            {
                return this.undersideToolsField;
            }
            set
            {
                this.undersideToolsField = value;
            }
        }

        /// <remarks/>
        public object AllTools
        {
            get
            {
                return this.allToolsField;
            }
            set
            {
                this.allToolsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeRawShapeData
    {

        private string profileIDField;

        private ushort lengthField;

        private string profileField;

        private float webThicknessField;

        private float thicknessField;

        private float heightField;

        private float widthField;

        private float topFlangeThicknessField;

        private float bottomFlangeThicknessField;

        private float roundingRadius1Field;

        private float roundingRadius2Field;

        private float flangeSlopeField;

        private float outerDiameterField;

        private float innerDiameterField;

        private float farLegThicknessField;

        private float nearLegThicknessField;

        private decimal shapeTypeField;

        private float weightPerLengthField;

        /// <remarks/>
        public string ProfileID
        {
            get
            {
                return this.profileIDField;
            }
            set
            {
                this.profileIDField = value;
            }
        }

        /// <remarks/>
        public ushort Length
        {
            get
            {
                return this.lengthField;
            }
            set
            {
                this.lengthField = value;
            }
        }

        /// <remarks/>
        public string Profile
        {
            get
            {
                return this.profileField;
            }
            set
            {
                this.profileField = value;
            }
        }

        /// <remarks/>
        public float WebThickness
        {
            get
            {
                return this.webThicknessField;
            }
            set
            {
                this.webThicknessField = value;
            }
        }

        /// <remarks/>
        public float Thickness
        {
            get
            {
                return this.thicknessField;
            }
            set
            {
                this.thicknessField = value;
            }
        }

        /// <remarks/>
        public float Height
        {
            get
            {
                return this.heightField;
            }
            set
            {
                this.heightField = value;
            }
        }

        /// <remarks/>
        public float Width
        {
            get
            {
                return this.widthField;
            }
            set
            {
                this.widthField = value;
            }
        }

        /// <remarks/>
        public float TopFlangeThickness
        {
            get
            {
                return this.topFlangeThicknessField;
            }
            set
            {
                this.topFlangeThicknessField = value;
            }
        }

        /// <remarks/>
        public float BottomFlangeThickness
        {
            get
            {
                return this.bottomFlangeThicknessField;
            }
            set
            {
                this.bottomFlangeThicknessField = value;
            }
        }

        /// <remarks/>
        public float RoundingRadius1
        {
            get
            {
                return this.roundingRadius1Field;
            }
            set
            {
                this.roundingRadius1Field = value;
            }
        }

        /// <remarks/>
        public float RoundingRadius2
        {
            get
            {
                return this.roundingRadius2Field;
            }
            set
            {
                this.roundingRadius2Field = value;
            }
        }

        /// <remarks/>
        public float FlangeSlope
        {
            get
            {
                return this.flangeSlopeField;
            }
            set
            {
                this.flangeSlopeField = value;
            }
        }

        /// <remarks/>
        public float OuterDiameter
        {
            get
            {
                return this.outerDiameterField;
            }
            set
            {
                this.outerDiameterField = value;
            }
        }

        /// <remarks/>
        public float InnerDiameter
        {
            get
            {
                return this.innerDiameterField;
            }
            set
            {
                this.innerDiameterField = value;
            }
        }

        /// <remarks/>
        public float FarLegThickness
        {
            get
            {
                return this.farLegThicknessField;
            }
            set
            {
                this.farLegThicknessField = value;
            }
        }

        /// <remarks/>
        public float NearLegThickness
        {
            get
            {
                return this.nearLegThicknessField;
            }
            set
            {
                this.nearLegThicknessField = value;
            }
        }

        /// <remarks/>
        public decimal ShapeType
        {
            get
            {
                return this.shapeTypeField;
            }
            set
            {
                this.shapeTypeField = value;
            }
        }

        /// <remarks/>
        public float WeightPerLength
        {
            get
            {
                return this.weightPerLengthField;
            }
            set
            {
                this.weightPerLengthField = value;
            }
        }
    }

    /// <remarks/>
    [System.Serializable()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlType("RoundHole")]
    public partial class ShapeHole
    {

        private decimal absoluteRoundingNumberField;

        private ShapeHoleLocation locationField;

        private bool isEdgeHoleField;

        private byte directionField;

        private byte partLabelField;

        private string partSurfaceField;

        private string toolStringField;

        private string holeIDField;

        private ShapeHoleDesign designField;

        private string optionField;

        private float countersinkAngleField;

        private float countersinkHeadDepthField;

        private float backCountersinkAngleField;

        private float backCountersinkHeadDepthField;

        private byte diameterField;

        private bool diameterFieldSpecified;

        private float threadPitchField;

        private bool threadPitchFieldSpecified;

        private float xdimensionField;

        private bool xdimensionFieldSpecified;

        private float ydimensionField;

        private bool ydimensionFieldSpecified;

        private byte xdimentionField;

        private bool xdimentionFieldSpecified;

        private byte ydimentionField;

        private bool ydimentionFieldSpecified;

        private byte holeAngleField;

        private bool holeAngleFieldSpecified;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public ShapeHoleLocation Location
        {
            get
            {
                return this.locationField;
            }
            set
            {
                this.locationField = value;
            }
        }

        /// <remarks/>
        public bool IsEdgeHole
        {
            get
            {
                return this.isEdgeHoleField;
            }
            set
            {
                this.isEdgeHoleField = value;
            }
        }

        /// <remarks/>
        public byte Direction
        {
            get
            {
                return this.directionField;
            }
            set
            {
                this.directionField = value;
            }
        }

        /// <remarks/>
        public byte partLabel
        {
            get
            {
                return this.partLabelField;
            }
            set
            {
                this.partLabelField = value;
            }
        }

        /// <remarks/>
        public string partSurface
        {
            get
            {
                return this.partSurfaceField;
            }
            set
            {
                this.partSurfaceField = value;
            }
        }

        /// <remarks/>
        public string ToolString
        {
            get
            {
                return this.toolStringField;
            }
            set
            {
                this.toolStringField = value;
            }
        }

        /// <remarks/>
        public string HoleID
        {
            get
            {
                return this.holeIDField;
            }
            set
            {
                this.holeIDField = value;
            }
        }

        /// <remarks/>
        public ShapeHoleDesign Design
        {
            get
            {
                return this.designField;
            }
            set
            {
                this.designField = value;
            }
        }

        /// <remarks/>
        public string option
        {
            get
            {
                return this.optionField;
            }
            set
            {
                this.optionField = value;
            }
        }

        /// <remarks/>
        public float CountersinkAngle
        {
            get
            {
                return this.countersinkAngleField;
            }
            set
            {
                this.countersinkAngleField = value;
            }
        }

        /// <remarks/>
        public float CountersinkHeadDepth
        {
            get
            {
                return this.countersinkHeadDepthField;
            }
            set
            {
                this.countersinkHeadDepthField = value;
            }
        }

        /// <remarks/>
        public float BackCountersinkAngle
        {
            get
            {
                return this.backCountersinkAngleField;
            }
            set
            {
                this.backCountersinkAngleField = value;
            }
        }

        /// <remarks/>
        public float BackCountersinkHeadDepth
        {
            get
            {
                return this.backCountersinkHeadDepthField;
            }
            set
            {
                this.backCountersinkHeadDepthField = value;
            }
        }

        /// <remarks/>
        public byte Diameter
        {
            get
            {
                return this.diameterField;
            }
            set
            {
                this.diameterField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool DiameterSpecified
        {
            get
            {
                return this.diameterFieldSpecified;
            }
            set
            {
                this.diameterFieldSpecified = value;
            }
        }

        /// <remarks/>
        public float ThreadPitch
        {
            get
            {
                return this.threadPitchField;
            }
            set
            {
                this.threadPitchField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool ThreadPitchSpecified
        {
            get
            {
                return this.threadPitchFieldSpecified;
            }
            set
            {
                this.threadPitchFieldSpecified = value;
            }
        }

        /// <remarks/>
        public float Xdimension
        {
            get
            {
                return this.xdimensionField;
            }
            set
            {
                this.xdimensionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool XdimensionSpecified
        {
            get
            {
                return this.xdimensionFieldSpecified;
            }
            set
            {
                this.xdimensionFieldSpecified = value;
            }
        }

        /// <remarks/>
        public float Ydimension
        {
            get
            {
                return this.ydimensionField;
            }
            set
            {
                this.ydimensionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool YdimensionSpecified
        {
            get
            {
                return this.ydimensionFieldSpecified;
            }
            set
            {
                this.ydimensionFieldSpecified = value;
            }
        }

        /// <remarks/>
        public byte Xdimention
        {
            get
            {
                return this.xdimentionField;
            }
            set
            {
                this.xdimentionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool XdimentionSpecified
        {
            get
            {
                return this.xdimentionFieldSpecified;
            }
            set
            {
                this.xdimentionFieldSpecified = value;
            }
        }

        /// <remarks/>
        public byte Ydimention
        {
            get
            {
                return this.ydimentionField;
            }
            set
            {
                this.ydimentionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool YdimentionSpecified
        {
            get
            {
                return this.ydimentionFieldSpecified;
            }
            set
            {
                this.ydimentionFieldSpecified = value;
            }
        }

        /// <remarks/>
        public byte HoleAngle
        {
            get
            {
                return this.holeAngleField;
            }
            set
            {
                this.holeAngleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool HoleAngleSpecified
        {
            get
            {
                return this.holeAngleFieldSpecified;
            }
            set
            {
                this.holeAngleFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeHoleLocation
    {

        private float xField;

        private float yField;

        private float zField;

        private decimal absoluteRoundingNumberField;

        /// <remarks/>
        public float X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public float Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }

        /// <remarks/>
        public float Z
        {
            get
            {
                return this.zField;
            }
            set
            {
                this.zField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapeHoleDesign
    {

        private string designIDField;

        private string sourceField;

        private string unitsModeField;

        private string referenceOptionField;

        private string xenteredAsField;

        private string xenteredValueField;

        private string gageEnteredValueField;

        private string diameterEnteredValueField;

        private string ovalLengthEnteredValueField;

        private string ovalAngleEnteredValueField;

        private string rectangleLengthEnteredValueField;

        private string rectangleWidthEnteredValueField;

        private string rectangleAngleEnteredValueField;

        private object countersinkAngleEnteredValueField;

        private object countersinkHeadDepthEnteredValueField;

        private object backCountersinkAngleEnteredValueField;

        private object backCountersinkHeadDepthEnteredValueField;

        private string threadEnteredAsField;

        /// <remarks/>
        public string DesignID
        {
            get
            {
                return this.designIDField;
            }
            set
            {
                this.designIDField = value;
            }
        }

        /// <remarks/>
        public string Source
        {
            get
            {
                return this.sourceField;
            }
            set
            {
                this.sourceField = value;
            }
        }

        /// <remarks/>
        public string UnitsMode
        {
            get
            {
                return this.unitsModeField;
            }
            set
            {
                this.unitsModeField = value;
            }
        }

        /// <remarks/>
        public string ReferenceOption
        {
            get
            {
                return this.referenceOptionField;
            }
            set
            {
                this.referenceOptionField = value;
            }
        }

        /// <remarks/>
        public string XenteredAs
        {
            get
            {
                return this.xenteredAsField;
            }
            set
            {
                this.xenteredAsField = value;
            }
        }

        /// <remarks/>
        public string XenteredValue
        {
            get
            {
                return this.xenteredValueField;
            }
            set
            {
                this.xenteredValueField = value;
            }
        }

        /// <remarks/>
        public string GageEnteredValue
        {
            get
            {
                return this.gageEnteredValueField;
            }
            set
            {
                this.gageEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string DiameterEnteredValue
        {
            get
            {
                return this.diameterEnteredValueField;
            }
            set
            {
                this.diameterEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string OvalLengthEnteredValue
        {
            get
            {
                return this.ovalLengthEnteredValueField;
            }
            set
            {
                this.ovalLengthEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string OvalAngleEnteredValue
        {
            get
            {
                return this.ovalAngleEnteredValueField;
            }
            set
            {
                this.ovalAngleEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string RectangleLengthEnteredValue
        {
            get
            {
                return this.rectangleLengthEnteredValueField;
            }
            set
            {
                this.rectangleLengthEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string RectangleWidthEnteredValue
        {
            get
            {
                return this.rectangleWidthEnteredValueField;
            }
            set
            {
                this.rectangleWidthEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string RectangleAngleEnteredValue
        {
            get
            {
                return this.rectangleAngleEnteredValueField;
            }
            set
            {
                this.rectangleAngleEnteredValueField = value;
            }
        }

        /// <remarks/>
        public object CountersinkAngleEnteredValue
        {
            get
            {
                return this.countersinkAngleEnteredValueField;
            }
            set
            {
                this.countersinkAngleEnteredValueField = value;
            }
        }

        /// <remarks/>
        public object CountersinkHeadDepthEnteredValue
        {
            get
            {
                return this.countersinkHeadDepthEnteredValueField;
            }
            set
            {
                this.countersinkHeadDepthEnteredValueField = value;
            }
        }

        /// <remarks/>
        public object BackCountersinkAngleEnteredValue
        {
            get
            {
                return this.backCountersinkAngleEnteredValueField;
            }
            set
            {
                this.backCountersinkAngleEnteredValueField = value;
            }
        }

        /// <remarks/>
        public object BackCountersinkHeadDepthEnteredValue
        {
            get
            {
                return this.backCountersinkHeadDepthEnteredValueField;
            }
            set
            {
                this.backCountersinkHeadDepthEnteredValueField = value;
            }
        }

        /// <remarks/>
        public string ThreadEnteredAs
        {
            get
            {
                return this.threadEnteredAsField;
            }
            set
            {
                this.threadEnteredAsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapePopMark
    {

        private decimal absoluteRoundingNumberField;

        private string popMarkIDField;

        private bool is2DRepresentationField;

        private string popmarkSurfaceField;

        private byte directionField;

        private string optionField;

        private ShapePopMarkDesign designField;

        private byte pieceOfThePartLabelField;

        private ShapePopMarkLocation locationField;

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }

        /// <remarks/>
        public string PopMarkID
        {
            get
            {
                return this.popMarkIDField;
            }
            set
            {
                this.popMarkIDField = value;
            }
        }

        /// <remarks/>
        public bool Is2DRepresentation
        {
            get
            {
                return this.is2DRepresentationField;
            }
            set
            {
                this.is2DRepresentationField = value;
            }
        }

        /// <remarks/>
        public string PopmarkSurface
        {
            get
            {
                return this.popmarkSurfaceField;
            }
            set
            {
                this.popmarkSurfaceField = value;
            }
        }

        /// <remarks/>
        public byte Direction
        {
            get
            {
                return this.directionField;
            }
            set
            {
                this.directionField = value;
            }
        }

        /// <remarks/>
        public string Option
        {
            get
            {
                return this.optionField;
            }
            set
            {
                this.optionField = value;
            }
        }

        /// <remarks/>
        public ShapePopMarkDesign Design
        {
            get
            {
                return this.designField;
            }
            set
            {
                this.designField = value;
            }
        }

        /// <remarks/>
        public byte PieceOfThePartLabel
        {
            get
            {
                return this.pieceOfThePartLabelField;
            }
            set
            {
                this.pieceOfThePartLabelField = value;
            }
        }

        /// <remarks/>
        public ShapePopMarkLocation Location
        {
            get
            {
                return this.locationField;
            }
            set
            {
                this.locationField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapePopMarkDesign
    {

        private string designIDField;

        private bool isMachinePausedAfterMarkingField;

        private bool isMarkingASawCutField;

        /// <remarks/>
        public string DesignID
        {
            get
            {
                return this.designIDField;
            }
            set
            {
                this.designIDField = value;
            }
        }

        /// <remarks/>
        public bool IsMachinePausedAfterMarking
        {
            get
            {
                return this.isMachinePausedAfterMarkingField;
            }
            set
            {
                this.isMachinePausedAfterMarkingField = value;
            }
        }

        /// <remarks/>
        public bool IsMarkingASawCut
        {
            get
            {
                return this.isMarkingASawCutField;
            }
            set
            {
                this.isMarkingASawCutField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class ShapePopMarkLocation
    {

        private ushort xField;

        private decimal yField;

        private decimal zField;

        private decimal absoluteRoundingNumberField;

        /// <remarks/>
        public ushort X
        {
            get
            {
                return this.xField;
            }
            set
            {
                this.xField = value;
            }
        }

        /// <remarks/>
        public decimal Y
        {
            get
            {
                return this.yField;
            }
            set
            {
                this.yField = value;
            }
        }

        /// <remarks/>
        public decimal Z
        {
            get
            {
                return this.zField;
            }
            set
            {
                this.zField = value;
            }
        }

        /// <remarks/>
        public decimal AbsoluteRoundingNumber
        {
            get
            {
                return this.absoluteRoundingNumberField;
            }
            set
            {
                this.absoluteRoundingNumberField = value;
            }
        }
    }


}