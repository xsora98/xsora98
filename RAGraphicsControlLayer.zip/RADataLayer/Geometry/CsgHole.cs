﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlDeserialize.XmlProcedures;
using CSG.Sharp;
using System.Numerics;

namespace ShapeLibrary
{
    public class CsgHole
    {
        #region Variables
        public string holeType;
        public float locationX;
        public float locationY;
        public float locationZ;
        public string partSurface;
        public float diameter;
        public float xDim;
        public float yDim;
        public float xDimt;
        public float yDimt;
        public float angle;
        #endregion

        #region Constructors

        /// <summary>
        /// Initialize hole data.
        /// </summary>
        /// <param name="hole">Hole data from XML3D</param>
        /// <param name="holeType">Hole type. Can be RoundHole, SquareHole, ObroundHole</param>
        public CsgHole(ShapeHole hole, string holeType)
        {
            this.holeType = holeType;
            this.locationX = hole.Location.X;
            this.locationY = hole.Location.Y;
            this.locationZ = hole.Location.Z;
            this.partSurface = hole.partSurface;
            this.diameter = hole.Diameter;
            this.xDim = hole.Xdimension;
            this.yDim = hole.Ydimension;
            this.angle = hole.HoleAngle;

            switch (holeType)
            {
                case "RoundHole":
                    this.holeType = holeType;
                    this.locationX = hole.Location.X;
                    this.locationY = hole.Location.Y;
                    this.locationZ = hole.Location.Z;
                    this.partSurface = hole.partSurface;
                    this.diameter = hole.Diameter;
                    break;
                case "SquareHole":
                    this.holeType = holeType;
                    this.locationX = hole.Location.X;
                    this.locationY = hole.Location.Y;
                    this.locationZ = hole.Location.Z;
                    this.partSurface = hole.partSurface;
                    this.xDim = hole.Xdimension;
                    this.yDim = hole.Ydimension;
                    this.angle = hole.HoleAngle;
                    break;
                case "ObroundHole":
                    this.holeType = holeType;
                    this.locationX = hole.Location.X;
                    this.locationY = hole.Location.Y;
                    this.locationZ = hole.Location.Z;
                    this.partSurface = hole.partSurface;
                    this.xDimt = hole.Xdimention;
                    this.yDimt = hole.Ydimention;
                    this.angle = hole.HoleAngle;
                    break;

            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Generate hole solid.
        /// </summary>
        /// <param name="holeType">Hole type. Can be RoundHole, SquareHole, ObroundHole.</param>
        /// <param name="csgSolid">The solid where the hole is done.</param>
        /// <returns></returns>
        public CSG.Sharp.CSG GenerateHole(string holeType, CsgSolid csgSolid)
        {
            CSG.Sharp.CSG hole = new CSG.Sharp.CSG();
            CSG.Sharp.CSG hole2 = new CSG.Sharp.CSG();
            CSG.Sharp.CSG hole3 = new CSG.Sharp.CSG();
            Polygon[] holePoly;
            var polyList = new List<Polygon>();
            switch (holeType)
            {
                case "RoundHole":
                    if (csgSolid.partName == "Web" || csgSolid.partName == "Underside")
                    {
                        hole = Cylinder.Create(startV: new Vector(0, -csgSolid.thickness - 0.1f, 0), endV: new Vector(0, csgSolid.thickness + 0.1f, 0), radius: diameter / 2);
                        holePoly = hole.ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x + csgSolid.vOrigin.X + this.locationY, (float)vertices[j].Pos.y + csgSolid.vOrigin.Y, (float)vertices[j].Pos.z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    if (csgSolid.partName == "TopFlange" || csgSolid.partName == "BottomFlange")
                    {
                        hole = Cylinder.Create(startV: new Vector(0, -csgSolid.widthOrHeight - 0.1f, 0), endV: new Vector(0, csgSolid.widthOrHeight + 0.1f, 0), radius: diameter / 2);
                        holePoly = hole.ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x, (float)vertices[j].Pos.y, (float)vertices[j].Pos.z);
                                x = Vector3.Transform(x, Matrix4x4.CreateRotationZ((float)((Math.PI / 180) * 90)));
                                x = new Vector3(x.X + csgSolid.vOrigin.X, x.Y + csgSolid.vOrigin.Y + this.locationZ, x.Z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    break;
                case "SquareHole":
                    if (csgSolid.partName == "Web" || csgSolid.partName == "Underside")
                    {
                        hole = Cube.Create(new Vector(0, 0, 0), this.yDim / 2, csgSolid.thickness + 0.1f, this.xDim / 2);
                        holePoly = hole.ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x, (float)vertices[j].Pos.y, (float)vertices[j].Pos.z);
                                if (this.angle > 0)
                                {
                                    x = Vector3.Transform(x, Matrix4x4.CreateRotationY((float)((Math.PI / 180) * -this.angle)));
                                }
                                x = new Vector3(x.X + csgSolid.vOrigin.X + this.locationY, x.Y + csgSolid.vOrigin.Y, x.Z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    if (csgSolid.partName == "TopFlange" || csgSolid.partName == "BottomFlange")
                    {
                        hole = Cube.Create(new Vector(0, 0, 0), csgSolid.widthOrHeight + 0.1f, this.yDim / 2, this.xDim / 2);
                        holePoly = hole.ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x, (float)vertices[j].Pos.y, (float)vertices[j].Pos.z);
                                if (this.angle > 0)
                                {
                                    x = Vector3.Transform(x, Matrix4x4.CreateRotationX((float)((Math.PI / 180) * -this.angle)));
                                }
                                x = new Vector3(x.X + csgSolid.vOrigin.X, x.Y + csgSolid.vOrigin.Y + this.locationZ, x.Z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    break;
                case "ObroundHole":

                    var sw = 0;
                    if (csgSolid.partName == "Web" || csgSolid.partName == "Underside")
                    {

                        if (this.xDimt > this.yDimt)
                        {
                            hole = Cube.Create(new Vector(0, 0, 0), this.yDimt / 2, csgSolid.thickness + 0.2f, this.xDimt / 2 - (this.xDimt - this.yDimt) / 2);
                            hole2 = Cylinder.Create(new Vector(0, -csgSolid.thickness - 0.1f, -this.yDimt / 2), new Vector(0, csgSolid.thickness + 0.1f, -this.yDimt / 2), this.yDimt / 2);
                            hole3 = Cylinder.Create(new Vector(0, -csgSolid.thickness - 0.1f, this.yDimt / 2), new Vector(0, csgSolid.thickness + 0.1f, this.yDimt / 2), this.yDimt / 2);
                        }
                        else if (this.xDimt < this.yDimt)
                        {
                            hole = Cube.Create(new Vector(0, 0, 0), this.yDimt / 2 - (this.yDimt - this.xDimt) / 2, csgSolid.thickness + 0.2f, this.xDimt / 2);
                            hole2 = Cylinder.Create(new Vector(-this.xDimt / 2, -csgSolid.thickness - 0.1f, 0), new Vector(-this.xDimt / 2, csgSolid.thickness + 0.1f, 0), this.xDimt / 2);
                            hole3 = Cylinder.Create(new Vector(this.xDimt / 2, -csgSolid.thickness - 0.1f, 0), new Vector(this.xDimt / 2, csgSolid.thickness + 0.1f, 0), this.xDimt / 2);
                        }
                        else
                        {
                            sw = 1;
                        }
                        if (sw == 0)
                            holePoly = hole.Union(hole2).Union(hole3).ToPolygons();
                        else
                            holePoly = Cylinder.Create(new Vector(0, -csgSolid.thickness - 0.1f, 0), new Vector(0, csgSolid.thickness + 0.1f, 0), this.xDimt / 2).ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x, (float)vertices[j].Pos.y, (float)vertices[j].Pos.z);
                                if (this.angle > 0)
                                {
                                    x = Vector3.Transform(x, Matrix4x4.CreateRotationY((float)((Math.PI / 180) * -this.angle)));
                                }
                                x = new Vector3(x.X + csgSolid.vOrigin.X + this.locationY, x.Y + csgSolid.vOrigin.Y, x.Z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    if (csgSolid.partName == "TopFlange" || csgSolid.partName == "BottomFlange")
                    {
                        if (this.xDimt > this.yDimt)
                        {
                            hole = Cube.Create(new Vector(0, 0, 0), this.yDimt / 2, csgSolid.widthOrHeight + 0.2f, this.xDimt / 2 - (this.xDimt - this.yDimt) / 2);
                            hole2 = Cylinder.Create(new Vector(0, -csgSolid.widthOrHeight - 0.1f, -this.yDimt / 2), new Vector(0, csgSolid.widthOrHeight + 0.1f, -this.yDimt / 2), this.yDimt / 2, slices: 64);
                            hole3 = Cylinder.Create(new Vector(0, -csgSolid.widthOrHeight - 0.1f, this.yDimt / 2), new Vector(0, csgSolid.widthOrHeight + 0.1f, this.yDimt / 2), this.yDimt / 2, slices: 64);
                        }
                        else if (this.xDimt < this.yDimt)
                        {
                            hole = Cube.Create(new Vector(0, 0, 0), this.yDimt / 2 - (this.yDimt - this.xDimt) / 2, csgSolid.widthOrHeight + 0.2f, this.xDimt / 2);
                            hole2 = Cylinder.Create(new Vector(-this.xDimt / 2, -csgSolid.widthOrHeight - 0.1f, 0), new Vector(-this.xDimt / 2, csgSolid.widthOrHeight + 0.1f, 0), this.xDimt / 2, slices: 64);
                            hole3 = Cylinder.Create(new Vector(this.xDimt / 2, -csgSolid.widthOrHeight - 0.1f, 0), new Vector(this.xDimt / 2, csgSolid.widthOrHeight + 0.1f, 0), this.xDimt / 2, slices: 64);
                        }
                        else
                        {
                            sw = 1;
                        }
                        if (sw == 0)
                            holePoly = hole.Union(hole2).Union(hole3).ToPolygons();
                        else
                            holePoly = Cylinder.Create(new Vector(0, -csgSolid.widthOrHeight - 0.1f, 0), new Vector(0, csgSolid.widthOrHeight + 0.1f, 0), this.xDimt / 2).ToPolygons();
                        holePoly = hole.Union(hole2).Union(hole3).ToPolygons();
                        for (int i = 0; i < holePoly.Length; i++)
                        {
                            var vertices = holePoly[i].Vertices;
                            for (int j = 0; j < vertices.Length; j++)
                            {
                                var x = new Vector3((float)vertices[j].Pos.x, (float)vertices[j].Pos.y, (float)vertices[j].Pos.z);
                                x = Vector3.Transform(x, Matrix4x4.CreateRotationZ((float)((Math.PI / 180) * 90)));
                                if (this.angle > 0)
                                {
                                    x = Vector3.Transform(x, Matrix4x4.CreateRotationX((float)((Math.PI / 180) * this.angle)));
                                }
                                x = new Vector3(x.X + csgSolid.vOrigin.X, x.Y + csgSolid.vOrigin.Y + this.locationZ, x.Z + csgSolid.vOrigin.Z + csgSolid.length - this.locationX);
                                var x_n = Vector3.Normalize(x);
                                vertices[j] = new CSG.Sharp.Vertex(new Vector(x.X, x.Y, x.Z), new Vector(x_n.X, x_n.Y, x_n.Z));
                            }
                            polyList.Add(new Polygon(vertices));
                        }
                        hole = CSG.Sharp.CSG.FromPolygons(polyList.ToArray());
                    }
                    break;
            }
            return hole;
        }
        #endregion
    }

    public class HoleData
    {
        #region Variables
        public List<CsgHole> holesList = new List<CsgHole>();
        #endregion

        #region Constructors
        /// <summary>
        /// Hole data initialize.
        /// </summary>
        public HoleData()
        {
            var shapeData = XmlContainer.shapeQueue[XmlContainer.shapeQueue.Count - 1].HolesInAPart;
            if (shapeData != null)
                InitData(shapeData);
        }
        #endregion

        #region Methods
        /// <summary>
        /// Create holes list with specific hole type.
        /// </summary>
        /// <param name="holesData">Hole data array</param>
        public void InitData(ShapeHole[] holesData)
        {
            for (int i = 0; i < holesData.Length; i++)
            {
                if (holesData[i].Diameter > 0 && holesData[i].Xdimension == 0 && holesData[i].Xdimention == 0)
                    this.holesList.Add(new CsgHole(holesData[i], "RoundHole"));
                if (holesData[i].Xdimension > 0 && holesData[i].Diameter == 0 && holesData[i].Xdimention == 0)
                    this.holesList.Add(new CsgHole(holesData[i], "SquareHole"));
                if (holesData[i].Xdimention > 0 && holesData[i].Xdimension == 0 && holesData[i].Diameter == 0)
                    this.holesList.Add(new CsgHole(holesData[i], "ObroundHole"));
            }
        }
        #endregion

    }
}
