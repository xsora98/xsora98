﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using LibTessDotNet;
using RADataLayer.Geometry;

namespace ShapeLibrary
{
    public class Solid
    {
        #region// Storage

        private List<Triangle> triangles;
        public List<Triangle> Triangles { get { return triangles; } private set { this.triangles = Triangles; } }

        public List<Line> contourLines;

        public List<Plane> listSolidPlanes = new List<Plane>();

        public List<Vector3> trianglesList = new List<Vector3>();

        public List<float> colorList = new List<float>();

        public static readonly Vector3 DirectionX = new Vector3(1, 0, 0);
        public static readonly Vector3 DirectionY = new Vector3(0, 1, 0);
        public static readonly Vector3 DirectionZ = new Vector3(0, 0, 1);

        public static readonly Vector3 ORIGIN = new Vector3(0, 0, 0);


        #endregion

        #region //Constructor

        public Solid() { }
        public Solid(List<Triangle> triangleList)
        {
            triangles = triangleList;
        }

        #endregion

        #region //GenerateSolids

        private List<Triangle> GenerateTrianglesFromSolidPoints(List<Vertex> vertices)
        {
            throw new NotImplementedException();
        }

        private List<Line> GenerateContourLinesFromSolidPoints(List<Vertex> vertices)
        {
            throw new NotImplementedException();

        }
        public void GenerateSolidPlanes(float fWidthOrHeight, float fThickness, float fLength, Vector3 vDirWidthHeight, Vector3 vDirThickess, Vector3 vDirLength, Vector3 vOrigin, string partName)
        {
            listSolidPlanes = new List<Plane>();
            var lstFront = new List<Vector3>();
            var lstBack = new List<Vector3>();
            //calculate distance vectors 
            Vector3 vWidthHeight = vDirWidthHeight * fWidthOrHeight;
            Vector3 vThick = vDirThickess * fThickness;
            Vector3 vLength = vDirLength * fLength;

            //calculate front points
            Vector3 planeFront1 = new Vector3(vOrigin.X, vOrigin.Y, vOrigin.Z);
            lstFront.Add(planeFront1);
            Vector3 planeFront2 = vOrigin + vLength;
            lstFront.Add(planeFront2);
            Vector3 planeFront3 = vOrigin + vLength + vWidthHeight;
            lstFront.Add(planeFront3);
            Vector3 planeFront4 = vOrigin + vWidthHeight;
            lstFront.Add(planeFront4);
            lstFront.Add(planeFront1);

            Plane planeFront = new Plane(planeFront1, planeFront2, planeFront3, planeFront4, planeFront1.Z, partName);

            //calculate back points points 
            Vector3 planeBack1 = planeFront1 + vThick;
            lstBack.Add(planeBack1);
            Vector3 planeBack2 = planeFront2 + vThick;
            lstBack.Add(planeBack2);
            Vector3 planeBack3 = planeFront3 + vThick;
            lstBack.Add(planeBack3);
            Vector3 planeBack4 = planeFront4 + vThick;
            lstBack.Add(planeBack4);
            lstBack.Add(planeBack1);

            Plane planeBack = new Plane(planeBack1, planeBack2, planeBack3, planeBack4, planeBack1.Z, partName);

            listSolidPlanes.Add(planeFront);
            listSolidPlanes.Add(planeBack);

            int nIndexPrevPoint = 3;
            for (int nIndexPoint = 0; nIndexPoint < 4; nIndexPoint++)
            {
                listSolidPlanes.Add(new Plane(lstFront[nIndexPrevPoint], lstBack[nIndexPrevPoint], lstBack[nIndexPoint], lstFront[nIndexPoint], lstFront[nIndexPrevPoint].Z, partName));

                nIndexPrevPoint = nIndexPoint;
            }
            var holesList = new HoleData();
            //Calling Tesselateion function
            if (holesList.holesList.Count == 0) 
                Tesselate(listSolidPlanes);
            //else
                //TesselateWithHoles(listSolidPlanes, holesList, fWidthOrHeight, fLength, fThickness, vOrigin);

            #endregion
        }

        public void Tesselate(List<Plane> planes)
        {
            Tess tess = new Tess();
            foreach (Plane plane in planes)
            {
                var v = new ContourVertex[4];
                v[0].Position = new Vec3(plane.firstPoint.X, plane.firstPoint.Y, plane.firstPoint.Z);
                v[1].Position = new Vec3(plane.secondPoint.X, plane.secondPoint.Y, plane.secondPoint.Z);
                v[2].Position = new Vec3(plane.thirdPoint.X, plane.thirdPoint.Y, plane.thirdPoint.Z);
                v[3].Position = new Vec3(plane.fourthPoint.X, plane.fourthPoint.Y, plane.fourthPoint.Z);
                tess.AddContour(v, ContourOrientation.Original);
                tess.Tessellate(WindingRule.EvenOdd, ElementType.Polygons, 3);
                for (int i = 0; i < tess.ElementCount; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int index = tess.Elements[i * 3 + j];
                        if (index == -1)
                            continue;   
                        trianglesList.Add(new Vector3(tess.Vertices[index].Position.X, tess.Vertices[index].Position.Y, tess.Vertices[index].Position.Z));
                        colorList.Add(1.0f);
                        colorList.Add(0.0f);
                        colorList.Add(1.0f);
                    }
                }
            }

        }

        /*public void TesselateWithHoles(List<Plane> planes, HoleData holes, float widthOrHeight, float length, float depth, Vector3 Origin)
        {
            List<Tuple<string, ContourVertex[], ContourVertex[],ContourVertex[]>> tupleList = new List<Tuple<string, ContourVertex[], ContourVertex[],ContourVertex[]>>();
            foreach (Hole hole in holes.holes)
            {
                tupleList.Add(GenerateSquareHoles(hole, widthOrHeight, length, depth, Origin));
            }
            var v3 = new ContourVertex[4];
            var v4 = new ContourVertex[4];
            Tess tess = new Tess();
            foreach (Plane plane in planes)
            {
                var sw=0;
                var v = new ContourVertex[4];
                v[0].Position = new Vec3(plane.firstPoint.X, plane.firstPoint.Y, plane.firstPoint.Z);
                v[1].Position = new Vec3(plane.secondPoint.X, plane.secondPoint.Y, plane.secondPoint.Z);
                v[2].Position = new Vec3(plane.thirdPoint.X, plane.thirdPoint.Y, plane.thirdPoint.Z);
                v[3].Position = new Vec3(plane.fourthPoint.X, plane.fourthPoint.Y, plane.fourthPoint.Z);
                tess.AddContour(v, ContourOrientation.Original);
                List<Vector3> planePoints = new List<Vector3>()
                {
                    plane.firstPoint,
                    plane.secondPoint,
                    plane.thirdPoint,
                    plane.fourthPoint
                };
                switch (plane.partName)
                {
                    case "TopFlange":
                        foreach (Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> tuple in tupleList)
                        {
                            
                            if (plane.orientation == "XZ" && tuple.Item1 == "TopFlange" && tuple.Item2[0].Position.X == plane.firstPoint.X)
                                tess.AddContour(tuple.Item2, ContourOrientation.Clockwise);
                            if (plane.orientation == "XZ" && tuple.Item1 == "TopFlange" && tuple.Item3[0].Position.X == plane.firstPoint.X)
                                tess.AddContour(tuple.Item3, ContourOrientation.Clockwise);
                            if (plane.orientation == "XY" && tuple.Item1 == "TopFlange" && tuple.Item4.Length > 0 )
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                            if (plane.orientation == "YZ" && tuple.Item1 == "TopFlange" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Y == outer[i].Position.Y)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Y == outer[i].Position.Y)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                                
                            }
                        }
                        break;
                    case "Web":
                        
                        foreach (Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> tuple in tupleList)
                        {
                            if (plane.orientation == "YZ" && tuple.Item1 == "Web" && tuple.Item2[0].Position.Y == plane.firstPoint.Y)
                                tess.AddContour(tuple.Item2, ContourOrientation.Clockwise);
                            if (plane.orientation == "YZ" && tuple.Item1 == "Web" && tuple.Item3[0].Position.Y == plane.firstPoint.Y)
                                tess.AddContour(tuple.Item3, ContourOrientation.Clockwise);
                            if (plane.orientation == "XY" && tuple.Item1 == "Web" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                            if (plane.orientation == "XZ" && tuple.Item1 == "Web" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.X == outer[i].Position.X)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.X == outer[i].Position.X)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                        }
                        break;
                    case "Underside":
                        foreach (Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> tuple in tupleList)
                        {
                            if (plane.orientation == "YZ" && tuple.Item1 == "Underside" && tuple.Item2[0].Position.Y == plane.firstPoint.Y)
                                tess.AddContour(tuple.Item2, ContourOrientation.Clockwise);
                            if (plane.orientation == "YZ" && tuple.Item1 == "Underside" && tuple.Item3[0].Position.Y == plane.firstPoint.Y)
                                tess.AddContour(tuple.Item3, ContourOrientation.Clockwise);
                            if (plane.orientation == "XY" && tuple.Item1 == "Underside" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                            if (plane.orientation == "XZ" && tuple.Item1 == "Underside" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.X == outer[i].Position.X)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.X == outer[i].Position.X)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                        }
                        break;
                    case "BottomFlange":
                        foreach (Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> tuple in tupleList)
                        {
                            if (plane.orientation == "XZ" && tuple.Item1 == "BottomFlange" && tuple.Item2[0].Position.X == plane.firstPoint.X)
                                tess.AddContour(tuple.Item2, ContourOrientation.Clockwise);
                            if (plane.orientation == "XZ" && tuple.Item1 == "BottomFlange" && tuple.Item3[0].Position.X == plane.firstPoint.X)
                                tess.AddContour(tuple.Item3, ContourOrientation.Clockwise);
                            if (plane.orientation == "XY" && tuple.Item1 == "BottomFlange" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Z == outer[i].Position.Z)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }
                            }
                            if (plane.orientation == "YZ" && tuple.Item1 == "BottomFlange" && tuple.Item4.Length > 0)
                            {
                                var outer = OuterContour(tuple.Item4, plane);
                                var cond = 0;
                                var cond2 = 0;
                                if (outer.Length > 0)
                                {
                                    for (int i = 0; i < outer.Length; i++)
                                    {
                                        if (!planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Y == outer[i].Position.Y)
                                            cond = 1;
                                        if (planePoints.Contains(new Vector3(outer[i].Position.X, outer[i].Position.Y, outer[i].Position.Z)) && plane.firstPoint.Y == outer[i].Position.Y)
                                            cond2++;
                                    }
                                    if (cond == 1)
                                        tess.AddContour(OuterContour(tuple.Item4, plane), ContourOrientation.Clockwise);
                                    if (cond2 == 4)
                                        tess = new Tess();
                                }

                            }
                        }
                        break;
                }

                tess.Tessellate(WindingRule.EvenOdd, ElementType.Polygons, 3);
                for (int i = 0; i < tess.ElementCount; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int index = tess.Elements[i * 3 + j];
                        if (index == -1)
                            continue;
                        trianglesList.Add(new Vector3(tess.Vertices[index].Position.X, tess.Vertices[index].Position.Y, tess.Vertices[index].Position.Z));
                        colorList.Add(1.0f);
                        colorList.Add(0.0f);
                        colorList.Add(1.0f);

                    }
                }
            }

        }*/

        public List<float> GetTriangleArray()
        {
            List<float> list = new List<float>();

            foreach (Vector3 vec in trianglesList)
            {
                list.Add(vec.X);
                list.Add(vec.Y);
                list.Add(vec.Z);
            }

            return list;
        }

        public Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> GenerateHoles(Hole hole, float widthOrHeight, float length, float depth, Vector3 Origin)
        {
            List<Vec3> holesContour = new List<Vec3>();
            List<Vec3> holesContour2 = new List<Vec3>();
            List<Vec3> externalContour = new List<Vec3>();
            List<Vec3> externalContour2 = new List<Vec3>();

            switch (hole.partSurface)
            {
                case "TopFlange":
                    for (double angle = 0.0; angle <= 2 * Math.PI; angle += (2 * Math.PI) / 50)
                    {
                        var vec = new Vec3(Origin.X, (float)(Math.Cos(angle) * hole.diameter / 2) + widthOrHeight / 2 + hole.locationZ + Origin.Y, (float)(-Math.Sin(angle) * hole.diameter / 2) + hole.locationX);
                        if (vec.Y >= Origin.Y && vec.Y <= Origin.Y + widthOrHeight && vec.Z >= Origin.Z && vec.Z <= Origin.Z + length)
                        {
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                        }
                        else
                        {
                            vec = DelimitateContour("TopFlange", Origin.Y + widthOrHeight, Origin.Z + length, vec, Origin);
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                            externalContour.Add(vec);
                            externalContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                        }

                    }
                    break;
                case "Web":
                    for (double angle = 0.0; angle <= 2 * Math.PI; angle += (2 * Math.PI) / 50)
                    {
                        var vec = new Vec3((float)(Math.Cos(angle) * hole.diameter / 2) + Origin.X + widthOrHeight / 2 + hole.locationY, Origin.Y, (float)(-Math.Sin(angle) * hole.diameter / 2) + hole.locationX);
                        if (vec.X >= Origin.X && vec.X <= Origin.X+widthOrHeight && vec.Z >= Origin.Z && vec.Z <= Origin.Z+length)
                        {
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X, vec.Y + depth, vec.Z));
                        }
                        else
                        {
                            vec = DelimitateContour("Web", Origin.X + widthOrHeight, Origin.Z + length, vec, Origin);
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X, vec.Y + depth, vec.Z));
                            externalContour.Add(vec);
                            externalContour2.Add(new Vec3(vec.X , vec.Y+depth, vec.Z));
                        }
                    }
                    break;
                case "Underside":
                    for (double angle = 0.0; angle <= 2 * Math.PI; angle += (2 * Math.PI) / 50)
                    {
                        var vec = new Vec3((float)(Math.Cos(angle) * hole.diameter / 2) + Origin.X + widthOrHeight / 2 + hole.locationY, Origin.Y, (float)(-Math.Sin(angle) * hole.diameter / 2) + hole.locationX);
                        if (vec.X >= Origin.X && vec.X <= Origin.X + widthOrHeight && vec.Z >= Origin.Z && vec.Z <= Origin.Z + length)
                        {
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X, vec.Y + depth, vec.Z));
                        }
                        else
                        {
                            vec = DelimitateContour("Underside", Origin.X + widthOrHeight, Origin.Z + length, vec, Origin);
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X, vec.Y + depth, vec.Z));
                            externalContour.Add(vec);
                            externalContour2.Add(new Vec3(vec.X, vec.Y + depth, vec.Z));
                        }
                    }
                    break;
                case "BottomFlange":
                    for (double angle = 0.0; angle <= 2 * Math.PI; angle += (2 * Math.PI) / 50)
                    {
                        var vec = new Vec3(Origin.X, (float)(Math.Cos(angle) * hole.diameter / 2) + widthOrHeight / 2 + hole.locationZ + Origin.Y, (float)(-Math.Sin(angle) * hole.diameter / 2) + hole.locationX);
                        if (vec.Y >= Origin.Y && vec.Y <= Origin.Y+widthOrHeight && vec.Z >= Origin.Z && vec.Z <= Origin.Y+length)
                        {
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                        }
                        else
                        {
                            vec = DelimitateContour("BottomFlange", Origin.Y+widthOrHeight, Origin.Z+length, vec, Origin);
                            holesContour.Add(vec);
                            holesContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                            externalContour.Add(vec);
                            externalContour2.Add(new Vec3(vec.X + depth, vec.Y, vec.Z));
                        }

                    }
                    break;
            }
            
            var v1 = new ContourVertex[holesContour.Count];
            var v2 = new ContourVertex[holesContour2.Count];
            for (int i = 0; i < holesContour.Count; i++)
            {
                v1[i].Position = holesContour[i];
                v2[i].Position = holesContour2[i];
            }

            ContourVertex[] v3 ;
            if (externalContour.Count > 0)
            {
                v3 = new ContourVertex[externalContour.Count * 2 - 1];
                var index = 0;
                for (int i = 0; i < externalContour.Count; i++)
                {
                    v3[index].Position = externalContour[i];
                    index++;
                }
                for (int i = externalContour2.Count - 1; i > 0; i--)
                {
                    v3[index].Position = externalContour2[i];
                    index++;
                }

            }
            else
            {
                v3 = new ContourVertex[0];
            }
            return Tuple.Create(hole.partSurface, v1, v2, v3);
        }

        public Tuple<string, ContourVertex[], ContourVertex[], ContourVertex[]> GenerateSquareHoles(Hole hole, float widthOrHeight, float length, float depth, Vector3 Origin)
        {
            List<Vec3> holesContour = new List<Vec3>();
            List<Vec3> holesContour2 = new List<Vec3>();
            List<Vec3> externalContour = new List<Vec3>();
            List<Vec3> externalContour2 = new List<Vec3>();
            List<Vec3> contour = new List<Vec3>();
            List<Vec3> holePoints = new List<Vec3>();
            switch (hole.partSurface)
            {
                
                case "TopFlange":
                    contour.Add(new Vec3(0,  hole.yDim / 2 ,  hole.xDim / 2));
                    contour.Add(new Vec3(0,  - hole.yDim / 2 ,  hole.xDim / 2));
                    contour.Add(new Vec3(0,  - hole.yDim / 2 , - hole.xDim / 2));
                    contour.Add(new Vec3(0,  hole.yDim / 2 ,  - hole.xDim / 2));
                    for(int i = 0; i < contour.Count-1; i++)
                    {
                        holePoints.Add(contour[i]);
                        holePoints.AddRange(GeneratePoints(contour[i], contour[i + 1],hole.partSurface));
                    }
                    holePoints.Add(contour[contour.Count-1]);
                    holePoints.AddRange(GeneratePoints(contour[contour.Count - 1], contour[0], hole.partSurface));
                    for (int i=0;i<holePoints.Count;i++)
                    {
                        var vec = new Vector3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z);
                        if (hole.angle > 0)
                        { 
                            vec = Vector3.Transform(vec, Matrix4x4.CreateRotationX((float)((Math.PI / 180) * -hole.angle)));
                            holePoints[i] = new Vec3(vec.X+ Origin.X, vec.Y+Origin.Y + widthOrHeight / 2+ hole.locationZ, vec.Z +Origin.Z + hole.locationX);
                        }
                        else
                        {
                            holePoints[i] = new Vec3(vec.X + Origin.X, vec.Y + Origin.Y + widthOrHeight / 2 + hole.locationZ, vec.Z + Origin.Z + hole.locationX);
                        }
                        if (holePoints[i].Y >= Origin.Y && holePoints[i].Y <= Origin.Y + widthOrHeight && holePoints[i].Z >= Origin.Z && holePoints[i].Z <= Origin.Z + length)
                        {
                            holesContour.Add(new Vec3(holePoints[i].X , holePoints[i].Y, holePoints[i].Z));
                            holesContour2.Add(new Vec3(holePoints[i].X + depth, holePoints[i].Y, holePoints[i].Z));
                        }
                        else
                        {
                            var vec2 = DelimitateContour("TopFlange", Origin.Y + widthOrHeight, Origin.Z + length, new Vec3(holePoints[i].X , holePoints[i].Y, holePoints[i].Z), Origin);
                            holesContour.Add(vec2);
                            holesContour2.Add(new Vec3(vec2.X + depth, vec2.Y, vec2.Z));
                            externalContour.Add(vec2);
                            externalContour2.Add(new Vec3(vec2.X + depth, vec2.Y, vec2.Z));
                        }


                    }
                    break;
                case "Web":
                    contour.Add(new Vec3(hole.yDim / 2,0 , hole.xDim / 2));
                    contour.Add(new Vec3(-hole.yDim / 2, 0, hole.xDim / 2));
                    contour.Add(new Vec3(-hole.yDim / 2, 0, -hole.xDim / 2));
                    contour.Add(new Vec3(hole.yDim / 2, 0, -hole.xDim / 2));
                    for (int i = 0; i < contour.Count - 1; i++)
                    {
                        holePoints.Add(contour[i]);
                        holePoints.AddRange(GeneratePoints(contour[i], contour[i + 1], hole.partSurface));
                    }
                    holePoints.Add(contour[contour.Count - 1]);
                    holePoints.AddRange(GeneratePoints(contour[contour.Count - 1], contour[0], hole.partSurface));
                    for (int i = 0; i < holePoints.Count; i++)
                    {
                        var vec = new Vector3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z);
                        if (hole.angle > 0)
                        {
                            vec = Vector3.Transform(vec, Matrix4x4.CreateRotationY((float)((Math.PI / 180) * hole.angle)));
                            holePoints[i] = new Vec3(vec.X + Origin.X + hole.locationY + widthOrHeight / 2, vec.Y + Origin.Y  , vec.Z + Origin.Z + hole.locationX);
                        }
                        else
                        {
                            holePoints[i] = new Vec3(vec.X + Origin.X + hole.locationY + widthOrHeight / 2, vec.Y + Origin.Y  , vec.Z + Origin.Z + hole.locationX);
                        }
                        if (holePoints[i].X >= Origin.X && holePoints[i].X <= Origin.X + widthOrHeight && holePoints[i].Z >= Origin.Z && holePoints[i].Z <= Origin.Z + length)
                        {
                            holesContour.Add(new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z));
                            holesContour2.Add(new Vec3(holePoints[i].X , holePoints[i].Y + depth, holePoints[i].Z));
                        }
                        else
                        {
                            var vec2 = DelimitateContour("Web", Origin.X + widthOrHeight, Origin.Z + length, new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z), Origin);
                            holesContour.Add(vec2);
                            holesContour2.Add(new Vec3(vec2.X , vec2.Y + depth, vec2.Z));
                            externalContour.Add(vec2);
                            externalContour2.Add(new Vec3(vec2.X , vec2.Y + depth, vec2.Z));
                        }
                    }
                    break;
                case "Underside":
                    contour.Add(new Vec3(hole.yDim / 2, 0, hole.xDim / 2));
                    contour.Add(new Vec3(-hole.yDim / 2, 0, hole.xDim / 2));
                    contour.Add(new Vec3(-hole.yDim / 2, 0, -hole.xDim / 2));
                    contour.Add(new Vec3(hole.yDim / 2, 0, -hole.xDim / 2));
                    for (int i = 0; i < contour.Count - 1; i++)
                    {
                        holePoints.Add(contour[i]);
                        holePoints.AddRange(GeneratePoints(contour[i], contour[i + 1], hole.partSurface));
                    }
                    holePoints.Add(contour[contour.Count - 1]);
                    holePoints.AddRange(GeneratePoints(contour[contour.Count - 1], contour[0], hole.partSurface));
                    for (int i = 0; i < holePoints.Count; i++)
                    {
                        var vec = new Vector3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z);
                        if (hole.angle > 0)
                        {
                            vec = Vector3.Transform(vec, Matrix4x4.CreateRotationY((float)((Math.PI / 180) * hole.angle)));
                            holePoints[i] = new Vec3(vec.X + Origin.X + hole.locationY + widthOrHeight / 2, vec.Y + Origin.Y, vec.Z + Origin.Z + hole.locationX);
                        }
                        else
                        {
                            holePoints[i] = new Vec3(vec.X + Origin.X + hole.locationY + widthOrHeight / 2, vec.Y + Origin.Y, vec.Z + Origin.Z + hole.locationX);
                        }
                        if (holePoints[i].X >= Origin.X && holePoints[i].X <= Origin.X + widthOrHeight && holePoints[i].Z >= Origin.Z && holePoints[i].Z <= Origin.Z + length)
                        {
                            holesContour.Add(new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z));
                            holesContour2.Add(new Vec3(holePoints[i].X, holePoints[i].Y + depth, holePoints[i].Z));
                        }
                        else
                        {
                            var vec2 = DelimitateContour("Underside", Origin.X + widthOrHeight, Origin.Z + length, new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z), Origin);
                            holesContour.Add(vec2);
                            holesContour2.Add(new Vec3(vec2.X, vec2.Y + depth, vec2.Z));
                            externalContour.Add(vec2);
                            externalContour2.Add(new Vec3(vec2.X, vec2.Y + depth, vec2.Z));
                        }
                    }
                    break;
                case "BottomFlange":
                    contour.Add(new Vec3(0, hole.yDim / 2, hole.xDim / 2));
                    contour.Add(new Vec3(0, -hole.yDim / 2, hole.xDim / 2));
                    contour.Add(new Vec3(0, -hole.yDim / 2, -hole.xDim / 2));
                    contour.Add(new Vec3(0, hole.yDim / 2, -hole.xDim / 2));
                    for (int i = 0; i < contour.Count - 1; i++)
                    {
                        holePoints.Add(contour[i]);
                        holePoints.AddRange(GeneratePoints(contour[i], contour[i + 1], hole.partSurface));
                    }
                    holePoints.Add(contour[contour.Count - 1]);
                    holePoints.AddRange(GeneratePoints(contour[contour.Count - 1], contour[0], hole.partSurface));
                    for (int i = 0; i < holePoints.Count; i++)
                    {
                        var vec = new Vector3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z);
                        if (hole.angle > 0)
                        {
                            vec = Vector3.Transform(vec, Matrix4x4.CreateRotationX((float)((Math.PI / 180) * -hole.angle)));
                            holePoints[i] = new Vec3(vec.X + Origin.X, vec.Y + Origin.Y + widthOrHeight / 2 + hole.locationZ, vec.Z + Origin.Z + hole.locationX);
                        }
                        else
                        {
                            holePoints[i] = new Vec3(vec.X + Origin.X, vec.Y + Origin.Y + widthOrHeight / 2 + hole.locationZ, vec.Z + Origin.Z + hole.locationX);
                        }
                        if (holePoints[i].Y >= Origin.Y && holePoints[i].Y <= Origin.Y + widthOrHeight && holePoints[i].Z >= Origin.Z && holePoints[i].Z <= Origin.Z + length)
                        {
                            holesContour.Add(new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z));
                            holesContour2.Add(new Vec3(holePoints[i].X + depth, holePoints[i].Y, holePoints[i].Z));
                        }
                        else
                        {
                            var vec2 = DelimitateContour("BottomFlange", Origin.Y + widthOrHeight, Origin.Z + length, new Vec3(holePoints[i].X, holePoints[i].Y, holePoints[i].Z), Origin);
                            holesContour.Add(vec2);
                            holesContour2.Add(new Vec3(vec2.X + depth, vec2.Y, vec2.Z));
                            externalContour.Add(vec2);
                            externalContour2.Add(new Vec3(vec2.X + depth, vec2.Y, vec2.Z));
                        }


                    }
                    break;
            }

            var v1 = new ContourVertex[holesContour.Count];
            var v2 = new ContourVertex[holesContour2.Count];
            for (int i = 0; i < holesContour.Count; i++)
            {
                v1[i].Position = holesContour[i];
                v2[i].Position = holesContour2[i];
            }

            ContourVertex[] v3;
            if (externalContour.Count > 0)
            {
                v3 = new ContourVertex[externalContour.Count * 2 - 1];
                var index = 0;
                for (int i = 0; i < externalContour.Count; i++)
                {
                    v3[index].Position = externalContour[i];
                    index++;
                }
                for (int i = externalContour2.Count - 1; i > 0; i--)
                {
                    v3[index].Position = externalContour2[i];
                    index++;
                }

            }
            else
            {
                v3 = new ContourVertex[0];
            }
            return Tuple.Create(hole.partSurface, v1, v2, v3);
        }


        public List<Vec3> GeneratePoints(Vec3 point1, Vec3 point2, string partName)
        {
            List<Vec3> points = new List<Vec3>();
            if(partName=="TopFlange" || partName=="BottomFlange")
                if (point1.Y > point2.Y && point1.Z == point2.Z)
                {
                    var aux = point1.Y;
                    while (aux > point2.Y)
                    {
                        aux = aux - 1f;
                        points.Add(new Vec3(point1.X, aux, point1.Z));
                    }
                }
                else if (point1.Y < point2.Y && point1.Z == point2.Z)
                {
                    var aux = point1.Y;
                    while (aux < point2.Y)
                    {
                        aux = aux + 1f;
                        points.Add(new Vec3(point1.X, aux, point1.Z));
                    }
                }
                else if (point1.Y == point2.Y && point1.Z > point2.Z)
                {
                    var aux = point1.Z;
                    while (aux > point2.Z)
                    {
                        aux = aux - 1f;
                        points.Add(new Vec3(point1.X, point1.Y, aux));
                    }
                }
                else if (point1.Y == point2.Y && point1.Z < point2.Z)
                {
                    var aux = point1.Z;
                    while (aux < point2.Z)
                    {
                        aux = aux + 1f;
                        points.Add(new Vec3(point1.X, point1.Y, aux));
                    }
                }
            if(partName=="Web" || partName=="Underside")
                    if (point1.X > point2.X && point1.Z == point2.Z)
                    {
                        var aux = point1.X;
                        while (aux > point2.X)
                        {
                            aux = aux - 1f;
                            points.Add(new Vec3(aux, point1.Y, point1.Z));
                        }
                    }
                    else if (point1.X < point2.X && point1.Z == point2.Z)
                    {
                        var aux = point1.X;
                        while (aux < point2.X)
                        {
                            aux = aux + 1f;
                            points.Add(new Vec3(aux, point1.Y, point1.Z));
                        }
                    }
                    else if (point1.X == point2.X && point1.Z > point2.Z)
                    {
                        var aux = point1.Z;
                        while (aux > point2.Z)
                        {
                            aux = aux - 1f;
                            points.Add(new Vec3(point1.X, point1.Y, aux));
                        }
                    }
                    else if (point1.X == point2.X && point1.Z < point2.Z)
                    {
                        var aux = point1.Z;
                        while (aux < point2.Z)
                        {
                            aux = aux + 1f;
                            points.Add(new Vec3(point1.X, point1.Y, aux));
                        }
                    }
            Console.WriteLine(points.Count);
            return points;
        }
        public Vec3 DelimitateContour(string partName, float widthOrHeight, float length, Vec3 vec, Vector3 origin)
        {
            var vecReturn = vec;
            switch (partName)
            {
                case "Web":
                    if(vec.X< origin.X && vec.Z>= origin.Z && vec.Z<=length)
                    {
                        vecReturn= new Vec3(origin.X, vec.Y, vec.Z);
                    }
                    if (vec.X > widthOrHeight && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, vec.Z);
                    }
                    if (vec.Z < origin.Z && vec.X >= origin.X && vec.X <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, origin.Z);
                    }
                    if (vec.Z > length && vec.X >= origin.X && vec.X <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, length);
                    }
                    if(vec.X< origin.X && vec.Z< origin.Z)
                    {
                        vecReturn = new Vec3(origin.X, vec.Y, origin.Z);
                    }
                    if (vec.X < origin.X && vec.Z > length)
                    {
                        vecReturn = new Vec3(origin.X, vec.Y, length);
                    }
                    if (vec.X > widthOrHeight && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, origin.Z);
                    }
                    if (vec.X > widthOrHeight && vec.Z > length)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, length);
                    }
                    break;
                case "TopFlange":
                    if (vec.Y < origin.Y && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, vec.Z);
                    }
                    if (vec.Y > widthOrHeight && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, vec.Z);
                    }
                    if (vec.Z < origin.Z && vec.Y >= origin.Y && vec.Y <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, origin.Z);
                    }
                    if (vec.Z > length && vec.Y >= origin.Y && vec.Y <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, length);
                    }
                    if (vec.Y < origin.Y && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, origin.Z);
                    }
                    if (vec.Y < origin.Y && vec.Z > length)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, length);
                    }
                    if (vec.Y > widthOrHeight && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, origin.Z);
                    }
                    if (vec.Y > widthOrHeight && vec.Z > length)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, length);
                    }
                    break;
                case "Underside":
                    if (vec.X < origin.X && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(origin.X, vec.Y, vec.Z);
                    }
                    if (vec.X > widthOrHeight && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, vec.Z);
                    }
                    if (vec.Z < origin.Z && vec.X >= origin.X && vec.X <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, origin.Z);
                    }
                    if (vec.Z > length && vec.X >= origin.X && vec.X <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, length);
                    }
                    if (vec.X < origin.X && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(origin.X, vec.Y, origin.Z);
                    }
                    if (vec.X < origin.X && vec.Z > length)
                    {
                        vecReturn = new Vec3(origin.X, vec.Y, length);
                    }
                    if (vec.X > widthOrHeight && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, origin.Z);
                    }
                    if (vec.X > widthOrHeight && vec.Z > length)
                    {
                        vecReturn = new Vec3(widthOrHeight, vec.Y, length);
                    }
                    break;
                case "BottomFlange":
                    if (vec.Y < origin.Y && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, vec.Z);
                    }
                    if (vec.Y > widthOrHeight && vec.Z >= origin.Z && vec.Z <= length)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, vec.Z);
                    }
                    if (vec.Z < origin.Z && vec.Y >= origin.Y && vec.Y <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, origin.Z);
                    }
                    if (vec.Z > length && vec.Y >= origin.Y && vec.Y <= widthOrHeight)
                    {
                        vecReturn = new Vec3(vec.X, vec.Y, length);
                    }
                    if (vec.Y < origin.Y && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, origin.Z);
                    }
                    if (vec.Y < origin.Y && vec.Z > length)
                    {
                        vecReturn = new Vec3(vec.X, origin.Y, length);
                    }
                    if (vec.Y > widthOrHeight && vec.Z < origin.Z)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, origin.Z);
                    }
                    if (vec.Y > widthOrHeight && vec.Z > length)
                    {
                        vecReturn = new Vec3(vec.X, widthOrHeight, length);
                    }
                    break;
            }
            return vecReturn;
        }

        public ContourVertex[] OuterContour(ContourVertex[] list,Plane plane)
        {
            var tempX = new List<float>();
            var tempY = new List<float>();
            var tempZ = new List<float>();
            var contour = new ContourVertex[4];
            var sw = 0;
            switch (plane.orientation)
            {
                case "XZ":
                    for (int i = 0; i < list.Length; i++)
                    {

                        if (list[i].Position.X == plane.firstPoint.X)
                        {
                            tempY.Add(list[i].Position.Y);
                            tempZ.Add(list[i].Position.Z);
                        }

                    }
                    if(tempY.Count>0 && tempZ.Count > 0)
                    {
                        contour[0].Position = new Vec3(plane.firstPoint.X, tempY.Min(), tempZ.Min());
                        contour[1].Position = new Vec3(plane.firstPoint.X, tempY.Max(), tempZ.Min());
                        contour[2].Position = new Vec3(plane.firstPoint.X, tempY.Max(), tempZ.Max());
                        contour[3].Position = new Vec3(plane.firstPoint.X, tempY.Min(), tempZ.Max());
                        sw = 1;
                    }
                    
                    break;
                case "YZ":
                    for (int i = 0; i < list.Length; i++)
                    {

                        if (list[i].Position.Y == plane.firstPoint.Y)
                        {
                            tempX.Add(list[i].Position.X);
                            tempZ.Add(list[i].Position.Z);
                        }

                    }
                    if (tempX.Count > 0 && tempZ.Count > 0)
                    {
                        contour[0].Position = new Vec3(tempX.Min(), plane.firstPoint.Y, tempZ.Min());
                        contour[1].Position = new Vec3(tempX.Max(), plane.firstPoint.Y, tempZ.Min());
                        contour[2].Position = new Vec3(tempX.Max(), plane.firstPoint.Y, tempZ.Max());
                        contour[3].Position = new Vec3(tempX.Min(), plane.firstPoint.Y, tempZ.Max());
                        sw = 1;
                    }
                        
                    break;
                case "XY":
                    for (int i = 0; i < list.Length; i++)
                    {

                        if (list[i].Position.Z == plane.firstPoint.Z)
                        {
                            tempX.Add(list[i].Position.X);
                            tempY.Add(list[i].Position.Y);
                        }

                    }
                    if (tempX.Count > 0 && tempY.Count > 0)
                    {
                        contour[0].Position = new Vec3(tempX.Min(), tempY.Min(), plane.firstPoint.Z);
                        contour[1].Position = new Vec3(tempX.Max(), tempY.Min(), plane.firstPoint.Z);
                        contour[2].Position = new Vec3(tempX.Max(), tempY.Max(), plane.firstPoint.Z);
                        contour[3].Position = new Vec3(tempX.Min(), tempY.Max(), plane.firstPoint.Z);
                        sw = 1;
                    }
                    break;
            }
            if (sw == 1)
                return contour;
            else
                return new ContourVertex[0];
            
        }

    }
}
