﻿using System.Numerics;


namespace ShapeLibrary
{
    public class Plane
    {

        #region //Storage

        public Vector3 firstPoint, secondPoint, thirdPoint, fourthPoint;
        public string orientation, partName;
        public float orientationPoint;

        #endregion

        #region //Constructor
        public Plane(Vector3 point1, Vector3 point2, Vector3 point3, Vector3 point4, float orientPoint,string partName)
        {
            this.firstPoint = point1;
            this.secondPoint = point2;
            this.thirdPoint = point3;
            this.fourthPoint = point4;
            this.orientation = DetectOrientaton(point1, point2, point3, point4);
            this.orientationPoint = orientPoint;
            this.partName = partName;
        }

        #endregion

        public string DetectOrientaton(Vector3 point1, Vector3 point2, Vector3 point3, Vector3 point4)
        {
            if (point1.X == point2.X && point1.X == point3.X && point1.X == point4.X)
                return "XZ";
            else if (point1.Y == point2.Y && point1.Y == point3.Y && point1.Y == point4.Y)
                return "YZ";
            else if (point1.Z == point2.Z && point1.Z == point3.Z && point1.Z == point4.Z)
                return "XY";
            else
                return "Wrong";
        }
    }
}
