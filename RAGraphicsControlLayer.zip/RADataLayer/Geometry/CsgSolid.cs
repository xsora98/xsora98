﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSG.Sharp;
using System.Numerics;
using LibTessDotNet;

namespace ShapeLibrary
{
    public class CsgSolid
    {
        #region Variables
        public CSG.Sharp.CSG polygon;
        public string partName;
        public Vector3 vOrigin;
        public float thickness;
        public float length;
        public float widthOrHeight;
        public List<Vector3> trianglesList = new List<Vector3>();
        public static List<Vector3> listTest = new List<Vector3>();
        #endregion

        #region Constructors
        /// <summary>
        /// Solid data initialize
        /// </summary>
        /// <param name="partName">Name of the solid part</param>
        /// <param name="length">Length of the solid </param>
        /// <param name="thickness">Thickness of the solid</param>
        /// <param name="widthOrHeight">Width or Height of the solid, depends on the part</param>
        /// <param name="origin">Origin vector of the solid</param>
        public void GeneratePolygon(string partName, float length, float thickness, float widthOrHeight, Vector3 origin)
        {
            this.polygon = Cube.Create(new Vector(origin.X, origin.Y, origin.Z), widthOrHeight, thickness, length);
            this.vOrigin = origin;
            this.length = length;
            this.thickness = thickness;
            this.widthOrHeight = widthOrHeight;
            this.partName = partName;
        }
        #endregion

        #region Getters/Setters
        /// <summary>
        /// Return a CSG solid.
        /// </summary>
        /// <returns></returns>
        public CSG.Sharp.CSG getPolygon()
        {
            return polygon;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Generate solid vertices in a vector3 list
        /// </summary>
        /// <param name="csgList">CSG Solid list</param>
        /// <returns></returns>
        public static List<Vector3> GenerateSolid(List<CSG.Sharp.CSG> csgList)
        {
            List<Vector3> verticesList = new List<Vector3>();
            CSG.Sharp.CSG poly = new CSG.Sharp.CSG();
            if (csgList.Count == 1)
            {
                poly = csgList[0];
            }

            if (csgList.Count == 2)
            {
                poly = csgList[0].Union(csgList[1]);
            }
            if (csgList.Count == 3)
            {
                poly = csgList[0].Union(csgList[1]);
                poly = csgList[2].Union(poly);
            }
            if (csgList.Count == 4)
            {
                poly = csgList[0].Union(csgList[1]);
                poly = csgList[2].Union(poly);
                poly = poly.Union(csgList[3]);
            }

            var polygons = poly.ToPolygons();

            Tess tess = new Tess();
            foreach (var polygon in polygons)
            {
                var vecList = new List<Vector3>();
                for (int i = 0; i < polygon.Vertices.Length; i++)
                {
                    vecList.Add(new Vector3((float)polygon.Vertices[i].Pos.x, (float)polygon.Vertices[i].Pos.y, (float)polygon.Vertices[i].Pos.z));
                }
                var v = new ContourVertex[vecList.Count];
                for (int i = 0; i < vecList.Count; i++)
                {
                    v[i].Position = new Vec3(vecList[i].X, vecList[i].Y, vecList[i].Z);
                   
                }
                tess.AddContour(v, ContourOrientation.Original);
                tess.Tessellate(WindingRule.EvenOdd, ElementType.Polygons, 3);
                for (int i = 0; i < tess.ElementCount; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int index = tess.Elements[i * 3 + j];
                        if (index == -1)
                            continue;
                        verticesList.Add(new Vector3(tess.Vertices[index].Position.X, tess.Vertices[index].Position.Y, tess.Vertices[index].Position.Z));

                    }
                }
            }
            return verticesList;

        }

        /// <summary>
        /// Generate a solid
        /// </summary>
        /// <param name="csgList">CSG Solid list</param>
        /// <returns></returns>
        public static CSG.Sharp.CSG GeneratePoly(List<CSG.Sharp.CSG> csgList)
        {
            CSG.Sharp.CSG poly = new CSG.Sharp.CSG();
            if (csgList.Count == 1)
            {
                poly = csgList[0];
            }

            if (csgList.Count == 2)
            {
                poly = csgList[0].Union(csgList[1]);

            }
            if (csgList.Count == 3)
            {
                poly = csgList[0].Union(csgList[1]);
                poly = csgList[2].Union(poly);
            }
            if (csgList.Count == 4)
            {
                poly = csgList[0].Union(csgList[1]);
                poly = csgList[2].Union(poly);
                poly = poly.Union(csgList[3]);
            }
            return poly;

        }

        /// <summary>
        /// Generate Solid vertices in a vector3 list.
        /// </summary>
        /// <param name="holeList">CSG Hole list</param>
        /// <param name="piece">CSG Solid where the hole is done</param>
        /// <returns></returns>
        public static List<Vector3> GenerateSolidHoles(List<CSG.Sharp.CSG> holeList, CSG.Sharp.CSG piece)
        {
            List<Vector3> verticesList = new List<Vector3>();
            CSG.Sharp.CSG poly = piece;
            foreach (CSG.Sharp.CSG hole in holeList)
            {
                poly = poly.Subtract(hole);

            }
            var polygons = poly.ToPolygons();
            Tess tess = new Tess();
            foreach (var polygon in polygons)
            {
                var vecList = new List<Vector3>();
                for (int i = 0; i < polygon.Vertices.Length; i++)
                {
                    vecList.Add(new Vector3((float)polygon.Vertices[i].Pos.x, (float)polygon.Vertices[i].Pos.y, (float)polygon.Vertices[i].Pos.z));
                }
                var v = new ContourVertex[vecList.Count];
                for (int i = 0; i < vecList.Count; i++)
                {
                    v[i].Position = new Vec3(vecList[i].X, vecList[i].Y, vecList[i].Z);
                    listTest.Add(new Vector3(vecList[i].X, vecList[i].Y, vecList[i].Z));
                }
                tess.AddContour(v, ContourOrientation.Original);
                tess.Tessellate(WindingRule.EvenOdd, ElementType.Polygons, 3);
                for (int i = 0; i < tess.ElementCount; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int index = tess.Elements[i * 3 + j];
                        if (index == -1)
                            continue;
                        verticesList.Add(new Vector3(tess.Vertices[index].Position.X, tess.Vertices[index].Position.Y, tess.Vertices[index].Position.Z));

                    }
                }
            }
            return verticesList;
        }
    }
    #endregion
}
