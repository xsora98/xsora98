﻿using System.Collections.Generic;
using System.Linq;
using TriangleNet.Geometry;
using TriangleNet.Meshing;

using Vertex = TriangleNet.Geometry.Vertex;

namespace ShapeLibrary
{
    public class PlaneGenerator
    {
        #region //Storage

        public List<Triangle> MainPlane;

        private ConstraintOptions options = new ConstraintOptions() { ConformingDelaunay = true };
        private QualityOptions quality = new QualityOptions() { MaximumAngle = 25 };

        private List<Triangle> triangleList = new List<Triangle>();


        #endregion

        #region //Constructor
        public PlaneGenerator(List<Plane> planeList)
        {
            var contourVertices = new List<TriangleNet.Geometry.Vertex>();

            for (int i = 0; i < planeList.Count; i++)
            {
                var polygon3 = new Polygon();
                contourVertices.Clear();

                if (planeList[i].orientation == "Vertical")
                    GenerateVerticalPlane(planeList[i], contourVertices, polygon3);
                {
                    #region //
                    /*contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].firstPoint.Y, planeList[i].firstPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].secondPoint.Y, planeList[i].secondPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].thirdPoint.Y, planeList[i].thirdPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].fourthPoint.Y, planeList[i].fourthPoint.Z, 1));

                    polygon3.Add(new Contour(contourVertices));

                    var mesh2 = polygon3.Triangulate(options, quality);
                    var dataMesh = mesh2.Triangles.ToArray();

                    for (int j = 0; j < dataMesh.Length; j++)
                    {
                        var vertex1 = dataMesh[j].GetVertex(0);
                        var vertex2 = dataMesh[j].GetVertex(1);
                        var vertex3 = dataMesh[j].GetVertex(2);

                        triangleList.Add(new Triangle(new Vertex(new Point(planeList[i].orientationPoint, (float)vertex1.X, (float)vertex1.Y)),
                                                      new Vertex(new Point(planeList[i].orientationPoint, (float)vertex2.X, (float)vertex2.Y)),
                                                      new Vertex(new Point(planeList[i].orientationPoint, (float)vertex3.X, (float)vertex3.Y))));
                    }*/
                    #endregion
                }

                if (planeList[i].orientation == "Horizontal")
                    GenerateHorizontalPlane(planeList[i], contourVertices, polygon3);
                { 
                    #region//
                    /*contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].firstPoint.X, planeList[i].firstPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].secondPoint.X, planeList[i].secondPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].thirdPoint.X, planeList[i].thirdPoint.Z, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].fourthPoint.X, planeList[i].fourthPoint.Z, 1));

                    polygon3.Add(new Contour(contourVertices));

                    var mesh2 = polygon3.Triangulate(options, quality);
                    var dataMesh = mesh2.Triangles.ToArray();

                    for (int j = 0; j < dataMesh.Length; j++)
                    {
                        var vertex1 = dataMesh[j].GetVertex(0);
                        var vertex2 = dataMesh[j].GetVertex(1);
                        var vertex3 = dataMesh[j].GetVertex(2);

                        triangleList.Add(new Triangle(new Vertex(new Point((float)vertex1.X, planeList[i].orientationPoint, ((float)vertex1.Y))),
                                                      new Vertex(new Point((float)vertex2.X, planeList[i].orientationPoint, ((float)vertex2.Y))),
                                                      new Vertex(new Point((float)vertex3.X, planeList[i].orientationPoint, ((float)vertex3.Y)))));
                    }*/
                    #endregion
                }

                if (planeList[i].orientation == "Front"|| planeList[i].orientation == "Back")
                    GenerateFrontBackPlane(planeList[i], contourVertices, polygon3);
                {
                    #region//
                    /*contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].firstPoint.X, planeList[i].firstPoint.Y, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].secondPoint.X, planeList[i].secondPoint.Y, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].thirdPoint.X, planeList[i].thirdPoint.Y, 1));
                    contourVertices.Add(new TriangleNet.Geometry.Vertex(planeList[i].fourthPoint.X, planeList[i].fourthPoint.Y, 1));

                    polygon3.Add(new Contour(contourVertices));

                    var mesh2 = polygon3.Triangulate(options, quality);
                    var dataMesh = mesh2.Triangles.ToArray();

                    for (int j = 0; j < dataMesh.Length; j++)
                    {
                        var vertex1 = dataMesh[j].GetVertex(0);
                        var vertex2 = dataMesh[j].GetVertex(1);
                        var vertex3 = dataMesh[j].GetVertex(2);

                        
                        triangleList.Add(new Triangle(new Vertex(new Point((float)vertex1.X, (float)vertex1.Y, planeList[i].orientationPoint)),
                                                      new Vertex(new Point((float)vertex2.X, (float)vertex2.Y, planeList[i].orientationPoint)),
                                                      new Vertex(new Point((float)vertex3.X, (float)vertex3.Y, planeList[i].orientationPoint))));
                    }*/
                    #endregion
                }
            }
            //list2.AddRange(list);
            this.MainPlane = triangleList;
        }

        public List<Triangle> GenerateHorizontalPlane(Plane plane, List<TriangleNet.Geometry.Vertex> contourVertices, Polygon polygon)
        {
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.firstPoint.X, plane.firstPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.secondPoint.X, plane.secondPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.thirdPoint.X, plane.thirdPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.fourthPoint.X, plane.fourthPoint.Z, 1));

            polygon.Add(new Contour(contourVertices));

            var mesh2 = polygon.Triangulate(options, quality);
            var dataMesh = mesh2.Triangles.ToArray();

            for (int j = 0; j < dataMesh.Length; j++)
            {
                var vertex1 = dataMesh[j].GetVertex(0);
                var vertex2 = dataMesh[j].GetVertex(1);
                var vertex3 = dataMesh[j].GetVertex(2);

                triangleList.Add(new Triangle(new Vertex(new Point((float)vertex1.X, plane.orientationPoint, ((float)vertex1.Y))),
                                              new Vertex(new Point((float)vertex2.X, plane.orientationPoint, ((float)vertex2.Y))),
                                              new Vertex(new Point((float)vertex3.X, plane.orientationPoint, ((float)vertex3.Y)))));
            }

            return triangleList;
        }

        public List<Triangle> GenerateVerticalPlane(Plane plane, List<TriangleNet.Geometry.Vertex> contourVertices, Polygon polygon)
        {
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.firstPoint.Y, plane.firstPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.secondPoint.Y, plane.secondPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.thirdPoint.Y, plane.thirdPoint.Z, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.fourthPoint.Y, plane.fourthPoint.Z, 1));

            polygon.Add(new Contour(contourVertices));

            var mesh2 = polygon.Triangulate(options, quality);
            var dataMesh = mesh2.Triangles.ToArray();

            for (int j = 0; j < dataMesh.Length; j++)
            {
                var vertex1 = dataMesh[j].GetVertex(0);
                var vertex2 = dataMesh[j].GetVertex(1);
                var vertex3 = dataMesh[j].GetVertex(2);

                triangleList.Add(new Triangle(new Vertex(new Point(plane.orientationPoint, (float)vertex1.X, (float)vertex1.Y)),
                                              new Vertex(new Point(plane.orientationPoint, (float)vertex2.X, (float)vertex2.Y)),
                                              new Vertex(new Point(plane.orientationPoint, (float)vertex3.X, (float)vertex3.Y))));

            }
                return triangleList;
        }

        public List<Triangle> GenerateFrontBackPlane(Plane plane, List<TriangleNet.Geometry.Vertex> contourVertices, Polygon polygon)
        {
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.firstPoint.X, plane.firstPoint.Y, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.secondPoint.X, plane.secondPoint.Y, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.thirdPoint.X, plane.thirdPoint.Y, 1));
            contourVertices.Add(new TriangleNet.Geometry.Vertex(plane.fourthPoint.X, plane.fourthPoint.Y, 1));

            polygon.Add(new Contour(contourVertices));

            var mesh2 = polygon.Triangulate(options, quality);
            var dataMesh = mesh2.Triangles.ToArray();

            for (int j = 0; j < dataMesh.Length; j++)
            {
                var vertex1 = dataMesh[j].GetVertex(0);
                var vertex2 = dataMesh[j].GetVertex(1);
                var vertex3 = dataMesh[j].GetVertex(2);

                triangleList.Add(new Triangle(new Vertex(new Point((float)vertex1.X, (float)vertex1.Y, plane.orientationPoint)),
                                              new Vertex(new Point((float)vertex2.X, (float)vertex2.Y, plane.orientationPoint)),
                                              new Vertex(new Point((float)vertex3.X, (float)vertex3.Y, plane.orientationPoint))));
            }

            return triangleList;
        }

        #endregion
    }
}
