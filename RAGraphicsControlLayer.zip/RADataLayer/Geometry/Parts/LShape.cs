﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class LShape : MultiSolid
    {
        public CsgSolid Web;
        public CsgSolid TopFlange;

        /// <summary>
        /// Generates solids required to represent shape, with the first solid indexed in the list being the topmost, the second one being the one below, etc. 
        /// </summary>
        /// <param name="data">Raw shape data needed to generate</param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            solidList = new List<CsgSolid>(2);
            solidList.Add(new CsgSolid());
            solidList.Add(new CsgSolid());

            var webHeight = data.Height;
            var webThickness = data.WebThickness;
            var webLength = data.Length;

            var flangeThickness = data.WebThickness;
            var flangeLength = data.Length;
            var flangeWidth = data.Width;

            var topFlangeStartPosition = new Vector3(data.Height - data.WebThickness, data.WebThickness, 0);

            //Top Flange
            solidList[0].GeneratePolygon("TopFlange", flangeLength / 2, flangeWidth / 2, flangeThickness / 2, Solid.ORIGIN);
            TopFlange = solidList[0];
            //Web
            solidList[1].GeneratePolygon("Web", webLength / 2, webThickness / 2, webHeight / 2, new Vector3(webHeight / 2 - data.TopFlangeThickness / 2, -data.Width / 2 + data.WebThickness / 2, 0));
            Web = solidList[1];


            return this;
        }
    }
}
