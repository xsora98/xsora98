﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public abstract class MultiSolid
    {
        #region//Storage

        public List<CsgSolid> solidList = new List<CsgSolid>();
  

        #endregion

        #region//Constructors

        public MultiSolid()
        {}
        public MultiSolid(List<CsgSolid> solidList)
        {
            solidList = solidList;
        }

        #endregion

        #region //Methods

        public abstract MultiSolid GenerateSolidsForPart(RawShapeData data);
        

        #endregion


    }
}
