﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class TShape : MultiSolid
    {

        #region //Storage

        public CsgSolid topFlange;
        public CsgSolid web;

        #endregion



        #region //Methods
        /// <summary>
        /// Generates solids required to represent shape, with the first solid indexed in the list being the topmost, the second one being the one below, etc. 
        /// </summary>
        /// <param name="data">Raw shape data needed to generate</param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            solidList = new List<CsgSolid>(2);

            solidList.Add(new CsgSolid());
            solidList.Add(new CsgSolid());

            var topFlangeHeight = data.TopFlangeThickness;

            var webHeight = data.Height - data.TopFlangeThickness;
            var webThickness = data.WebThickness;
            var webLength = data.Length;

            var flangeLength = data.Length;
            var flangeWidth = data.Width;

            //Top Flange
            solidList[0].GeneratePolygon("TopFlange", flangeLength / 2, flangeWidth / 2, topFlangeHeight / 2, Solid.ORIGIN);
            topFlange = solidList[0];
            //Web
            solidList[1].GeneratePolygon("Web", webLength / 2, webThickness / 2, webHeight / 2, new Vector3(webHeight / 2 - data.TopFlangeThickness / 2, 0, 0));
            web = solidList[1];

            return this;
        }
        #endregion
    }
}
