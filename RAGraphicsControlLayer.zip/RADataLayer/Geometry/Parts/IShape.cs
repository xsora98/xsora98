﻿using System.Collections.Generic;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class IShape : MultiSolid
    {
        public CsgSolid web;

        /// <summary>
        /// Generates solids required to represent shape, with the first solid indexed in the list being the topmost, the second one being the one below, etc. 
        /// </summary>
        /// <param name="data">Raw shape data needed to generate</param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            solidList = new List<CsgSolid>(1);

            solidList.Add(new CsgSolid());
            //Web
            solidList[0].GeneratePolygon("Web", data.Length / 2, data.WebThickness / 2, data.Height / 2, Solid.ORIGIN);
            web = solidList[0];

            return this;
        }
    }
}
