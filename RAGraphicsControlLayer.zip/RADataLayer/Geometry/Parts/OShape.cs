﻿using System.Collections.Generic;
using System.Numerics;
using XmlDeserialize.Geometry;

namespace ShapeLibrary
{
    public class OShape : MultiSolid
    {
        #region //Storage

        public CsgSolid topFlange;
        public CsgSolid bottomFlange;
        public CsgSolid web;
        public CsgSolid underside;

        #endregion

        #region //Methods
        /// <summary>
        /// Generates solids required to represent shape, with the first solid indexed in the list being the topmost, the second one being the one below, etc. 
        /// </summary>
        /// <param name="data">Raw shape data needed to generate</param>
        /// <returns></returns>
        public override MultiSolid GenerateSolidsForPart(RawShapeData data)
        {
            solidList = new List<CsgSolid>(4);


            solidList.Add(new CsgSolid());
            solidList.Add(new CsgSolid());
            solidList.Add(new CsgSolid());
            solidList.Add(new CsgSolid());

            var webHeight = data.Height - data.Thickness * 2;
            var webThickness = data.Thickness;
            var webLength = data.Length;

            var topFlangeHeight = data.Thickness;
            var bottomFlangeHeight = data.Thickness;

            var flangeLength = data.Length;
            var flangeWidth = data.Width;

            var topFlangeStartPosition = new Vector3(data.Height-data.Thickness, 0, 0);
            var rightWebStartPosition = new Vector3(data.Thickness,flangeWidth-data.Thickness,0);
            var leftWebStartPosition = new Vector3(data.Thickness, 0, 0);

            //Top Flange
            solidList[0].GeneratePolygon("TopFlange", flangeLength / 2, flangeWidth / 2, topFlangeHeight / 2, Solid.ORIGIN);
            topFlange = solidList[0];
            //Web
            solidList[1].GeneratePolygon("Web", webLength / 2, webThickness / 2, webHeight / 2, new Vector3(webHeight / 2 - data.Thickness / 2, data.Width / 2 - data.Thickness / 2, 0));
            web = solidList[1];
            //Bottom Flange
            solidList[2].GeneratePolygon("BottomFlange", flangeLength / 2, flangeWidth / 2, bottomFlangeHeight / 2, new Vector3(webHeight - data.Thickness, 0, 0));
            bottomFlange = solidList[2];
            //Web
            solidList[3].GeneratePolygon("Underside", webLength / 2, webThickness / 2, webHeight / 2, new Vector3(webHeight / 2 - data.Thickness / 2, -data.Width / 2 + data.Thickness / 2, 0));
            underside = solidList[3];

            return this;
        }

        #endregion
    }
}
