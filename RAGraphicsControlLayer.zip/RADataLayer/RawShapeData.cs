﻿

using UIControl;

namespace XmlDeserialize
{
    public class RawShapeData
    {

        #region //Storage

        public float BottomFlangeThickness;
        public float FarLegThickness;
        public float FlangeSlope;
        public float Height;
        public float InnerDiameter;
        public float Length;
        public float NearLegThickness;
        public float OuterDiameter;
        public float TopFlangeThickness;
        public float RoundingRadius1;
        public float RoundingRadius2;
        public float Thickness;
        public float WebThickness;
        public float WeightPerLength;
        public float Width;

        public int ShapeType;

        public string Profile;
        public string ProfileID;

        #endregion

        #region //Constructor
        /// <summary>
        /// Retrieves last shape's raw data
        /// </summary>
        public RawShapeData()
        {
                var shapeData = XMLContainer.shapeQueue[XMLContainer.shapeQueue.Count - 1].RawShapeData;
                this.BottomFlangeThickness = (float)shapeData.BottomFlangeThickness;
                this.FarLegThickness = shapeData.FarLegThickness;
                this.FlangeSlope = shapeData.FlangeSlope;
                this.Height = (float)shapeData.Height;
                this.InnerDiameter = shapeData.InnerDiameter;
                this.Length = shapeData.Length;
                this.NearLegThickness = shapeData.NearLegThickness;
                this.OuterDiameter = shapeData.OuterDiameter;
                this.Profile = shapeData.Profile;
                this.ProfileID = shapeData.ProfileID;
                this.RoundingRadius1 = (float)shapeData.RoundingRadius1;
                this.RoundingRadius2 = (float)shapeData.RoundingRadius2;
                this.ShapeType = (int)shapeData.ShapeType;
                this.Thickness = (float)shapeData.Thickness;
                this.TopFlangeThickness = (float)shapeData.TopFlangeThickness;
                this.WebThickness = (float)shapeData.WebThickness;
                this.WeightPerLength = (float)shapeData.WeightPerLength;
                this.Width = (float)shapeData.Width;       
         }
        

        public RawShapeData(ShapeRawShapeData shapeData)
        {
            this.BottomFlangeThickness = (float)shapeData.BottomFlangeThickness;
            this.FarLegThickness = shapeData.FarLegThickness;
            this.FlangeSlope = shapeData.FlangeSlope;
            this.Height = (float)shapeData.Height;
            this.InnerDiameter = shapeData.InnerDiameter;
            this.Length = shapeData.Length;
            this.NearLegThickness = shapeData.NearLegThickness;
            this.OuterDiameter = shapeData.OuterDiameter;
            this.Profile = shapeData.Profile;
            this.ProfileID = shapeData.ProfileID;
            this.RoundingRadius1 = (float)shapeData.RoundingRadius1;
            this.RoundingRadius2 = (float)shapeData.RoundingRadius2;
            this.ShapeType = (int)shapeData.ShapeType;
            this.Thickness = (float)shapeData.Thickness;
            this.TopFlangeThickness = (float)shapeData.TopFlangeThickness;
            this.WebThickness = (float)shapeData.WebThickness;
            this.WeightPerLength = (float)shapeData.WeightPerLength;
            this.Width = (float)shapeData.Width;
        }

        #endregion

        public override string ToString()
        {
            return "Bottom Flange Thickness:"+ this.BottomFlangeThickness+"\r\n"+
                "Far Leg Thickness:" + this.FarLegThickness + "\r\n" +
                "Flange Slope:" + this.FlangeSlope + "\r\n" +
                "Height:" + this.Height + "\r\n" +
                "Ineer Diameter:" + this.InnerDiameter + "\r\n" +
                "Length:" + this.Length + "\r\n" +
                "Near Leg Thickness:" + this.NearLegThickness + "\r\n" +
                "Outer Diameter:" + this.OuterDiameter + "\r\n" +
                "Profile:" + this.Profile + "\r\n" +
                "Profile ID:" + this.ProfileID + "\r\n" +
                "Rounding Radius 1:" + this.RoundingRadius1 + "\r\n" +
                "Rounding Radius 2:" + this.RoundingRadius2 + "\r\n" +
                "Shape Type:" + this.ShapeType + "\r\n" +
                "Thickness:" + this.Thickness + "\r\n" +
                "Top FlangeThickness:" + this.TopFlangeThickness + "\r\n" +
                "Web Thickness:" + this.WebThickness + "\r\n" +
                "Weight Per Length:" + this.WeightPerLength + "\r\n" +
                "Width:" + this.Width + "\r\n";
        }
    }

}
