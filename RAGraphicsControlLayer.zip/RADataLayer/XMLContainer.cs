﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace XmlDeserialize
{
    public class XMLContainer
    {
        //TODO REDO


        #region //storage

        public static List<Shape> shapeQueue = new List<Shape>();
        public string[] _types = new string[] { "Angle", "Beam", "Channel", "Plate", "Tube", "TShape" };
        public string[] Types
        {
            get => _types;
        }
        public XmlAttributes attrs = new XmlAttributes();
        public XmlAttributeOverrides xOver = new XmlAttributeOverrides();

        /* Create an XmlTypeAttribute and change the name of the XML type. */
        public XmlTypeAttribute xType = new XmlTypeAttribute();
        public XmlRootAttribute xRoot = new XmlRootAttribute();

        public Shape ProcessPartXml()
        {
            attrs.XmlRoot = xRoot;
            xRoot.ElementName = "Shape";

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "xml3d files (*.xml3d)|*.xml3d";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    var lines = System.IO.File.ReadAllLines(openFileDialog.FileName);
                    foreach (string type in _types)
                    {
                        if (lines[1].Contains(type))
                        {
                            xType.TypeName = type;
                            Console.WriteLine(type);
                        }
                    }

                    attrs.XmlType = xType;
                    xOver.Add(typeof(Shape), attrs);

                    var currentShape = XMLDeserializer.DeserializeObject(openFileDialog.FileName, xOver);
                    shapeQueue.Add(currentShape);

                    return currentShape;

                }

                return null;
            }
        }

        #endregion


    }
}
