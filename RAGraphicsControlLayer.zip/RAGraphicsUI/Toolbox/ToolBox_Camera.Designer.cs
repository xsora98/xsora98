﻿
namespace RAGraphicsUI.Toolbox
{
    partial class ToolBox_Camera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Panel PositionPanel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Panel RotationPanel;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Panel panel6;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Panel panel8;
            System.Windows.Forms.Label label15;
            this.label8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.ZPosTextBox = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.YPosTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.XPosTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.SnapToXZButton = new System.Windows.Forms.Button();
            this.SnapToYZButton = new System.Windows.Forms.Button();
            this.SnapToXYButton = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.YawTextBox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PitchTextBox = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ZoomTrackBar = new System.Windows.Forms.TrackBar();
            this.PitchTrackbar = new System.Windows.Forms.TrackBar();
            this.YawTrackbar = new System.Windows.Forms.TrackBar();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.CamRightButton = new System.Windows.Forms.Button();
            this.CamDownButton = new System.Windows.Forms.Button();
            this.CamPerspectiveButton = new System.Windows.Forms.Button();
            this.CamLeftButton = new System.Windows.Forms.Button();
            this.CamUpButton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ResetRotationButton = new System.Windows.Forms.Button();
            this.ResetPositionButton = new System.Windows.Forms.Button();
            PositionPanel = new System.Windows.Forms.Panel();
            label1 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            RotationPanel = new System.Windows.Forms.Panel();
            label2 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            panel6 = new System.Windows.Forms.Panel();
            label14 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            panel8 = new System.Windows.Forms.Panel();
            label15 = new System.Windows.Forms.Label();
            PositionPanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            RotationPanel.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            panel6.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZoomTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PitchTrackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YawTrackbar)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // PositionPanel
            // 
            PositionPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            PositionPanel.Controls.Add(label1);
            PositionPanel.Controls.Add(this.label8);
            PositionPanel.Controls.Add(this.panel4);
            PositionPanel.Controls.Add(this.panel3);
            PositionPanel.Controls.Add(this.panel2);
            PositionPanel.Location = new System.Drawing.Point(0, -1);
            PositionPanel.Name = "PositionPanel";
            PositionPanel.Size = new System.Drawing.Size(200, 239);
            PositionPanel.TabIndex = 0;
            // 
            // label1
            // 
            label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            label1.Location = new System.Drawing.Point(0, 216);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(190, 23);
            label1.TabIndex = 0;
            label1.Text = "Position";
            label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Location = new System.Drawing.Point(190, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 239);
            this.label8.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(label5);
            this.panel4.Controls.Add(this.ZPosTextBox);
            this.panel4.Location = new System.Drawing.Point(3, 68);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(181, 29);
            this.panel4.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(3, 6);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(17, 17);
            label5.TabIndex = 0;
            label5.Text = "Z";
            // 
            // ZPosTextBox
            // 
            this.ZPosTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ZPosTextBox.Location = new System.Drawing.Point(26, 3);
            this.ZPosTextBox.Name = "ZPosTextBox";
            this.ZPosTextBox.ReadOnly = true;
            this.ZPosTextBox.Size = new System.Drawing.Size(152, 22);
            this.ZPosTextBox.TabIndex = 1;
            this.ZPosTextBox.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(label4);
            this.panel3.Controls.Add(this.YPosTextBox);
            this.panel3.Location = new System.Drawing.Point(3, 36);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(181, 29);
            this.panel3.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(3, 6);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(17, 17);
            label4.TabIndex = 0;
            label4.Text = "Y";
            // 
            // YPosTextBox
            // 
            this.YPosTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YPosTextBox.Location = new System.Drawing.Point(26, 3);
            this.YPosTextBox.Name = "YPosTextBox";
            this.YPosTextBox.ReadOnly = true;
            this.YPosTextBox.Size = new System.Drawing.Size(152, 22);
            this.YPosTextBox.TabIndex = 1;
            this.YPosTextBox.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(label3);
            this.panel2.Controls.Add(this.XPosTextBox);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(181, 29);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(3, 6);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(17, 17);
            label3.TabIndex = 0;
            label3.Text = "X";
            // 
            // XPosTextBox
            // 
            this.XPosTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.XPosTextBox.Location = new System.Drawing.Point(26, 3);
            this.XPosTextBox.Name = "XPosTextBox";
            this.XPosTextBox.ReadOnly = true;
            this.XPosTextBox.Size = new System.Drawing.Size(152, 22);
            this.XPosTextBox.TabIndex = 1;
            this.XPosTextBox.TabStop = false;
            // 
            // RotationPanel
            // 
            RotationPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            RotationPanel.Controls.Add(label2);
            RotationPanel.Controls.Add(this.label9);
            RotationPanel.Controls.Add(this.panel7);
            RotationPanel.Controls.Add(this.panel5);
            RotationPanel.Controls.Add(this.panel1);
            RotationPanel.Location = new System.Drawing.Point(206, -1);
            RotationPanel.Name = "RotationPanel";
            RotationPanel.Size = new System.Drawing.Size(194, 239);
            RotationPanel.TabIndex = 0;
            // 
            // label2
            // 
            label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            label2.Location = new System.Drawing.Point(0, 216);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(181, 23);
            label2.TabIndex = 0;
            label2.Text = "Rotation";
            label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Dock = System.Windows.Forms.DockStyle.Right;
            this.label9.Location = new System.Drawing.Point(181, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 239);
            this.label9.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.SnapToXZButton);
            this.panel7.Controls.Add(this.SnapToYZButton);
            this.panel7.Controls.Add(this.SnapToXYButton);
            this.panel7.Location = new System.Drawing.Point(0, 68);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(175, 29);
            this.panel7.TabIndex = 1;
            // 
            // SnapToXZButton
            // 
            this.SnapToXZButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SnapToXZButton.Location = new System.Drawing.Point(55, 0);
            this.SnapToXZButton.Name = "SnapToXZButton";
            this.SnapToXZButton.Size = new System.Drawing.Size(64, 29);
            this.SnapToXZButton.TabIndex = 3;
            this.SnapToXZButton.Text = "XZ";
            this.SnapToXZButton.UseVisualStyleBackColor = true;
            this.SnapToXZButton.Click += new System.EventHandler(this.SnapToXZButton_Click);
            // 
            // SnapToYZButton
            // 
            this.SnapToYZButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.SnapToYZButton.Location = new System.Drawing.Point(119, 0);
            this.SnapToYZButton.Name = "SnapToYZButton";
            this.SnapToYZButton.Size = new System.Drawing.Size(56, 29);
            this.SnapToYZButton.TabIndex = 3;
            this.SnapToYZButton.Text = "YZ";
            this.SnapToYZButton.UseVisualStyleBackColor = true;
            this.SnapToYZButton.Click += new System.EventHandler(this.SnapToYZButton_Click);
            // 
            // SnapToXYButton
            // 
            this.SnapToXYButton.Dock = System.Windows.Forms.DockStyle.Left;
            this.SnapToXYButton.Location = new System.Drawing.Point(0, 0);
            this.SnapToXYButton.Name = "SnapToXYButton";
            this.SnapToXYButton.Size = new System.Drawing.Size(55, 29);
            this.SnapToXYButton.TabIndex = 3;
            this.SnapToXYButton.Text = "XY";
            this.SnapToXYButton.UseVisualStyleBackColor = true;
            this.SnapToXYButton.Click += new System.EventHandler(this.SnapToXYButton_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(label7);
            this.panel5.Controls.Add(this.YawTextBox);
            this.panel5.Location = new System.Drawing.Point(0, 34);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(178, 29);
            this.panel5.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(6, 8);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(34, 17);
            label7.TabIndex = 0;
            label7.Text = "Yaw";
            // 
            // YawTextBox
            // 
            this.YawTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YawTextBox.Location = new System.Drawing.Point(61, 3);
            this.YawTextBox.Name = "YawTextBox";
            this.YawTextBox.ReadOnly = true;
            this.YawTextBox.Size = new System.Drawing.Size(114, 22);
            this.YawTextBox.TabIndex = 1;
            this.YawTextBox.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(label6);
            this.panel1.Controls.Add(this.PitchTextBox);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(175, 29);
            this.panel1.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(3, 6);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(39, 17);
            label6.TabIndex = 0;
            label6.Text = "Pitch";
            // 
            // PitchTextBox
            // 
            this.PitchTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PitchTextBox.Location = new System.Drawing.Point(58, 3);
            this.PitchTextBox.Name = "PitchTextBox";
            this.PitchTextBox.ReadOnly = true;
            this.PitchTextBox.Size = new System.Drawing.Size(114, 22);
            this.PitchTextBox.TabIndex = 1;
            this.PitchTextBox.TabStop = false;
            // 
            // panel6
            // 
            panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            panel6.Controls.Add(this.tableLayoutPanel2);
            panel6.Controls.Add(this.tableLayoutPanel1);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(this.label11);
            panel6.Location = new System.Drawing.Point(406, -1);
            panel6.Name = "panel6";
            panel6.Size = new System.Drawing.Size(383, 239);
            panel6.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(label14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(label12, 0, 0);
            this.tableLayoutPanel2.Controls.Add(label13, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ZoomTrackBar, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.PitchTrackbar, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.YawTrackbar, 1, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(132, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(232, 97);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label14
            // 
            label14.Location = new System.Drawing.Point(3, 64);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(73, 33);
            label14.TabIndex = 0;
            label14.Text = "Zoom";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            label12.Location = new System.Drawing.Point(3, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(73, 32);
            label12.TabIndex = 0;
            label12.Text = "Pitch";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            label13.Location = new System.Drawing.Point(3, 32);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(73, 32);
            label13.TabIndex = 0;
            label13.Text = "Yaw";
            label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ZoomTrackBar
            // 
            this.ZoomTrackBar.Location = new System.Drawing.Point(82, 67);
            this.ZoomTrackBar.Minimum = -10;
            this.ZoomTrackBar.Name = "ZoomTrackBar";
            this.ZoomTrackBar.Size = new System.Drawing.Size(147, 27);
            this.ZoomTrackBar.TabIndex = 1;
            this.ZoomTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.ZoomTrackBar.Scroll += new System.EventHandler(this.ZoomTrackBar_Scroll);
            this.ZoomTrackBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ZoomTrackBar_MouseUp);
            // 
            // PitchTrackbar
            // 
            this.PitchTrackbar.Location = new System.Drawing.Point(82, 3);
            this.PitchTrackbar.Maximum = 100;
            this.PitchTrackbar.Minimum = -100;
            this.PitchTrackbar.Name = "PitchTrackbar";
            this.PitchTrackbar.Size = new System.Drawing.Size(147, 26);
            this.PitchTrackbar.TabIndex = 1;
            this.PitchTrackbar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.PitchTrackbar.Scroll += new System.EventHandler(this.PitchTrackbar_Scroll);
            this.PitchTrackbar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.PitchTrackbar_MouseUp);
            // 
            // YawTrackbar
            // 
            this.YawTrackbar.Location = new System.Drawing.Point(82, 35);
            this.YawTrackbar.Maximum = 100;
            this.YawTrackbar.Minimum = -100;
            this.YawTrackbar.Name = "YawTrackbar";
            this.YawTrackbar.Size = new System.Drawing.Size(147, 26);
            this.YawTrackbar.TabIndex = 1;
            this.YawTrackbar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.YawTrackbar.Scroll += new System.EventHandler(this.YawTrackbar_Scroll);
            this.YawTrackbar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.YawTrackbar_MouseUp);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.CamRightButton, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.CamDownButton, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.CamPerspectiveButton, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.CamLeftButton, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.CamUpButton, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(126, 97);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // CamRightButton
            // 
            this.CamRightButton.Location = new System.Drawing.Point(87, 35);
            this.CamRightButton.Name = "CamRightButton";
            this.CamRightButton.Size = new System.Drawing.Size(36, 26);
            this.CamRightButton.TabIndex = 4;
            this.CamRightButton.Text = ">";
            this.CamRightButton.UseVisualStyleBackColor = true;
            this.CamRightButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CamRightButton_MouseDown);
            this.CamRightButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CamRightButton_MouseUp);
            // 
            // CamDownButton
            // 
            this.CamDownButton.Location = new System.Drawing.Point(45, 67);
            this.CamDownButton.Name = "CamDownButton";
            this.CamDownButton.Size = new System.Drawing.Size(35, 27);
            this.CamDownButton.TabIndex = 4;
            this.CamDownButton.Text = "\\/";
            this.CamDownButton.UseVisualStyleBackColor = true;
            this.CamDownButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CamDownButton_MouseDown);
            this.CamDownButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CamDownButton_MouseUp);
            // 
            // CamPerspectiveButton
            // 
            this.CamPerspectiveButton.Location = new System.Drawing.Point(45, 35);
            this.CamPerspectiveButton.Name = "CamPerspectiveButton";
            this.CamPerspectiveButton.Size = new System.Drawing.Size(35, 26);
            this.CamPerspectiveButton.TabIndex = 4;
            this.CamPerspectiveButton.Text = "\\  /";
            this.CamPerspectiveButton.UseVisualStyleBackColor = true;
            this.CamPerspectiveButton.Click += new System.EventHandler(this.CamPerspectiveButton_Click);
            // 
            // CamLeftButton
            // 
            this.CamLeftButton.Location = new System.Drawing.Point(3, 35);
            this.CamLeftButton.Name = "CamLeftButton";
            this.CamLeftButton.Size = new System.Drawing.Size(35, 26);
            this.CamLeftButton.TabIndex = 4;
            this.CamLeftButton.Text = "<";
            this.CamLeftButton.UseVisualStyleBackColor = true;
            this.CamLeftButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CamLeftButton_MouseDown);
            this.CamLeftButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CamLeftButton_MouseUp);
            // 
            // CamUpButton
            // 
            this.CamUpButton.Location = new System.Drawing.Point(45, 3);
            this.CamUpButton.Name = "CamUpButton";
            this.CamUpButton.Size = new System.Drawing.Size(35, 26);
            this.CamUpButton.TabIndex = 4;
            this.CamUpButton.Text = "/\\";
            this.CamUpButton.UseVisualStyleBackColor = true;
            this.CamUpButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CamUpButton_MouseDown);
            this.CamUpButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CamUpButton_MouseUp);
            // 
            // label10
            // 
            label10.Dock = System.Windows.Forms.DockStyle.Bottom;
            label10.Location = new System.Drawing.Point(0, 216);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(370, 23);
            label10.TabIndex = 0;
            label10.Text = "Control";
            label10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Dock = System.Windows.Forms.DockStyle.Right;
            this.label11.Location = new System.Drawing.Point(370, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 239);
            this.label11.TabIndex = 2;
            // 
            // panel8
            // 
            panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            panel8.Controls.Add(label15);
            panel8.Controls.Add(this.label16);
            panel8.Controls.Add(this.ResetRotationButton);
            panel8.Controls.Add(this.ResetPositionButton);
            panel8.Location = new System.Drawing.Point(795, -1);
            panel8.Name = "panel8";
            panel8.Size = new System.Drawing.Size(165, 239);
            panel8.TabIndex = 0;
            // 
            // label15
            // 
            label15.Dock = System.Windows.Forms.DockStyle.Bottom;
            label15.Location = new System.Drawing.Point(0, 216);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(152, 23);
            label15.TabIndex = 0;
            label15.Text = "Reset";
            label15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label16.Dock = System.Windows.Forms.DockStyle.Right;
            this.label16.Location = new System.Drawing.Point(152, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 239);
            this.label16.TabIndex = 2;
            // 
            // ResetRotationButton
            // 
            this.ResetRotationButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ResetRotationButton.BackColor = System.Drawing.Color.LightCoral;
            this.ResetRotationButton.Location = new System.Drawing.Point(3, 37);
            this.ResetRotationButton.Name = "ResetRotationButton";
            this.ResetRotationButton.Size = new System.Drawing.Size(143, 26);
            this.ResetRotationButton.TabIndex = 4;
            this.ResetRotationButton.Text = "Reset Rotation";
            this.ResetRotationButton.UseVisualStyleBackColor = false;
            this.ResetRotationButton.Click += new System.EventHandler(this.ResetRotationButton_Click);
            // 
            // ResetPositionButton
            // 
            this.ResetPositionButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ResetPositionButton.BackColor = System.Drawing.Color.LightCoral;
            this.ResetPositionButton.Location = new System.Drawing.Point(3, 6);
            this.ResetPositionButton.Name = "ResetPositionButton";
            this.ResetPositionButton.Size = new System.Drawing.Size(143, 26);
            this.ResetPositionButton.TabIndex = 4;
            this.ResetPositionButton.Text = "Reset Position";
            this.ResetPositionButton.UseVisualStyleBackColor = false;
            this.ResetPositionButton.Click += new System.EventHandler(this.ResetPositionButton_Click);
            // 
            // ToolBox_Camera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1521, 236);
            this.Controls.Add(panel6);
            this.Controls.Add(panel8);
            this.Controls.Add(RotationPanel);
            this.Controls.Add(PositionPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ToolBox_Camera";
            this.Text = "ToolBox_Camera";
            this.Load += new System.EventHandler(this.ToolBox_Camera_Load);
            PositionPanel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            RotationPanel.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            panel6.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZoomTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PitchTrackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YawTrackbar)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox ZPosTextBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox YPosTextBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox XPosTextBox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox YawTextBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox PitchTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button SnapToYZButton;
        private System.Windows.Forms.Button SnapToXZButton;
        private System.Windows.Forms.Button SnapToXYButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button CamRightButton;
        private System.Windows.Forms.Button CamDownButton;
        private System.Windows.Forms.Button CamLeftButton;
        private System.Windows.Forms.Button CamUpButton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TrackBar YawTrackbar;
        private System.Windows.Forms.TrackBar PitchTrackbar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TrackBar ZoomTrackBar;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button ResetRotationButton;
        private System.Windows.Forms.Button ResetPositionButton;
        private System.Windows.Forms.Button CamPerspectiveButton;
    }
}