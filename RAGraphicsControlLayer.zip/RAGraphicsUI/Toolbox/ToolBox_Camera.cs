﻿using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Windows.Forms;
using RAGraphicsControlLayer;

namespace RAGraphicsUI.Toolbox
{

    public partial class ToolBox_Camera : Form
    {
        #region Variables

        private ICamera _camera;
        private RAOpenGLContainer _renderer;
        private Thread _showValThread;
        private List<bool> _threadSubscriber;
        private static bool _stopInvoking = false;

        #endregion /Variables

        #region Constructors

        /// <summary>
        /// Initialize the Camera Toolbox.
        /// </summary>
        /// <param name="renderer"> Pass the 3D graphics control to manipulate its parameters. </param>
        /// <param name="threadSubscriber"> Subscribe to the thread checker in the MainUI layer. </param>
        public ToolBox_Camera(RAOpenGLContainer renderer, List<bool> threadSubscriber = null)
        {
            InitializeComponent();

            if (threadSubscriber != null) _threadSubscriber = threadSubscriber;
            
            _renderer = renderer;
            _camera = _renderer.RenderCamera;
        }

        #endregion /Constructors

        #region Getters/Setters

        /// <summary>
        /// This flag checks whether or not the Main window is closing.
        /// </summary>
        public static bool ShuttingDown
        {
            get => _stopInvoking;
            set
            {
                _stopInvoking = value;
            }
        }

        #endregion /Getters/Setters

        #region Methods

        private void ToolBox_Camera_Load(object sender, EventArgs e)
        {
            //  Extend the graphics timer to add events from this class.
            _renderer.timerGraphicsLuncher.Tick += new EventHandler(AddToUpdateEvent);
        }

        /// <summary>
        /// Create threads to update textbox items with needed values.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddToUpdateEvent(object sender, EventArgs e)
        {
            var threadParameters = new ThreadStart(delegate { DisplayCameraValues(_camera.Position , _camera.Yaw.ToString() ,_camera.Pitch.ToString()); });
            _showValThread = new Thread(threadParameters);
            _showValThread.Start();
        }

        /// <summary>
        /// Make use of delegates to pass updated values to controls on the UI.
        /// </summary>
        /// <param name="position"> Camera position coordinates. </param>
        /// <param name="pitch"> Camera Pitch rotation value. </param>
        /// <param name="yaw"> Camera Yaw rotation value. </param>
        private void DisplayCameraValues(OpenTK.Vector3 position, string pitch, string yaw)
        {
            if (PitchTextBox.InvokeRequired)
            {
                if (_threadSubscriber == null)
                {
                    throw new Exception("Error! ToolBox_Camera.cs was not implemented correctly! Thread Subscriber not implemented, but action requires threads.");
                }

//                if (_stopInvoking != true)
                if (ShuttingDown != true)
                {
                    // VERY IMPORTANT
                    // The ClosingChecks list NEEDS to be handled in pairs of Add ... Remove
                    // Otherwise, the Application will not exit.
                    // TB Discussed --- Since we don't care where or what the values in the list are,
                    //      we could probably replace the list itself with an int variable and handle code with ++ and --
                    //      OR replace the bools with strings. More memory to be stored but the values can be used to indicate what thread activity was not handled.

//                    MainUI.ClosingChecks.Add(false);
                    _threadSubscriber.Add(false);

                    Action safeWrite = delegate { DisplayCameraValues(position, pitch, yaw); };
                    PitchTextBox.Invoke(safeWrite);

//                    MainUI.ClosingChecks.RemoveAt(0);
                    _threadSubscriber.RemoveAt(0);
                }
            }
            else
            {
                XPosTextBox.Text = position.X.ToString();
                YPosTextBox.Text = position.Y.ToString();
                ZPosTextBox.Text = position.Z.ToString();
                PitchTextBox.Text = pitch;
                YawTextBox.Text = yaw;
            }
        }

        #region Rotation Buttons

        private void SnapToXYButton_Click(object sender, EventArgs e)
        {
            _camera.SnapToXY();
        }

        private void SnapToXZButton_Click(object sender, EventArgs e)
        {
            _camera.SnapToXZ();
        }

        private void SnapToYZButton_Click(object sender, EventArgs e)
        {
            _camera.SnapToYZ();
        }

        #endregion /Rotation Buttons

        #region Control Buttons

        private void CamPerspectiveButton_Click(object sender, EventArgs e)
        {
            _camera.ChangePerspective();
        }

        private void CamUpButton_MouseDown(object sender, MouseEventArgs e)
        {
            _renderer.PanUp = true;
        }

        private void CamUpButton_MouseUp(object sender, MouseEventArgs e)
        {
            _renderer.PanUp = false;
        }

        private void CamLeftButton_MouseDown(object sender, MouseEventArgs e)
        {
            _renderer.PanLeft = true;
        }

        private void CamLeftButton_MouseUp(object sender, MouseEventArgs e)
        {
            _renderer.PanLeft = false;
        }

        private void CamRightButton_MouseDown(object sender, MouseEventArgs e)
        {
            _renderer.PanRight = true;
        }

        private void CamRightButton_MouseUp(object sender, MouseEventArgs e)
        {
            _renderer.PanRight = false;
        }

        private void CamDownButton_MouseDown(object sender, MouseEventArgs e)
        {
            _renderer.PanDown = true;
        }

        private void CamDownButton_MouseUp(object sender, MouseEventArgs e)
        {
            _renderer.PanDown = false;
        }

        private void PitchTrackbar_Scroll(object sender, EventArgs e)
        {
            _renderer.PitchStrength = PitchTrackbar.Value;
        }

        private void PitchTrackbar_MouseUp(object sender, MouseEventArgs e)
        {
            PitchTrackbar.Value = 0;
            _renderer.PitchStrength = PitchTrackbar.Value;
        }

        private void YawTrackbar_Scroll(object sender, EventArgs e)
        {
            _renderer.YawStrength = YawTrackbar.Value;
        }

        private void YawTrackbar_MouseUp(object sender, MouseEventArgs e)
        {
            YawTrackbar.Value = 0;
            _renderer.YawStrength = YawTrackbar.Value;
        }

        private void ZoomTrackBar_Scroll(object sender, EventArgs e)
        {
            _renderer.ZoomStrength = ZoomTrackBar.Value;
        }

        private void ZoomTrackBar_MouseUp(object sender, MouseEventArgs e)
        {
            ZoomTrackBar.Value = 0;
            _renderer.ZoomStrength = ZoomTrackBar.Value;
        }

        #endregion /Control Buttons

        #region Reset Buttons

        private void ResetPositionButton_Click(object sender, EventArgs e)
        {
            _camera.ResetPosition();
        }

        private void ResetRotationButton_Click(object sender, EventArgs e)
        {
            _camera.ResetRotation();
        }

        #endregion /Reset Buttons

        #endregion /Methods
    }
}