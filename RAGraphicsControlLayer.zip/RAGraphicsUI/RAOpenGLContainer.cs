﻿using System;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Input;
using GraphicsControlLayer;
using RAGraphicsControlLayer;
using RAManagementLayer;

namespace RAGraphicsUI
{
    public partial class RAOpenGLContainer : UserControl
    {
        #region Private Variables

        private ICamera _cam;
        private System.Windows.Forms.MouseEventArgs _mouse;
        private Vector2 _vLastPos;
        private float _yawStrength, _pitchStrength, _zoomStrength;
        private float _deltaTime;
        private bool _hasFocus = false;
        private bool _num5_Handled = false;
        private bool _num9_Handled = false;
        private bool _firstMove = true;
        private bool _canPan = false;
        private bool _canZoom = false;

        #endregion /Private Variables

        #region Constructors

        public RAOpenGLContainer()
        {
            InitializeComponent();
            RenderCamera = _cam;
        }

        #endregion /Constructors

        #region Getters/Setters

        /// <summary>
        /// Manually handle if the parent form is focused or not.
        /// </summary>
        public bool IsFocused
        {
            private get => _hasFocus;
            set 
            {
                _hasFocus = value;
            }
        }

        //As their name implies, we can handle different FPS values within the application. Values to be checked at a later time.
        public int FocusedTickRate = 10; // 100 FPS
        public int UnocusedTickRate = 67; // ~15 FPS

        /// <summary>
        /// Get the Frames Per Second of the renderer.
        /// This value cannot and should not be set to anything. FPS is a consequential value.
        /// </summary>
        public float FPS
        {
            get => 1000 / timerGraphicsLuncher.Interval;
        }

        /// <summary>
        /// This is the main camera of the rendering panel.
        /// </summary>
        public ICamera RenderCamera
        {
            get => _cam;
            private set 
            {
                _cam = new Camera(Vector3.Zero, 1025f / 566f);
                _cam.Initialize();
            }
        }

        // Flags for the Toolbox_Camera Pan control

        public bool PanUp = false, PanDown = false, PanLeft = false, PanRight = false;

        public float YawStrength 
        {
            get => _yawStrength;
            set => _yawStrength = value * 0.01f;
        }

        public float PitchStrength
        {
            get => _pitchStrength;
            set => _pitchStrength = value * 0.01f;
        }

        public float ZoomStrength
        {
            get => _zoomStrength;
            set => _zoomStrength = value * 001f;
        }

        #endregion /Getters/Setters

        #region Methods

        /// <summary>
        /// The "Start" method. Used to set the FPS and start the rendering process.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RenderPanel_Load(object sender, EventArgs e)
        {
            RenderControl.RenderStart(RenderPanel);

            timerGraphicsLuncher.Interval = FocusedTickRate;   // 1000 ms per sec / 50 ms per frame = 20 FPS
            timerGraphicsLuncher.Start();
            timerGraphicsLuncher.Tick += new EventHandler(timerGraphicsLuncher_Tick);
        }

        /// <summary>
        /// This acts as Input Update. Get Input control each tick then send a frame render command.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerGraphicsLuncher_Tick(object sender, EventArgs e)
        {
            if (IsFocused)
            {
                ProcessInput(0.001f * (float)timerGraphicsLuncher.Interval); // this gets a frame time in miliseconds
            }
            else
            {
                _canPan = false;
                _canZoom = false;
            }
            
            //After input is accounted for, go ahead and render the next frame
            RenderControl.RenderFrameWithContour(RenderPanel, RenderCamera.GetViewMatrix(), RenderCamera.GetViewMode());
        }

        /// <summary>
        /// Handle the user Input.
        /// </summary>
        /// <param name="deltaTime"> This is the time between 2 adjacent frames. </param>
        private void ProcessInput(float deltaTime)
        {
            if (_mouse == null) return;

            #region Get Inputs

            _deltaTime = deltaTime;
            var input = Keyboard.GetState();
            float panV = 0f, panH = 0f;
            float rotYaw = 0f, rotPitch = 0f;
            float zoom = 0f;

            //Check for Pan and Zoom modifiers
            if ((input.IsKeyDown(Key.ControlLeft) || input.IsKeyDown(Key.ControlRight)) && _mouse.Button == MouseButtons.None)
            {
                _canZoom = true;
                _canPan = true;
            }
            else
            {
                // Do not reset flags unless the user releases all mouse buttons. 
                if (_mouse.Button == MouseButtons.None)
                {
                    _canZoom = false;
                    _canPan = false;
                }
            }

            // Handle Pan direction
            if (_canPan)
            {
                if (input.IsKeyDown(Key.Keypad2)) panV = -1f;
                else if (input.IsKeyDown(Key.Keypad8)) panV = 1f;
                
                if (input.IsKeyDown(Key.Keypad4)) panH = -1f;
                else if (input.IsKeyDown(Key.Keypad6)) panH = 1f;
            }
            // Handle Pitch and Yaw directions
            else 
            {
                if (input.IsKeyDown(Key.Keypad2))      rotPitch = -100f;
                else if (input.IsKeyDown(Key.Keypad8)) rotPitch =  100f;

                if (input.IsKeyDown(Key.Keypad4))      rotYaw = -100f;
                else if (input.IsKeyDown(Key.Keypad6)) rotYaw =  100f;
            }

            //Reset camera position
            if (input.IsKeyDown(Key.Home)) RenderCamera.ResetPosition();

            //Reset both position and rotation
            if (input.IsKeyDown(Key.End)) RenderCamera.ResetRotation();

            //Rotate screen paralel to XY (front)
            if (input.IsKeyDown(Key.Keypad1)) RenderCamera.SnapToXY();

            //Rotate screen paralel to YZ (right)
            if (input.IsKeyDown(Key.Keypad3)) RenderCamera.SnapToYZ();

            //Rotate screen paralel to XY (topdown)
            if (input.IsKeyDown(Key.Keypad7)) RenderCamera.SnapToXZ();

            //Switch Perspective and Ortho || the _Handled flags are added because the library lacks an IsKeyPressed() method
            if (input.IsKeyDown(Key.Keypad5))
            {
                if (!_num5_Handled)
                {
                    _num5_Handled = true;
                    RenderCamera.ChangePerspective();
                }
            }
            else
            {
                _num5_Handled = false;
            }

            //Rotate YAW 180 degrees
            if (input.IsKeyDown(Key.Keypad9)) 
            {
                if (!_num9_Handled)
                {
                    _num9_Handled = true;
                    RenderCamera.FlipYaw();
                }
            }
            else
            {
                _num9_Handled = false;
            }
            
            if (input.IsKeyDown(Key.KeypadSubtract)) zoom = -100f;
            else if (input.IsKeyDown(Key.KeypadAdd)) zoom = 100f;

            #endregion /Get Inputs

            #region Toolbox Controls

            if (PanUp)
            {
                panV = 1f;
                panH = 0f;
            }
            else if (PanDown)
            {
                panV = -1f;
                panH = 0f;
            }
            else if (PanLeft)
            {
                panV = 0f;
                panH = -1f;
            }
            else if (PanRight)
            {
                panV = 0f;
                panH = 1f;
            }
            else
            {
                //Intentionally left blank
            }

            #endregion /Toolbox Controls

            //Process Camera changes at the end

            if (panV != 0f || panH != 0f) PanCamera(panV, panH);
            
            if (YawStrength != 0f) YawCamera(YawStrength);
            else if (rotYaw != 0f) YawCamera(rotYaw);
            
            if (PitchStrength != 0f) PitchCamera(PitchStrength);
            else if (rotPitch != 0f) PitchCamera(rotPitch);
            
            if (ZoomStrength != 0f) ZoomCamera(ZoomStrength);
            else if (zoom != 0f) ZoomCamera(zoom);

        }

        private void PanCamera(float vertical, float horizontal)
        {
            RenderCamera.Move(vertical, horizontal, _deltaTime);
        }

        private void YawCamera(float value)
        {
            RenderCamera.RotateYaw(value, _deltaTime);
        }

        private void PitchCamera(float value)
        {
            RenderCamera.RotatePitch(value, _deltaTime);
        }

        private void ZoomCamera(float value)
        {
            RenderCamera.ChangeZoom(value, _deltaTime);
        }

        /// <summary>
        /// Process Mouse Wheel events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RenderPanel_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            RenderCamera.ZoomWithCursor(e.Delta);
        }

        /// <summary>
        /// Process Mouse move events.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RenderPanel_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            _mouse = e;

            if (e.Button == MouseButtons.Middle)
            {
                Cursor = Cursors.SizeAll;

                if (_firstMove) //---> Record mouse first position when grabbed
                {
                    _vLastPos = new Vector2(e.X, e.Y);
                    _firstMove = false;
                }
                else //---> Start calculating mouse movements
                {
                    var deltaX = e.X - _vLastPos.X;
                    var deltaY = e.Y - _vLastPos.Y;
                    _vLastPos = new Vector2(e.X, e.Y);

                    if (_canPan == true) // Pan is triggered by LEFT or RIGHT SHIFT
                    {
                        RenderCamera.MoveWithCursor(deltaX, deltaY, _deltaTime);
                    }
                    else if (_canZoom == true) // Zoom is triggered by LEFT or RIGHT CONTROL
                    {
                        RenderCamera.ZoomWithCursor(deltaY * 0.1f);
                    }
                    else // Tilt is triggered if SHIFT and CONTROL are NOT pressed!
                    {
                        RenderCamera.RotateWithCursor(deltaX, deltaY);
                    }
                }
            }
            //Reset triggers upon Mouse3 release
            else
            {
                _firstMove = true;
                Cursor = Cursors.Default;
            }
        }

        /// <summary>
        /// Process the container resize event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RenderPanel_Resize(object sender, EventArgs e)
        {
            if (RenderCamera != null)
            {
                RenderControl.Resize(RenderPanel, RenderCamera);
            }
        }

        #endregion /Methods
    }
}
