﻿using System;
using System.Diagnostics;
using OpenTK;
using RAGraphicsControlLayer;

namespace GraphicsControlLayer
{
    public class Camera : ICamera
    {
        #region Private Variables

        private Vector3 _front = -Vector3.UnitZ;
        private Vector3 _up    =  Vector3.UnitY;
        private Vector3 _right =  Vector3.UnitX;

        private float _rotIncrements = 2f;
        private float _pitch;
        private float _yaw = -MathHelper.PiOver2;
        private float _fov = MathHelper.DegreesToRadians(60f); // Field of View for perspective camera. 60f is a decent value.
        private float _zoom = 6f;
        private float _zoomPercent = 0.1f;

        private float _mSensitivity = 0.2f;
        private float _cameraSpeed = 1.5f;

        private bool _isPerspectiveCamera = true;

        #endregion /Private Variables

        #region Constructors

        public Camera (Vector3 position, float aspectRatio)
        {
            Position = position;
            AspectRatio = aspectRatio;
        }

        #endregion /Constructors

        #region Getters/Setters

        public event EventHandler PitchChanged;

        public Vector3 Position { get; set; }

        public float AspectRatio { private get; set; }

        //Front would correspond to moving forward like in a game. Not currently used.
        public Vector3 Front => _front;
        public Vector3 Up => _up;
        public Vector3 Right => _right;

        public float Pitch
        {
            get => MathHelper.RadiansToDegrees(_pitch);
            set
            {
                var angle = MathHelper.Clamp(value, -89f, 89f);
                _pitch = MathHelper.DegreesToRadians(angle);
                UpdateVectors();
                OnPitchChanged();
            }
        }

        public float Yaw
        {
            get => MathHelper.RadiansToDegrees(_yaw);
            set
            {
                _yaw = MathHelper.DegreesToRadians(value);
                UpdateVectors();
            }
        }

        public float Fov
        {
//            get => MathHelper.RadiansToDegrees(_fov);
            get => _fov;
            set
            {
                var angle = MathHelper.Clamp(value, 1f, 90f);
                _fov = MathHelper.DegreesToRadians(angle);
            }
        }

        public float Zoom
        {
            get
            {
                return _zoom;
            }
            set
            {
                _zoom = value;
                _zoom = MathHelper.Clamp(_zoom, 0.01f, 10000f);
            }
        }

        #endregion /Getters/Setters

        #region Methods

        protected virtual void OnPitchChanged()
        {
            if (PitchChanged != null) PitchChanged(this, EventArgs.Empty);
        }

        public void Initialize()
        {
            Pitch = -45f;
            Yaw = -135f;
        }

        public Matrix4 GetViewMode()
        {
            if (_isPerspectiveCamera)
                return Matrix4.CreatePerspectiveFieldOfView(Fov, AspectRatio, 0.001f, 10000f);
            else
                return Matrix4.CreateOrthographic(AspectRatio * Zoom, Zoom, 0.001f, 10000f);
        }

        private void UpdateVectors()
        {
            _front.X = (float)Math.Cos(_pitch) * (float)Math.Cos(_yaw);
            _front.Y = (float)Math.Sin(_pitch);
            _front.Z = (float)Math.Cos(_pitch) * (float)Math.Sin(_yaw);

            _front = Vector3.Normalize(_front);

            _right = Vector3.Normalize(Vector3.Cross(_front, Vector3.UnitY));
            _up    = Vector3.Normalize(Vector3.Cross(_right, _front));
        }

        /// <summary>
        /// <para>Lerp interpolates between two points by a specified percentage. </para>
        /// <br>0f (0%) returns the starting value, while 1f (100%) returns the end value.</br>
        /// </summary>
        /// <param name="from"> Starting value for the operation. </param>
        /// <param name="to"> Destination value for the operation. </param>
        /// <param name="amount"> Percent of the movement between the two. Valid values are between 0f and 1f. </param>
        /// <returns> A float, corresponding to the value calculated between the start and end values. </returns>
        private float Lerp(float from, float to, float amount)
        {
            amount = MathHelper.Clamp(amount, 0f, 1f);
            return from + (to - from) * amount;
        }

        public void ChangeZoom(float dir, float deltaTime)
        {
            dir = MathHelper.Clamp(dir, -1f, 1f);

            float offset = Lerp(0f, Zoom, deltaTime);

            Zoom -= offset * dir;
        }
        public void ZoomWithCursor(float dir)
        {
            if (dir < 0f) dir = -1;
            else dir = 1;

            float offset = Lerp(0f, Zoom, _zoomPercent);

            Zoom -= offset * dir;
        }


        //bing to Num5
        public void ChangePerspective()
        {
            _isPerspectiveCamera = !_isPerspectiveCamera;
        }

        public void ResetRotation()
        {
            Pitch = -45f;
            Yaw = -135f;
        }
        //bind to Num1
        public void SnapToXY()
        {
            Pitch = 0f;
            Yaw = 270f;
        }
        //bind to Num3
        public void SnapToXZ()
        {
            Pitch = -89f;
            Yaw = 270f;
        }
        //bind to Num7
        public void SnapToYZ()
        {
            Pitch = 0f;
            Yaw = 180f;
        }
        //bind to Num9
        public void FlipYaw()
        {
            if (Yaw > 180f)
            {
                Yaw -= 180f;
            }
            else
            {
                Yaw += 180f;
            }
        }
        //bind -1 to Num4 and +1 to Num6
        public void RotateYaw(float dir, float deltaTime)
        {
            dir = MathHelper.Clamp(dir, -1f, 1f);
            Yaw += 360f / _rotIncrements * dir * deltaTime;
        }
        //bind -1 to Num2 and +1 to Num8
        public void RotatePitch(float dir, float deltaTime)
        {
            dir = MathHelper.Clamp(dir, -1f, 1f);
            Pitch += 360f / _rotIncrements * dir * deltaTime;
        }
        public void RotateWithCursor(float yawRot, float pitchRot)
        {
            Yaw += yawRot * _mSensitivity;
            Pitch -= pitchRot * _mSensitivity; // !! Reversed
        }

        public Matrix4 GetViewMatrix()
        {
            //this fixes a bug with the camera offset where ortho Zoom would make part of the object not be displayed
            // Long stoy short, we force the camera to be 1000 units away from the point it is looking at in ortho mode
            // This works because Orthographic mode
            float _camOffset;
            _camOffset = _isPerspectiveCamera == true ? Zoom : 1000f;

            return Matrix4.LookAt(Position - _front * _camOffset, Position + _front, _up);
        }

        public void ResetPosition()
        {
            Position = Vector3.Zero;
        }
        public void Move(float vertical, float horizontal, float deltaTime)
        {
            if (vertical > 0f) vertical = 1f;
            else if (vertical < 0f) vertical = -1f;
            else vertical = 0f;
            
            if (horizontal > 0f) horizontal = 1f;
            else if (horizontal < 0f) horizontal = -1f;
            else horizontal = 0f;

            Position += Up    * vertical   * _cameraSpeed * Zoom / 2f * deltaTime; // Up
            Position += Right * horizontal * _cameraSpeed * Zoom / 2f * deltaTime; //  Strafe Right
        }
        public void MoveWithCursor(float x, float y, float deltaTime)
        {
            Position -= Right * x * deltaTime * Zoom / 12f; // Strafe Right
            Position += Up    * y * deltaTime * Zoom / 12f; // Up
        }

        public void GetAspectRatio(float X, float Y)
        {
            AspectRatio = X / Y;
        }

        #endregion /Methods
    }
}
