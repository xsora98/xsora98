﻿using OpenTK.Graphics.OpenGL;

namespace NetCoreGLApp.Shaders
{
    public class VertexShaderLayout
    {
        private static string vertexShaderCode = @"#version 330 core
                                               layout (location = 0) in vec4 aPosition; 
                                               void main(void)
{
    gl_Position = vec4(aPosition, 1.0);
}";
        
        public static string VertexShaderCode { get { return vertexShaderCode; }private set {} }
        
        public unsafe static void EnableCurrentVertexAttributes() 
        {
            GL.VertexAttribPointer(0, 4, VertexAttribPointerType.Float, false, 8 * sizeof(float), (System.IntPtr)0);
            GL.EnableVertexAttribArray(0);

            GL.VertexAttribPointer(1, 4, VertexAttribPointerType.Float, false, sizeof(float) * 8, (System.IntPtr)(4 * sizeof(float)));
            GL.EnableVertexAttribArray(1);

            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindVertexArray(0);
        }
    }
}
