﻿using System.Diagnostics;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace GraphicsControlLayer
{
    public class Shader
    {
        #region //storage

        string vertexCode;
        string fragmentCode;
        public int ProgramID { get; set; }

        #endregion

        #region //constructors
        public Shader(string vertexCode, string fragmentCode)
        {
            this.vertexCode = vertexCode;
            this.fragmentCode = fragmentCode;
        }
        #endregion

        #region//shader operations
        private int CompileShader(ShaderType type, string shaderCode)
        {
            var shader = GL.CreateShader(type);
            GL.ShaderSource(shader, shaderCode);
            GL.CompileShader(shader); 

            return shader;
        }

        private static void CheckShaderStatus(int shaderType)
        {
            int[] parameters = new int[10];
            GL.GetShader(shaderType, ShaderParameter.CompileStatus, parameters);
            if (parameters[0] == 0)
            {
                Debug.WriteLine($"Error compiling {shaderType} -> {GL.GetShaderInfoLog(shaderType)}");
            }

        }

        private void AttachShadersAndLinkProgram(int vertexShader, int fragmentShader)
        {
            ProgramID = GL.CreateProgram();
            GL.AttachShader(ProgramID, vertexShader);
            GL.AttachShader(ProgramID, fragmentShader);
            GL.LinkProgram(ProgramID);
        }
        private void DetachAndDeleteShaders(int vertexShader, int fragmentShader)
        {
            
            GL.DetachShader(ProgramID, vertexShader);
            GL.DetachShader(ProgramID, fragmentShader);

            GL.DeleteShader(vertexShader);
            GL.DeleteShader(fragmentShader);
        }

        public void Load()
        {
            int vs, fs;
            
            vs = CompileShader(ShaderType.VertexShader, vertexCode);
            CheckShaderStatus(vs);

            fs = CompileShader(ShaderType.FragmentShader, fragmentCode);
            CheckShaderStatus(fs);

            AttachShadersAndLinkProgram(vs, fs);

            //delete shaders 
            DetachAndDeleteShaders(vs, fs);
        }

        public void UseProgram()
        {
            GL.UseProgram(ProgramID);
        }

        public void SetMatrix4(int location, Matrix4 data)
        {
            GL.UseProgram(ProgramID);
            GL.UniformMatrix4(location, true, ref data);
        }

        public void SetVector3(int location, Vector3 data)
        {
            GL.UseProgram(ProgramID);
            GL.Uniform3(location, ref data);
        }

        #endregion
    }
}
