﻿using System;
using OpenTK;

namespace RAGraphicsControlLayer
{
    public interface ICamera
    {
        event EventHandler PitchChanged;
        float Pitch { get; }
        float Yaw { get; }
        Vector3 Position { get; }
        /// <summary>
        /// Calculate where the Camera is looking at AND its offset.
        /// </summary>
        /// <returns>The Camera LookAt matrix.</returns>
        Matrix4 GetViewMatrix();
        /// <summary>
        /// Calculate the perspective of the Camera.
        /// </summary>
        /// <returns>The Camera perspective OR orthographic matrix.</returns>
        Matrix4 GetViewMode();
        /// <summary>
        /// Change the Camera offset by using the mouse scroll wheel.
        /// </summary>
        /// <param name="dir">Direction of movement. Only the sign is needed.</param>
        void ZoomWithCursor(float dir);
        /// <summary>
        /// Change the Camera offset by using keyboard inputs.
        /// </summary>
        /// <param name="dir">Direction of movement. Only the sign is needed.</param>
        /// <param name="deltaTime">1 Second / FPS. Used to normalize movements for different machines.</param>
        void ChangeZoom(float dir, float deltaTime);
        /// <summary>
        /// Set the Camera rotation normal to the Front plane.
        /// </summary>
        void SnapToXY();
        /// <summary>
        /// Set the Camera rotation normal to the Right plane.
        /// </summary>
        void SnapToXZ();
        /// <summary>
        /// Set the Camera rotation normal to the Top plane.
        /// </summary>
        void SnapToYZ();
        /// <summary>
        /// Switch between Orthographic and Perspective Camera modes.
        /// </summary>
        void ChangePerspective();
        /// <summary>
        /// Rotate the Camera Yaw by 180 degrees from the current position.
        /// </summary>
        void FlipYaw();
        /// <summary>
        /// Rotate the Camera Yaw by using the Keyboard.
        /// </summary>
        /// <param name="dir"> Direction of rotation. Only uses the sign of the parameter.</param>
        /// <param name="deltaTime"> 1 Second / FPS. Used to normalize movements for different machines. </param>
        void RotateYaw(float dir, float deltaTime);
        /// <summary>
        /// Rotate the Camera Pitch by using the Keyboard.
        /// </summary>
        /// <param name="dir"> Direction of rotation. Only uses the sign of the parameter. </param>
        /// <param name="deltaTime"> 1 Second / FPS. Used to normalize movements for different machines. </param>
        void RotatePitch(float dir, float deltaTime);
        /// <summary>
        /// Set the Camera back to the world origin.
        /// </summary>
        void ResetPosition();
        /// <summary>
        /// Recalculate the renderer aspect ratio.
        /// </summary>
        /// <param name="X">Container Width.</param>
        /// <param name="Y">Container Height.</param>
        void GetAspectRatio(float X, float Y);
        /// <summary>
        /// On load, rotate the Camera to a nice angle.
        /// </summary>
        void Initialize();
        /// <summary>
        /// Reset the Camera orientation.
        /// </summary>
        void ResetRotation();
        /// <summary>
        /// Change the Camera position using the Mouse movement.
        /// </summary>
        /// <param name="x">Mouse Horizontal Axis.</param>
        /// <param name="y">Mouse Vertical Axis.</param>
        /// <param name="deltaTime"> 1 Second / FPS. Used to normalize movements for different machines. </param>
        void MoveWithCursor(float x, float y, float deltaTime);
        /// <summary>
        /// Change the Camera position using the keyboard.
        /// </summary>
        /// <param name="vertical"> Vertical Axis.</param>
        /// <param name="horizontal">Horizontal Axis.</param>
        /// <param name="deltaTime"> 1 Second / FPS. Used to normalize movements for different machines. </param>
        void Move(float vertical, float horizontal, float deltaTime);
        /// <summary>
        /// Rotate the camera by using the mouse movements.
        /// </summary>
        /// <param name="yawRot">Mouse X (horizontal) input.</param>
        /// <param name="pitchRot">Mouse Y (vertical) input.</param>
        void RotateWithCursor(float yawRot, float pitchRot);
    }
}
